// lib/spiders.ts
var SKINS = [
  { id: "classic", name: "Unnepo", unlockAt: 0, color: "#6E5B6E" },
  { id: "school", name: "School spirit", unlockAt: 0, color: "#6E5B6E" },
  { id: "blue", name: "Blue", unlockAt: 50, color: "#3D8BFF" },
  { id: "green", name: "Green", unlockAt: 150, color: "#2FBF71" },
  { id: "purple", name: "Purple", unlockAt: 300, color: "#9B5CFF" },
  { id: "gold", name: "Gold", unlockAt: 500, color: "#F2B227" },
  { id: "pink", name: "Pink", unlockAt: 1e3, color: "#FF5C9A" }
];
var SCHOOL_STYLES = {
  "colby college": { color: "#002169", text: "#FFFFFF", letters: "C" },
  "university of vermont": { color: "#154734", text: "#FFD416", letters: "UVM" },
  "uvm": { color: "#154734", text: "#FFD416", letters: "UVM" },
  "university of pennsylvania": { color: "#011F5B", text: "#FFFFFF", letters: "P" },
  "university of pittsburgh": { color: "#003594", text: "#FFB81C", letters: "P" },
  "cornell university": { color: "#B31B1B", text: "#FFFFFF", letters: "C" },
  "columbia university": { color: "#6CACE4", text: "#FFFFFF", letters: "C" },
  "boston college": { color: "#8A100B", text: "#E0C48A", letters: "BC" },
  "new york university": { color: "#57068C", text: "#FFFFFF", letters: "NYU" },
  "university of washington": { color: "#4B2E83", text: "#B7A57A", letters: "W" },
  "university of texas at austin": { color: "#BF5700", text: "#FFFFFF", letters: "T" },
  "bowdoin college": { color: "#1A1A1A", text: "#FFFFFF", letters: "B" },
  "bates college": { color: "#881124", text: "#FFFFFF", letters: "B" },
  "middlebury college": { color: "#0D395F", text: "#FFFFFF", letters: "M" },
  "williams college": { color: "#500082", text: "#FFCC00", letters: "W" },
  "amherst college": { color: "#3F1F69", text: "#FFFFFF", letters: "A" },
  "brown university": { color: "#4E3629", text: "#ED1C24", letters: "B" },
  "dartmouth college": { color: "#00693E", text: "#FFFFFF", letters: "D" },
  "yale university": { color: "#00356B", text: "#FFFFFF", letters: "Y" },
  "harvard university": { color: "#A51C30", text: "#FFFFFF", letters: "H" },
  "princeton university": { color: "#E77500", text: "#121212", letters: "P" },
  "stanford university": { color: "#8C1515", text: "#FFFFFF", letters: "S" },
  "university of michigan": { color: "#00274C", text: "#FFCB05", letters: "M" },
  "university of california, berkeley": { color: "#003262", text: "#FDB515", letters: "CAL" },
  "georgetown university": { color: "#041E42", text: "#A7B1B7", letters: "G" },
  "duke university": { color: "#00539B", text: "#FFFFFF", letters: "D" },
  "northwestern university": { color: "#4E2A84", text: "#FFFFFF", letters: "N" }
};
var FALLBACK_COLORS = ["#1D4F91", "#7A1F2B", "#1F6B45", "#5B2C83", "#B35A00", "#0F5A6B"];
var FILLER = /* @__PURE__ */ new Set(["of", "the", "at", "and", "for", "in"]);
function schoolStyle(school) {
  const name = (school ?? "").replace(/\s+/g, " ").trim();
  if (!name) return null;
  const known = SCHOOL_STYLES[name.toLowerCase()];
  if (known) return known;
  const words = name.split(/[\s,-]+/).filter((word) => word && !FILLER.has(word.toLowerCase()));
  const general = words.filter((word) => !/^(college|university|school|institute)$/i.test(word));
  const letters = (words[0] && /^university$/i.test(words[0]) ? words : general.length ? general : words).map((word) => word[0]).join("").toUpperCase().slice(0, 3) || name[0].toUpperCase();
  const hash = [...name].reduce((sum, char) => sum * 31 + char.charCodeAt(0) >>> 0, 7);
  return { color: FALLBACK_COLORS[hash % FALLBACK_COLORS.length], text: "#FFFFFF", letters: letters.length === 2 && general.length === 1 ? letters[0] : letters };
}
function shade(hex, amount) {
  const value = parseInt(hex.replace("#", ""), 16);
  const target = amount > 0 ? 255 : 0;
  const mix = (channel) => Math.round(channel + (target - channel) * Math.abs(amount));
  const [r, g, b] = [value >> 16 & 255, value >> 8 & 255, value & 255].map(mix);
  return `#${(1 << 24 | r << 16 | g << 8 | b).toString(16).slice(1).toUpperCase()}`;
}
var GLYPHS = {
  A: "010101111101101",
  B: "110101110101110",
  C: "011100100100011",
  D: "110101101101110",
  E: "111100110100111",
  F: "111100110100100",
  G: "011100101101011",
  H: "101101111101101",
  I: "111010010010111",
  J: "001001001101010",
  K: "101101110101101",
  L: "100100100100111",
  M: "101111111101101",
  N: "110101101101101",
  O: "010101101101010",
  P: "110101110100100",
  Q: "010101101110011",
  R: "110101110101101",
  S: "011100010001110",
  T: "111010010010010",
  U: "101101101101111",
  V: "101101101101010",
  W: "101101111111101",
  X: "101101010101101",
  Y: "101101010010010",
  Z: "111001010100111"
};
var WIDE = { M: "1000111011101011000110001", W: "1000110001101011101110001" };
var glyphRows = (letter2) => {
  const wide = WIDE[letter2];
  const bits = wide ?? GLYPHS[letter2] ?? GLYPHS.O;
  const width = wide ? 5 : 3;
  return { width, rows: Array.from({ length: 5 }, (_, row) => bits.slice(row * width, row * width + width)) };
};
var ART_W = 40;
var ART_H = 30;
function spiderPalette(look) {
  if (look.skin === "classic") {
    return {
      o: "#000000",
      b: "#6E5B6E",
      h: "#B48FAE",
      d: "#4E3549",
      a: "#3D8BFF",
      e: "#3D8BFF",
      k: "#7E6580",
      K: "#5A4258",
      l: "#6E5B6E",
      L: "#4E3549",
      w: "#FFFFFF",
      m: "#1A0E14",
      f: "#F7F7F8",
      p: "#965E8C",
      t: "#FFFFFF",
      r: "#4E3549"
    };
  }
  const skin = SKINS.find((item) => item.id === look.skin) ?? SKINS[0];
  const style = look.skin === "school" ? schoolStyle(look.school) : null;
  const body = skin.color;
  const back2 = style?.color ?? body;
  return {
    o: "#000000",
    b: back2,
    h: shade(back2, 0.35),
    d: shade(back2, -0.3),
    k: shade(body, 0.12),
    K: shade(body, -0.15),
    l: body,
    L: shade(body, -0.3),
    a: skin.id === "school" ? "#3D8BFF" : shade(body, 0.55),
    e: skin.id === "school" ? "#3D8BFF" : shade(body, 0.55),
    t: style?.text ?? "#FFFFFF",
    r: shade(back2, -0.45),
    m: "#1A0E14",
    w: "#FFFFFF",
    f: "#F7F7F8",
    p: "#965E8C"
  };
}
function spiderArt(open, look, angry = false) {
  const W2 = ART_W, H2 = ART_H;
  const g = Array.from({ length: H2 }, () => Array(W2).fill(""));
  const set = (x, y, c) => {
    if (x >= 0 && x < W2 && y >= 0 && y < H2) g[y][x] = c;
  };
  const brush = (x, y, c) => {
    set(x, y, c);
    set(x + 1, y, c);
    set(x, y + 1, c);
    set(x + 1, y + 1, c);
  };
  const line = (x0, y0, x1, y1, c) => {
    const dx = Math.abs(x1 - x0), sx = x0 < x1 ? 1 : -1, dy = -Math.abs(y1 - y0), sy = y0 < y1 ? 1 : -1;
    let err = dx + dy;
    for (; ; ) {
      brush(x0, y0, c);
      if (x0 === x1 && y0 === y1) break;
      const e2 = 2 * err;
      if (e2 >= dy) {
        err += dy;
        x0 += sx;
      }
      if (e2 <= dx) {
        err += dx;
        y0 += sy;
      }
    }
  };
  const legs = [[[13, 10], [7, 4], [3, 13]], [[12, 13], [5, 9], [1, 19]], [[12, 16], [5, 15], [2, 24]], [[14, 19], [9, 21], [6, 27]]];
  for (const leg of legs) for (const side of [0, 1]) {
    const [hip, knee, foot] = leg.map((p) => side ? [W2 - 2 - p[0], p[1]] : p);
    line(hip[0], hip[1], knee[0], knee[1], "l");
    line(knee[0], knee[1], foot[0], foot[1], "L");
    set(knee[0] + (side ? 1 : 0), knee[1], "h");
  }
  const blob = (cx, cy, rx, ry, base, hi, lo) => {
    for (let y = 0; y < H2; y++) for (let x = 0; x < W2; x++) {
      const nx = (x + 0.5 - cx) / rx, ny = (y + 0.5 - cy) / ry;
      if (nx * nx + ny * ny <= 1) g[y][x] = nx < -0.25 && ny < -0.3 ? hi : ny > 0.55 || nx > 0.6 ? lo : base;
    }
  };
  blob(20, 9, 8.6, 7.2, "b", "h", "d");
  const style = look.skin === "school" ? schoolStyle(look.school) : null;
  if (!style) {
    set(17, 4, "w");
    set(18, 4, "h");
  }
  if (style) {
    for (let x = 13; x <= 27; x++) if (g[12][x] === "b" || g[12][x] === "d" || g[12][x] === "h") set(x, 12, x % 2 ? "r" : "d");
    const glyphs = style.letters.slice(0, 3).split("").map(glyphRows);
    const width = glyphs.reduce((sum, glyph) => sum + glyph.width + 1, -1);
    let left = 20 - Math.ceil(width / 2);
    for (const glyph of glyphs) {
      glyph.rows.forEach((row, y) => row.split("").forEach((bit, x) => {
        if (bit === "1") set(left + x, 5 + y, "t");
      }));
      left += glyph.width + 1;
    }
  } else {
    for (const [x, y] of [[19, 7], [20, 7], [18, 8], [21, 8], [19, 9], [20, 9], [19, 10], [20, 10]]) set(x, y, "a");
  }
  blob(20, 17.8, 6.8, 5.2, "k", "h", "K");
  for (const [x, y] of [[16, 15], [17, 15], [16, 16], [17, 16], [22, 15], [23, 15], [22, 16], [23, 16]]) set(x, y, "e");
  set(16, 15, "w");
  set(22, 15, "w");
  set(14, 14, "e");
  set(25, 14, "e");
  if (angry) {
    for (const [x, y] of [[16, 15], [17, 15], [16, 16], [17, 16], [22, 15], [23, 15], [22, 16], [23, 16], [14, 14], [25, 14]]) set(x, y, "R");
    set(17, 16, "w");
    set(22, 16, "w");
    for (const [x, y] of [[15, 13], [16, 13], [17, 14], [18, 14], [24, 13], [23, 13], [22, 14], [21, 14]]) set(x, y, "m");
  }
  if (open) {
    for (let x = 17; x <= 22; x++) {
      set(x, 19, "m");
      set(x, 20, "m");
    }
    for (let x = 18; x <= 21; x++) set(x, 21, "m");
    set(19, 21, "p");
    set(20, 21, "p");
    set(18, 19, "f");
    set(18, 20, "f");
    set(21, 19, "f");
    set(21, 20, "f");
  } else {
    for (let x = 18; x <= 21; x++) set(x, 20, "m");
    set(18, 21, "f");
    set(21, 21, "f");
  }
  const out = g.map((row) => row.slice());
  for (let y = 0; y < H2; y++) for (let x = 0; x < W2; x++) {
    if (g[y][x]) continue;
    if ([[1, 0], [-1, 0], [0, 1], [0, -1]].some(([dx, dy]) => g[y + dy]?.[x + dx])) out[y][x] = "o";
  }
  return out;
}
function artRects(grid, palette) {
  let svg = "";
  for (let y = 0; y < grid.length; y++) {
    let x = 0;
    while (x < grid[y].length) {
      const c = grid[y][x];
      if (!c) {
        x++;
        continue;
      }
      let w = 1;
      while (x + w < grid[y].length && grid[y][x + w] === c) w++;
      svg += `<rect x="${x}" y="${y}" width="${w}" height="1" fill="${palette[c]}"/>`;
      x += w;
    }
  }
  return svg;
}

// extension/src/shared/hero-spider.ts
function heroSpiderSvg(look = { skin: "classic" }) {
  const palette = spiderPalette(look);
  return `<svg viewBox="0 0 ${ART_W} ${ART_H}" width="80" height="60" shape-rendering="crispEdges" aria-hidden="true"><g class="mouth-shut">${artRects(spiderArt(false, look), palette)}</g><g class="mouth-open">${artRects(spiderArt(true, look), palette)}</g><g class="mouth-angry">${artRects(spiderArt(true, look, true), { ...palette, R: "#FF4D4D" })}</g></svg>`;
}
var TYPING_W = 60;
var TYPING_H = 48;
var LAPTOP = [[13, 27, 34, 16, "#000000"], [14, 28, 32, 14, "#C9CDD6"], [14, 28, 32, 2, "#E6E9EF"], [14, 40, 32, 2, "#A9AEB9"], [8, 43, 44, 3, "#000000"], [9, 43, 42, 2, "#9AA0AC"], [26, 43, 8, 1, "#7D8390"]].map(([x, y, w, h, fill]) => `<rect x="${x}" y="${y}" width="${w}" height="${h}" fill="${fill}"/>`).join("");
function typingSpiderSvg(width, look = { skin: "classic" }) {
  const palette = spiderPalette(look);
  return `<svg viewBox="0 0 ${TYPING_W} ${TYPING_H}" width="${width}" height="${Math.round(width * TYPING_H / TYPING_W)}" shape-rendering="crispEdges" aria-hidden="true" style="color:${palette.l}"><g transform="translate(${(TYPING_W - ART_W) / 2} 1)"><g class="spider">${artRects(spiderArt(false, look), palette)}</g></g><rect x="18" y="26" width="24" height="2" fill="#3D8BFF" opacity=".35" class="glow"/>` + LAPTOP + `<rect x="29" y="34" width="2" height="2" fill="#3D8BFF" class="logo"/><g class="foot left"><rect x="10" y="40" width="4" height="3" fill="#000"/><rect x="11" y="40" width="2" height="2" fill="currentColor"/></g><g class="foot right"><rect x="46" y="40" width="4" height="3" fill="#000"/><rect x="47" y="40" width="2" height="2" fill="currentColor"/></g></svg>`;
}

// extension/src/shared/password.ts
var PASSWORD_RULES = [
  { label: "A numeric character", test: (value) => /\d/.test(value) },
  { label: "An uppercase character", test: (value) => /[A-Z]/.test(value) },
  { label: "An alphabetic character", test: (value) => /[A-Za-z]/.test(value) },
  { label: "A special character", test: (value) => /[^A-Za-z0-9\s]/.test(value) },
  { label: "A lowercase character", test: (value) => /[a-z]/.test(value) },
  { label: "A minimum of 8 characters", test: (value) => value.length >= 8 }
];
function unmetRules(value) {
  return PASSWORD_RULES.filter((rule) => !rule.test(value)).map((rule) => rule.label);
}

// extension/src/shared/sprite.ts
var W = 20;
var H = 17;
var COLORS = { o: "#000000", b: "#2B2531", s: "#4A4252", l: "#1B171F", w: "#EAF6F2", p: "#1B171F", c: "#F2949E" };
function spiderGrid(step) {
  const g = Array.from({ length: H }, () => Array(W).fill(""));
  const set = (x, y, c) => {
    if (x >= 0 && x < W && y >= 0 && y < H) g[y][x] = c;
  };
  const legs = step === 0 ? [[[6, 6], [5, 5], [4, 4], [4, 3], [3, 2]], [[5, 8], [4, 7], [3, 7], [2, 7], [1, 8]], [[5, 10], [4, 10], [3, 11], [2, 11], [2, 12]], [[6, 12], [5, 13], [4, 14], [4, 15]]] : [[[6, 6], [5, 5], [5, 4], [4, 3], [4, 2]], [[5, 8], [4, 8], [3, 8], [2, 8], [1, 9]], [[5, 10], [4, 11], [3, 11], [3, 12], [2, 13]], [[6, 12], [6, 13], [5, 14], [5, 15]]];
  for (const leg of legs) for (const [x, y] of leg) {
    set(x, y, "l");
    set(W - 1 - x, y, "l");
  }
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
    const nx = (x + 0.5 - 10) / 4.6, ny = (y + 0.5 - 9.2) / 5;
    if (nx * nx + ny * ny <= 1) set(x, y, "b");
  }
  for (const ex of [6, 11]) for (let dx = 0; dx < 3; dx++) for (let dy = 0; dy < 3; dy++) set(ex + dx, 5 + dy, "w");
  set(7, 6, "p");
  set(12, 6, "p");
  set(5, 8, "c");
  set(14, 8, "c");
  set(11, 11, "s");
  const out = g.map((row) => row.slice());
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
    if (g[y][x]) continue;
    if ([[1, 0], [-1, 0], [0, 1], [0, -1]].some(([dx, dy]) => g[y + dy]?.[x + dx])) out[y][x] = "o";
  }
  return out;
}
function spiderRects(step, colors = {}) {
  const out = spiderGrid(step);
  const palette = { ...COLORS, ...colors };
  let rects = "";
  for (let y = 0; y < H; y++) {
    let x = 0;
    while (x < W) {
      const c = out[y][x];
      if (!c) {
        x++;
        continue;
      }
      let w = 1;
      while (x + w < W && out[y][x + w] === c) w++;
      rects += `<rect x="${x}" y="${y}" width="${w}" height="1" fill="${palette[c]}"/>`;
      x += w;
    }
  }
  return rects;
}

// extension/src/shared/types.ts
var AUTOFILL_ENABLED = false;

// lib/apply/stats.ts
var NO_RESPONSE_DAYS = 28;
var isApplied = (status) => status === "submitted" || status === "applied_manual";
function stageOf(app2, now = Date.now()) {
  if (!isApplied(app2.status)) return "in_progress";
  if (app2.fillReport?.outcome) return app2.fillReport.outcome;
  const last = Math.max(Date.parse(app2.submittedAt ?? app2.createdAt ?? "") || 0, Date.parse(app2.fillReport?.lastEmailAt ?? "") || 0);
  return last && now - last > NO_RESPONSE_DAYS * 864e5 ? "no_response" : "submitted";
}
var countsTowardGoals = (app2) => !app2.fillReport?.notCounted;
var appliedOn = (app2) => new Date(app2.submittedAt ?? app2.createdAt);
function dayKey(date) {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
}
function weekStart(now) {
  const start = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  start.setDate(start.getDate() - (start.getDay() + 6) % 7);
  return start;
}

// lib/apply/follow-ups.ts
var FOLLOW_UP_BUSINESS_DAYS = 5;
function businessDaysBetween(from, to) {
  let days = 0;
  const day = new Date(Date.UTC(from.getUTCFullYear(), from.getUTCMonth(), from.getUTCDate()));
  const end = Date.UTC(to.getUTCFullYear(), to.getUTCMonth(), to.getUTCDate());
  while (day.getTime() < end) {
    day.setUTCDate(day.getUTCDate() + 1);
    const weekday = day.getUTCDay();
    if (weekday !== 0 && weekday !== 6) days += 1;
  }
  return days;
}
function followUpsDue(apps, now = /* @__PURE__ */ new Date()) {
  return apps.flatMap((app2) => (app2.contacts ?? []).flatMap((person) => {
    const at = app2.fillReport?.emailedAt?.[person.id];
    if (person.outreachStatus !== "emailed" || !at) return [];
    const days = businessDaysBetween(new Date(at), now);
    return days >= FOLLOW_UP_BUSINESS_DAYS ? [{ applicationId: app2.id, contactId: person.id, name: person.name, company: app2.company, title: app2.title, emailedAt: at, days }] : [];
  })).sort((a, b) => a.emailedAt.localeCompare(b.emailedAt));
}

// lib/apply/progress.ts
var STEPS = ["Applied", "Reach out", "Waiting", "Follow up", "Interview"];
var STEP_LABEL = ["Not applied", "Reach out", "Waiting", "Follow up", "Waiting", "Interview"];
var applied = (job) => job.status === "submitted" || job.status === "applied_manual";
var emailedCount = (job) => Math.max(job.fillReport?.reachedOut?.count ?? 0, job.contacts.filter((person) => person.outreachStatus !== "not_contacted").length);
function progressOf(job, followedUp = false, now = /* @__PURE__ */ new Date()) {
  const stage = stageOf(job);
  const company = job.companyMissing ? "the company" : job.company;
  if (!applied(job)) return { done: 0, due: false, ended: null, next: "Apply, then it moves along here." };
  if (stage === "offer") return { done: 5, due: false, ended: "Offer", next: "You got an offer." };
  if (stage === "interviewing" || stage === "assessment") return { done: 5, due: false, ended: null, next: stage === "assessment" ? "You have an assessment." : "You're interviewing." };
  const emailed = emailedCount(job);
  const replied = job.contacts.some((person) => person.outreachStatus === "replied");
  const progress = !emailed ? { done: 1, due: false, ended: null, next: `Email someone at ${company}.` } : followUpsDue([job], now).length ? { done: 3, due: true, ended: null, next: "A follow-up is due." } : replied || followedUp ? { done: 4, due: false, ended: null, next: replied ? "Someone replied. Waiting on an interview." : "Followed up. Waiting on an interview." } : { done: 2, due: false, ended: null, next: `Emailed ${emailed} ${emailed === 1 ? "person" : "people"}. Waiting on a reply.` };
  return stage === "rejected" ? { ...progress, due: false, ended: "Rejected", next: "This one said no." } : progress;
}

// lib/apply/next-up.ts
var DAY = 864e5;
var FINISH_DAYS = 30;
var UPDATE_DAYS = 14;
var SHOWN = 5;
function daysAgo(at, now) {
  const start = (date) => new Date(date.getFullYear(), date.getMonth(), date.getDate()).getTime();
  return Math.round((start(now) - start(new Date(at))) / DAY);
}
function dayWords(at, now) {
  const days = daysAgo(at, now);
  if (days <= 0) return "Today";
  if (days === 1) return "Yesterday";
  return new Date(at).toLocaleDateString("en-US", { month: "short", day: "numeric" });
}
function nextUp(apps, options = {}) {
  const shown = options.shown ?? SHOWN;
  const now = options.now ?? /* @__PURE__ */ new Date();
  const role = (app2) => app2.titleMissing ? "" : app2.title;
  const named = apps.filter((app2) => !app2.companyMissing);
  const goal = { today: options.goal?.today ?? 0, daily: options.goal?.daily ?? 0, week: options.goal?.week ?? 0, weekly: options.goal?.weekly ?? 0 };
  const goalItems = [];
  const leftToday = Math.max(0, goal.daily - goal.today);
  const leftWeek = Math.max(0, goal.weekly - goal.week);
  if (leftToday > 0 || leftWeek > 0) {
    const left = leftToday || leftWeek;
    goalItems.push({
      key: `goal:${goal.today}:${goal.week}`,
      kind: "goal",
      title: `Apply to ${left} more ${left === 1 ? "job" : "jobs"}${leftToday ? " today" : " this week"}`,
      detail: [goal.daily ? `${goal.today} of ${goal.daily} today` : "", goal.weekly ? `${goal.week} of ${goal.weekly} this week` : ""].filter(Boolean).join(" \xB7 "),
      when: `${left} to go`,
      action: "Find a job"
    });
  }
  const replied = named.filter((app2) => stageOf(app2) === "follow_up").map((app2) => {
    const change = [...app2.fillReport?.statusHistory ?? []].reverse().find((item) => item.status !== "applied" && item.status !== "incomplete");
    return { app: app2, at: Date.parse(change?.at ?? app2.fillReport?.lastEmailAt ?? app2.submittedAt ?? app2.createdAt), summary: change?.summary ?? "" };
  }).sort((a, b) => b.at - a.at);
  const followItems = replied.map(({ app: app2, at, summary }) => ({
    key: `reply:${app2.id}`,
    kind: "reply",
    applicationId: app2.id,
    title: `Follow up with ${app2.company}`,
    detail: [role(app2), summary].filter(Boolean).join(" \xB7 "),
    when: dayWords(at, now),
    action: "Open job"
  }));
  for (const due of followUpsDue(named, now)) {
    followItems.push({
      key: `follow:${due.contactId}`,
      kind: "follow_up",
      applicationId: due.applicationId,
      contactId: due.contactId,
      title: `Follow up with ${due.name}`,
      detail: `${due.company} \xB7 emailed ${due.days} business days ago`,
      when: `${due.days} business days`,
      action: "Write follow-up"
    });
  }
  const appItems = named.filter((app2) => !isApplied(app2.status) && now.getTime() - Date.parse(app2.createdAt) <= FINISH_DAYS * DAY).sort((a, b) => Date.parse(b.createdAt) - Date.parse(a.createdAt)).map((app2) => ({
    key: `finish:${app2.id}`,
    kind: "finish",
    applicationId: app2.id,
    title: role(app2) ? `Finish ${role(app2)} at ${app2.company}` : `Finish your application at ${app2.company}`,
    detail: "Started, not submitted",
    when: "In progress",
    action: "Finish application"
  }));
  const dueIds = new Set(followItems.map((item) => item.applicationId));
  for (const app2 of named.filter((app3) => ["submitted", "no_response"].includes(stageOf(app3, now.getTime())) && !dueIds.has(app3.id)).filter((app3) => now.getTime() - Date.parse(app3.fillReport?.lastEmailAt ?? app3.submittedAt ?? app3.createdAt) >= UPDATE_DAYS * DAY).sort((a, b) => Date.parse(a.submittedAt ?? a.createdAt) - Date.parse(b.submittedAt ?? b.createdAt))) {
    appItems.push({
      key: `update:${app2.id}`,
      kind: "update",
      applicationId: app2.id,
      title: `Heard back from ${app2.company}?`,
      detail: [role(app2), `applied ${daysAgo(Date.parse(app2.submittedAt ?? app2.createdAt), now)} days ago`].filter(Boolean).join(" \xB7 "),
      when: "Update status",
      action: "Update status"
    });
  }
  return {
    goals: { ...goal, items: goalItems },
    follow_ups: { replied: replied.length, count: followItems.length, items: followItems.slice(0, shown) },
    applications: { count: appItems.length, items: appItems.slice(0, shown) }
  };
}

// extension/src/shared/reminders.ts
var MAX_FOLLOW_UPS = 2;
var SENT_ASK_MS = 60 * 60 * 1e3;
var DAY2 = 864e5;
function goalCounts(tracker, now) {
  const dayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
  const weekStart2 = new Date(dayStart - (now.getDay() + 6) % 7 * DAY2).getTime();
  const applied2 = tracker.jobs.filter((job) => isApplied(job.status) && !job.fillReport?.notCounted).map((job) => Date.parse(job.submittedAt ?? job.createdAt));
  const weekly = tracker.weeklyGoal ?? 0;
  return { today: applied2.filter((at) => at >= dayStart).length, daily: weekly ? Math.ceil(weekly / 5) : 0, week: applied2.filter((at) => at >= weekStart2).length, weekly };
}
function reminders(tracker, marks, opened, followUps, now = /* @__PURE__ */ new Date()) {
  const next = nextUp(tracker.jobs, { now, goal: goalCounts(tracker, now), shown: 100 });
  const hidden = (key) => Boolean(marks[key]?.done || marks[key]?.until && marks[key].until > now.getTime());
  const contact = (id) => tracker.jobs.flatMap((job) => job.contacts).find((person) => person.id === id);
  const sent = Object.entries(opened).filter(([id, item]) => now.getTime() - item.at >= SENT_ASK_MS && (item.followUp || contact(id)?.outreachStatus === "not_contacted")).map(([id, item]) => ({
    key: `sent:${id}:${item.at}`,
    kind: "sent",
    applicationId: item.applicationId,
    contactId: id,
    title: `Did you send your ${item.followUp ? "follow-up" : "email"} to ${item.name}?`,
    detail: item.company,
    when: "",
    action: "Yes, I sent it"
  }));
  const follow = next.follow_ups.items.map((item) => item.kind === "follow_up" && item.contactId && (followUps[item.contactId] ?? 0) >= MAX_FOLLOW_UPS ? { ...item, title: `No reply from ${item.title.replace(/^Follow up with /, "")}`, detail: `${item.detail} \xB7 followed up ${MAX_FOLLOW_UPS} times`, action: "Stop following up" } : item);
  const today = [...sent, ...follow, ...next.applications.items].filter((item) => !hidden(item.key));
  return { goal: next.goals, items: today };
}
function dueCount(items) {
  return items.filter((item) => item.kind !== "finish").length;
}

// extension/src/shared/tracker-view.ts
var escape = (text) => text.replace(/[&<>"']/g, (char) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[char]);
var ask = (message) => chrome.runtime.sendMessage(message);
var short = (text, max = 60) => text.length > max ? `${text.slice(0, max - 1).trimEnd()}\u2026` : text;
var store = {
  tracker: null,
  error: "",
  loading: false,
  loadedAt: 0,
  detected: null,
  marks: {},
  opened: {},
  followUps: {},
  mailer: "gmail",
  /** What happened last, per job: "Copied", an error. */
  notes: {},
  busy: /* @__PURE__ */ new Set()
};
var host = { redraw: () => void 0, openJob: () => void 0, upgradeUrl: () => "" };
function setHost(next) {
  host = next;
}
var redraw = () => host.redraw();
async function loadTracker(fresh = false) {
  if (store.loading) return;
  store.loading = true;
  const [result, local, detected] = await Promise.all([
    ask({ type: "tracker", fresh }).catch(() => ({ ok: false, error: "Couldn't reach Unnepo." })),
    chrome.storage.local.get(["reminderMarks", "openedEmails", "followUps", "mailer"]),
    ask({ type: "detected-list" }).catch(() => ({ ok: false, list: [] }))
  ]);
  store.loading = false;
  store.loadedAt = Date.now();
  if (result.ok && "tracker" in result && result.tracker) {
    store.tracker = result.tracker;
    store.error = "";
  } else store.error = result.error ?? "Couldn't load your jobs.";
  store.marks = local.reminderMarks ?? {};
  store.opened = local.openedEmails ?? {};
  store.followUps = local.followUps ?? {};
  store.mailer = local.mailer ?? "gmail";
  store.detected = detected.list ?? [];
  host.redraw();
  pollWhileFinding();
}
function ensureTracker(maxAge = 2e4) {
  if (!store.loading && (!store.tracker || Date.now() - store.loadedAt > maxAge)) void loadTracker();
}
var pollTimer = 0;
function pollWhileFinding() {
  clearTimeout(pollTimer);
  if (store.tracker?.jobs.some((job) => job.contactsStatus === "finding" || job.contactsStatus === "writing")) pollTimer = window.setTimeout(() => void loadTracker(true), 4e3);
}
var jobById = (id) => store.tracker?.jobs.find((job) => job.id === id) ?? null;
var isAppliedJob = (job) => job.status === "submitted" || job.status === "applied_manual";
var emailedCount2 = (job) => Math.max(job.fillReport?.reachedOut?.count ?? 0, job.contacts.filter((person) => person.outreachStatus !== "not_contacted").length);
var needsFirstEmail = (job) => {
  if (!isAppliedJob(job) || emailedCount2(job)) return false;
  const stage = stageOf(job);
  return stage !== "rejected" && stage !== "offer";
};
function progressOf2(job, now = /* @__PURE__ */ new Date()) {
  return progressOf(job, job.contacts.some((person) => (store.followUps[person.id] ?? 0) > 0), now);
}
function progressLine(job) {
  const progress = progressOf2(job);
  const steps = STEPS.map((label, index) => {
    const state = index < progress.done ? "done" : index === progress.done && !progress.ended ? progress.due ? "due" : "now" : "";
    return `<li class="step ${state}"${state === "now" || state === "due" ? ' aria-current="step"' : ""}><i aria-hidden="true">${state === "done" ? "\u2713" : ""}</i>${label}</li>`;
  }).join("");
  return `<div class="progress${progress.ended ? ` ended ${progress.ended.toLowerCase()}` : ""}">
    <ol class="steps-line" aria-label="Progress">${steps}</ol>
    <p class="progress-next${progress.due ? " due" : ""}">${progress.ended ? `<span class="status${progress.ended === "Offer" ? " done" : ""}">${progress.ended}</span> ` : ""}${escape(progress.next)}</p>
  </div>`;
}
function progressDots(job) {
  const progress = progressOf2(job);
  const bars = STEPS.map((_, index) => `<i class="${index < progress.done ? "d" : index === progress.done && !progress.ended ? progress.due ? "w" : "n" : ""}"></i>`).join("");
  const label = progress.ended ?? STEP_LABEL[progress.done];
  return `<span class="dots-wrap"><span class="dots" aria-hidden="true">${bars}</span><span class="dots-label${progress.due ? " due" : progress.ended === "Offer" || progress.done >= 5 ? " ok" : ""}">${escape(label)}</span></span>`;
}
var ROLE_LABEL = { alumni: "Alum", recruiter: "Recruiter", department: "Team", team_member: "Team", poster: "Posted the job", job_poster: "Posted the job" };
var AVATAR = `<span class="avatar" aria-hidden="true"><svg viewBox="0 0 24 24" fill="currentColor"><circle cx="12" cy="9" r="4.2"/><path d="M3.5 24c.8-5 4.2-8 8.5-8s7.7 3 8.5 8z"/></svg></span>`;
function freeRow(name, title, role) {
  const label = ROLE_LABEL[role] ?? role;
  const main = name || title || label;
  const sub = name ? [title || label] : [title ? label : "", "Name hidden"];
  return `<li class="person compact">${AVATAR}
    <div class="person-text"><span class="person-name" title="${escape(main)}">${escape(main)}</span><span class="sub">${escape(sub.filter(Boolean).join(" \xB7 "))}</span></div>
    <span class="pro-tag" title="Included with Pro">Pro</span><button type="button" class="solid" data-upgrade>Show person</button></li>`;
}
var EMAIL_SOURCE = {
  apollo: "Verified",
  hunter: "Verified",
  pattern: "Verified",
  job_posting: "From the job posting",
  website: "From the company's website",
  likely: "Likely: follows the company's format, not checked",
  cant_check: "Can't be checked: the company accepts every address",
  guess: "Best guess"
};
var when = (at) => {
  const date = new Date(at);
  return date.toLocaleDateString("en-US", { month: "short", day: "numeric", ...date.getFullYear() === (/* @__PURE__ */ new Date()).getFullYear() ? {} : { year: "numeric" } });
};
var MAX_LINK = 2e3;
function composeLink(mailer, to, subject, body) {
  const q = (pairs) => Object.entries(pairs).filter(([, value]) => value).map(([key, value]) => `${key}=${encodeURIComponent(value)}`).join("&");
  const build = (text) => mailer === "gmail" ? `https://mail.google.com/mail/?${q({ view: "cm", fs: "1", to, su: subject, body: text })}` : mailer === "outlook" ? `https://outlook.office.com/mail/deeplink/compose?${q({ to, subject, body: text })}` : `mailto:${encodeURIComponent(to).replace(/%40/g, "@")}?${q({ subject, body: text })}`;
  const full = build(body);
  return full.length <= MAX_LINK ? { url: full, cut: false } : { url: build(""), cut: true };
}
var MAILER_NAME = { gmail: "Gmail", outlook: "Outlook", mailto: "your mail app" };
var openPeople = /* @__PURE__ */ new Set();
var justOpened = /* @__PURE__ */ new Map();
var drafts = {};
var websites = {};
var editing = { jobId: "", title: "", company: "", url: "", busy: false, error: "" };
function jobPage(job, focus) {
  if (focus) openPeople.add(focus);
  const applied2 = isAppliedJob(job);
  const stage = stageOf(job);
  const pick = (value, label) => `<option value="${value}"${(stage === "no_response" ? "submitted" : stage) === value ? " selected" : ""}>${label}</option>`;
  const note = store.notes[job.id];
  const status = applied2 ? `<select class="status-mini" data-outcome="${job.id}" aria-label="Status">${pick("submitted", "Applied")}${pick("follow_up", "Follow up")}${stage === "assessment" ? pick("assessment", "Assessment") : ""}${pick("interviewing", "Interviewing")}${pick("offer", "Offer")}${pick("rejected", "Rejected")}</select>` : `<button type="button" class="status-mini" data-mark-applied="${job.id}">I applied</button>`;
  return `
    <section class="page job-view" aria-label="${escape(job.title)}">
      <div>
        <div class="job-title-row">
          <div class="job-name small-name">${escape(job.titleMissing ? "Job title missing" : job.title)}</div>
          ${status}
        </div>
        <div class="job-detail">${escape(job.companyMissing ? "Company missing" : job.company)}${job.location ? ` \xB7 ${escape(job.location)}` : ""}</div>
        <div class="sub">${applied2 ? `Applied ${when(job.submittedAt ?? job.createdAt)}${job.confirmation?.confidence === "confirmed" ? " \xB7 the site confirmed it" : ""}` : `Saved ${when(job.createdAt)}`}</div>
      </div>
      ${progressLine(job)}
      ${editing.jobId === job.id ? editForm(job) : ""}
      <div class="links">
        ${job.url ? `<a class="link" href="${escape(job.url)}" target="_blank" rel="noreferrer">Job posting \u2197</a>` : ""}
        ${editing.jobId === job.id ? "" : `<button type="button" class="link" data-edit-job="${job.id}">Edit job info</button>`}
        <button type="button" class="link" data-delete-job="${job.id}">Delete job</button>
      </div>
      ${note ? `<p class="small" role="status">${escape(note)}</p>` : ""}
    </section>
    ${peopleCard(job)}
    ${applied2 ? `<section class="page" aria-label="People you emailed">${reachPicker(job)}</section>` : ""}`;
}
function editForm(job) {
  return `
      <div class="edit-job letter-form flat" role="group" aria-label="Edit job info">
        <label class="question"><span class="q-label">Job title</span><input class="field" data-edit="title" maxlength="200" value="${escape(editing.title)}"></label>
        <label class="question"><span class="q-label">Company</span><input class="field" data-edit="company" maxlength="200" value="${escape(editing.company)}"></label>
        <label class="question"><span class="q-label">Job link</span><input class="field" data-edit="url" type="url" maxlength="2000" placeholder="https://\u2026" value="${escape(editing.url)}"></label>
        ${editing.error ? `<p class="small" style="color: var(--warn)" role="alert">${escape(editing.error)}</p>` : ""}
        <div class="links">
          <button type="button" class="solid" data-edit-save="${job.id}" ${editing.busy ? "disabled" : ""}>${editing.busy ? "Saving\u2026" : "Save"}</button>
          <button type="button" class="link" data-edit-cancel>Cancel</button>
        </div>
      </div>`;
}
function reachPicker(job) {
  const count = emailedCount2(job);
  const busy = store.busy.has(`reach:${job.id}`);
  const option2 = (value, label) => {
    const on = value === 3 ? count >= 3 : count === value;
    return `<button type="button" class="seg-btn${on ? " on" : ""}" data-reach="${value}" data-reach-job="${job.id}" aria-pressed="${on}" ${busy ? "disabled" : ""}>${label}</button>`;
  };
  return `<div class="question" role="group" aria-label="People you emailed about this job">
    <span class="q-label">People you emailed</span>
    <div class="seg">${option2(0, "None yet")}${option2(1, "1")}${option2(2, "2")}${option2(3, "3+")}</div>
  </div>`;
}
async function setReached(jobId, count) {
  const key = `reach:${jobId}`;
  store.busy.add(key);
  const job = jobById(jobId);
  if (job) job.fillReport = { ...job.fillReport ?? { outcome: null, peopleReveals: 0 }, reachedOut: count ? { count, at: job.fillReport?.reachedOut?.at ?? (/* @__PURE__ */ new Date()).toISOString() } : void 0 };
  host.redraw();
  const result = await ask({ type: "job-status", applicationId: jobId, reachedOut: count }).catch(() => ({ ok: false, error: "Couldn't reach Unnepo." }));
  store.busy.delete(key);
  store.notes[jobId] = result.ok ? "" : result.error ?? "Couldn't save it.";
  await loadTracker(true);
}
function wireReach(root) {
  root.querySelectorAll("[data-reach-job]").forEach((button) => button.addEventListener("click", () => void setReached(button.dataset.reachJob, Number(button.dataset.reach))));
}
function peopleCard(job) {
  const company = job.companyMissing ? "this company" : job.company;
  const posted = job.postedRecruiter ? `<p class="small">Posted by <strong>${escape(job.postedRecruiter.name)}</strong>${job.postedRecruiter.title ? `, ${escape(job.postedRecruiter.title)}` : ""}${job.postedRecruiter.linkedinUrl ? ` \xB7 <a href="${escape(job.postedRecruiter.linkedinUrl)}" target="_blank" rel="noreferrer">LinkedIn \u2197</a>` : ""}</p>` : "";
  const badge = store.tracker?.peopleBadge;
  const head = `<div class="row-between"><span class="eyebrow">People at ${escape(short(company, 28))}${job.contacts.length ? ` \xB7 ${job.contacts.length}` : ""}</span>${badge ? `<span class="people-count${/^0 /.test(badge) ? " out" : ""}">${escape(badge)}</span>` : ""}</div>`;
  if (!isAppliedJob(job)) {
    return `<section class="page people" aria-label="People">${head}${posted}<p class="note">Once you apply, Unnepo finds who to email here: recruiters, the team, and people from your school.</p></section>`;
  }
  const preview = !job.contacts.length && job.contactsStatus === "done" ? job.fillReport?.peoplePreview : void 0;
  if (preview?.rows.length && store.tracker?.free) {
    const count = (role) => preview.rows.filter((row) => row.role === role).length;
    const words = (n, one, many) => n ? `${n} ${n === 1 ? one : many}` : "";
    const parts = [words(count("recruiter"), "recruiter", "recruiters"), words(count("alumni"), "alum", "alumni"), words(count("department") + count("team_member"), "person on the team", "people on the team")].filter(Boolean);
    return `<section class="page people" aria-label="People">${head}${posted}
      <p class="small">Unnepo found ${escape(parts.join(", ") || `${preview.rows.length} people`)} at ${escape(company)}.</p>
      <ul class="people-list">${preview.rows.map((row) => freeRow(null, row.title, row.role)).join("")}</ul></section>`;
  }
  if (job.contactsStatus === "idle" || preview && !store.tracker?.free) {
    return `<section class="page people" aria-label="People">${head}${posted}
      <p class="note">Recruiters, the team, and people you have something in common with.</p>
      <button type="button" class="btn primary" data-find-people="${job.id}" ${store.busy.has(`find:${job.id}`) ? "disabled" : ""}>Find people</button>
      ${store.tracker?.peopleNote ? `<p class="small" style="color: var(--warn)">${escape(store.tracker.peopleNote)}</p>` : ""}</section>`;
  }
  const stale = job.contactsStatus === "finding" && Date.now() - Date.parse(job.updatedAt) > 2 * 60 * 1e3;
  if ((job.contactsStatus === "finding" || job.contactsStatus === "writing") && !stale) {
    return `<section class="page people" aria-label="People">${head}${posted}<p class="note" role="status">${escape(job.contactsMessage || `Searching for people at ${company}\u2026`)}</p></section>`;
  }
  const none = !job.contacts.length;
  const linkedIn = (label, keywords) => `<a class="link" href="https://www.linkedin.com/search/results/people/?${new URLSearchParams({ keywords })}" target="_blank" rel="noreferrer">${label} on LinkedIn \u2197</a>`;
  return `
    <section class="page people" aria-label="People">${head}${posted}
      ${job.contactsMessage && none ? `<p class="small">${escape(job.contactsMessage)}</p>` : ""}
      ${none ? `
        <p class="note">${stale || job.contactsStatus === "failed" ? "That search didn't finish." : `No one found at ${escape(company)} yet.`}</p>
        <div class="links">${linkedIn("Recruiters", `recruiter ${job.company}`)}${linkedIn("The team", `${job.department || job.title} ${job.company}`)}</div>
        <div class="connect-code"><input class="field" data-website="${job.id}" value="${escape(websites[job.id] ?? "")}" placeholder="Company website, like acme.com" aria-label="Company website"><button type="button" class="solid" data-find-people="${job.id}">Search again</button></div>` : `<ul class="people-list">${job.contacts.map((person, index) => store.tracker?.free && !person.email && job.hidden.includes(person.name.toLowerCase()) ? freeRow(person.name, person.title, person.role) : personRow(job, person, index === job.contacts.findIndex((other) => other.email))).join("")}</ul>`}
    </section>`;
}
function personRow(job, person, first) {
  const key = person.name.toLowerCase();
  const hidden = job.hidden.includes(key);
  const revealsLeft = (job.fillReport?.peopleReveals ?? 0) < 3;
  const open = openPeople.has(person.id);
  const followUps = store.followUps[person.id] ?? 0;
  const due = person.outreachStatus === "emailed" && Boolean(job.fillReport?.emailedAt?.[person.id]);
  const busy = (what) => store.busy.has(`${what}:${person.id}`);
  const draft = drafts[person.id] ?? { subject: person.emailSubject ?? "", body: person.emailBody ?? "" };
  const link = person.email && draft.body ? composeLink(store.mailer, person.email, draft.subject, draft.body) : null;
  const followUp = person.outreachStatus === "emailed" || person.outreachStatus === "no_response";
  const status = { not_contacted: "", emailed: "Emailed", replied: "Replied", no_response: "No reply" }[person.outreachStatus];
  const address = person.email ? link ? `<a class="email-link" href="${escape(link.url)}" ${link.url.startsWith("mailto:") ? "" : 'target="_blank" rel="noreferrer"'} data-email-link="${person.id}" data-cut="${link.cut}" title="Open this email in ${MAILER_NAME[store.mailer]}">${escape(person.email)} \u2197</a>` : `<button type="button" class="email-link" data-write-open="${person.id}" ${busy("write") ? "disabled" : ""} title="Write the email, then open it in ${MAILER_NAME[store.mailer]}">${busy("write") ? "Writing your email\u2026" : `${escape(person.email)} \u2197`}</button>` : hidden ? revealsLeft ? `<button type="button" class="solid" data-reveal="${person.id}" ${busy("reveal") ? "disabled" : ""}>${busy("reveal") ? "Looking\u2026" : "Show person"}</button>` : `<span class="small">You've shown 3 people for this job.</span>` : `<span class="small">No email found</span>`;
  return `
    <li class="person${first ? " first" : ""}">
      <div class="row-between"><span class="person-name">${escape(person.name)} <span class="role">${escape(ROLE_LABEL[person.role] ?? person.role)}</span></span>${status ? `<span class="status${person.outreachStatus === "replied" ? " done" : ""}">${status}</span>` : ""}</div>
      ${person.title ? `<span class="sub">${escape(person.title)}</span>` : ""}
      ${first ? `<span class="small start-here">\u2605 Start here</span>` : ""}
      <div class="person-line">${address}${person.linkedinUrl ? `<a class="link" href="${escape(person.linkedinUrl)}" target="_blank" rel="noreferrer">LinkedIn \u2197</a>` : ""}</div>
      ${person.emailSource && person.email ? `<span class="small"${person.emailSource === "likely" || person.emailSource === "guess" ? ' style="color: var(--warn)"' : ""}>${escape(EMAIL_SOURCE[person.emailSource] ?? "")}</span>` : ""}
      ${justOpened.has(person.id) ? `
        <div class="sent-check" role="status"><span class="small">${justOpened.get(person.id) ? "Sent the follow-up?" : "Sent it?"}</span>
          <button type="button" class="solid" data-sent="${person.id}" data-follow="${justOpened.get(person.id)}">${justOpened.get(person.id) ? "I sent the follow-up" : "I emailed them"}</button></div>` : ""}
      ${person.email && !hidden ? `
        <details class="q-answer" data-person="${person.id}" ${open ? "open" : ""}><summary>${draft.body ? "The email" : "Write the email first"}</summary>
          <div class="letter-form flat">
            ${draft.body ? `<input class="field" data-subject="${person.id}" value="${escape(draft.subject)}" aria-label="Subject" maxlength="200">
            <textarea class="field letter-input" rows="7" data-body="${person.id}" aria-label="Email to ${escape(person.name)}">${escape(draft.body)}</textarea>` : ""}
            <div class="links">
              <button type="button" class="link" data-write="${person.id}" ${busy("write") ? "disabled" : ""}>${busy("write") ? "Writing\u2026" : draft.body ? "Write it again" : "Write email"}</button>
              ${drafts[person.id] ? `<button type="button" class="link" data-save-draft="${person.id}">Save my edits</button>` : ""}
              ${draft.body ? `<button type="button" class="link" data-copy-email="${person.id}">Copy</button>` : ""}
              <button type="button" class="link" data-bounced="${person.id}">It bounced</button>
            </div>
          </div>
        </details>` : ""}
      ${person.email && !hidden ? `<div class="links">
        ${person.outreachStatus === "not_contacted" ? `<button type="button" class="quiet-link" data-status="${person.id}" data-value="emailed">I emailed them</button>` : ""}
        ${followUp && due ? `${followUps < MAX_FOLLOW_UPS ? `<button type="button" class="quiet-link" data-follow-up="${person.id}" ${busy("follow") ? "disabled" : ""}>${busy("follow") ? "Writing\u2026" : "Write follow-up"}</button>` : ""}<button type="button" class="quiet-link" data-status="${person.id}" data-value="replied">They replied</button><button type="button" class="quiet-link" data-status="${person.id}" data-value="no_response">No reply, stop</button>` : ""}
      </div>` : ""}
    </li>`;
}
function wireJobPage(root, job) {
  wireReach(root);
  const say = (text) => {
    store.notes[job.id] = text;
    host.redraw();
  };
  const run = async (what, contactId, message) => {
    store.busy.add(`${what}:${contactId}`);
    host.redraw();
    const result = await ask({ type: "people", body: { applicationId: job.id, contactId, ...message } }).catch(() => ({ ok: false, error: "Couldn't reach Unnepo." }));
    store.busy.delete(`${what}:${contactId}`);
    if (!result.ok) store.notes[job.id] = result.error ?? "Couldn't do that.";
    else store.notes[job.id] = "";
    await loadTracker();
    return result;
  };
  const person = (id) => job.contacts.find((item) => item.id === id);
  root.querySelectorAll("[data-outcome]").forEach((select) => select.addEventListener("change", async () => {
    const outcome = select.value === "submitted" ? null : select.value;
    const result = await ask({ type: "job-status", applicationId: job.id, outcome }).catch(() => ({ ok: false, error: "Couldn't reach Unnepo." }));
    say(result.ok ? "" : result.error ?? "Couldn't change it.");
    void loadTracker();
  }));
  root.querySelector("[data-mark-applied]")?.addEventListener("click", async () => {
    const result = await ask({ type: "job-status", applicationId: job.id, applied: true }).catch(() => ({ ok: false, error: "Couldn't reach Unnepo." }));
    say(result.ok ? "Marked as applied." : result.error ?? "Couldn't change it.");
    void loadTracker();
  });
  root.querySelector("[data-edit-job]")?.addEventListener("click", () => {
    Object.assign(editing, { jobId: job.id, title: job.titleMissing ? "" : job.title, company: job.companyMissing ? "" : job.company, url: job.url ?? "", busy: false, error: "" });
    host.redraw();
  });
  root.querySelectorAll("[data-edit]").forEach((box) => box.addEventListener("input", () => {
    editing[box.dataset.edit] = box.value;
  }));
  root.querySelector("[data-edit-cancel]")?.addEventListener("click", () => {
    editing.jobId = "";
    if (document.activeElement instanceof HTMLElement) document.activeElement.blur();
    host.redraw();
  });
  root.querySelector("[data-edit-save]")?.addEventListener("click", async () => {
    const [title, company, url] = [editing.title.trim(), editing.company.trim(), editing.url.trim()];
    if (title.length < 2) {
      editing.error = "Type the job title.";
      return host.redraw();
    }
    if (company.length < 2) {
      editing.error = "Type the company's name.";
      return host.redraw();
    }
    if (url && !/^https:\/\/\S+\.\S+/i.test(url)) {
      editing.error = "The link should start with https://.";
      return host.redraw();
    }
    editing.busy = true;
    editing.error = "";
    if (document.activeElement instanceof HTMLElement) document.activeElement.blur();
    host.redraw();
    const changes = {
      ...title !== job.title || job.titleMissing ? { title } : {},
      ...company !== job.company || job.companyMissing ? { company } : {},
      ...url !== (job.url ?? "") ? { url } : {}
    };
    const result = Object.keys(changes).length ? await ask({ type: "edit-job", applicationId: job.id, ...changes }).catch(() => ({ ok: false, error: "Couldn't reach Unnepo." })) : { ok: true };
    editing.busy = false;
    if (!result.ok) {
      editing.error = result.error ?? "Couldn't save it.";
      return host.redraw();
    }
    editing.jobId = "";
    store.notes[job.id] = Object.keys(changes).length ? "Saved." : "";
    await loadTracker(true);
  });
  root.querySelector("[data-delete-job]")?.addEventListener("click", async () => {
    if (!confirm(`Delete ${job.title} at ${job.company} from your tracker? Its people go too.`)) return;
    const result = await ask({ type: "delete-job", applicationId: job.id }).catch(() => ({ ok: false, error: "Couldn't reach Unnepo." }));
    if (!result.ok) return say(result.error ?? "Couldn't delete it.");
    await loadTracker();
    host.openJob("");
  });
  root.querySelectorAll("[data-website]").forEach((box) => box.addEventListener("input", () => {
    websites[job.id] = box.value;
  }));
  root.querySelectorAll("[data-find-people]").forEach((button) => button.addEventListener("click", async () => {
    store.busy.add(`find:${job.id}`);
    host.redraw();
    const website = (websites[job.id] ?? "").trim();
    const result = await ask({ type: "people", body: { action: "find", applicationId: job.id, ...website ? { website } : {} } }).catch(() => ({ ok: false, error: "Couldn't reach Unnepo." }));
    store.busy.delete(`find:${job.id}`);
    store.notes[job.id] = result.ok ? "" : result.error ?? "Couldn't start the search.";
    await loadTracker(true);
  }));
  root.querySelectorAll("[data-upgrade]").forEach((button) => button.addEventListener("click", () => {
    if (host.upgradeUrl()) window.open(host.upgradeUrl(), "_blank", "noreferrer");
  }));
  root.querySelectorAll("[data-reveal]").forEach((button) => button.addEventListener("click", () => void run("reveal", button.dataset.reveal, { action: "reveal" })));
  root.querySelectorAll("details[data-person]").forEach((box) => box.addEventListener("toggle", () => {
    if (box.open) openPeople.add(box.dataset.person);
    else openPeople.delete(box.dataset.person);
  }));
  root.querySelectorAll("[data-write]").forEach((button) => button.addEventListener("click", async () => {
    delete drafts[button.dataset.write];
    await run("write", button.dataset.write, { action: "write" });
  }));
  root.querySelectorAll("[data-subject]").forEach((box) => box.addEventListener("input", () => {
    const id = box.dataset.subject;
    const current = drafts[id] ?? { subject: person(id)?.emailSubject ?? "", body: person(id)?.emailBody ?? "" };
    drafts[id] = { ...current, subject: box.value };
  }));
  root.querySelectorAll("[data-body]").forEach((box) => box.addEventListener("input", () => {
    const id = box.dataset.body;
    const current = drafts[id] ?? { subject: person(id)?.emailSubject ?? "", body: person(id)?.emailBody ?? "" };
    drafts[id] = { ...current, body: box.value };
  }));
  root.querySelectorAll("[data-save-draft]").forEach((button) => button.addEventListener("click", async () => {
    const id = button.dataset.saveDraft;
    const draft = drafts[id];
    if (!draft) return;
    const result = await run("save", id, { action: "write", subject: draft.subject, body: draft.body });
    if (result.ok) delete drafts[id];
    if (document.activeElement instanceof HTMLElement) document.activeElement.blur();
    host.redraw();
  }));
  root.querySelectorAll("[data-copy-email]").forEach((button) => button.addEventListener("click", () => {
    const id = button.dataset.copyEmail;
    const body = drafts[id]?.body ?? person(id)?.emailBody ?? "";
    void navigator.clipboard.writeText(body).then(() => say("Copied."), () => say("Couldn't copy. Select the text and copy it."));
  }));
  root.querySelectorAll("[data-bounced]").forEach((button) => button.addEventListener("click", () => {
    if (confirm("Did the email bounce? Unnepo drops this address and checks the company's format again.")) void run("bounced", button.dataset.bounced, { action: "bounced" });
  }));
  const opened = async (contact, followUp) => {
    justOpened.set(contact.id, followUp);
    await ask({ type: "email-opened", contactId: contact.id, applicationId: job.id, name: contact.name, company: job.company, followUp });
    host.redraw();
  };
  const openLink = async (contact, followUp) => {
    const draft = drafts[contact.id] ?? { subject: contact.emailSubject ?? "", body: contact.emailBody ?? "" };
    const link = composeLink(store.mailer, contact.email, draft.subject, draft.body);
    if (link.cut) {
      await navigator.clipboard.writeText(draft.body).catch(() => void 0);
      say("The email was too long for the link: it's copied. Paste it into the email that opened.");
    }
    if (link.url.startsWith("mailto:")) window.location.href = link.url;
    else void chrome.tabs.create({ url: link.url });
    await opened(contact, followUp);
  };
  root.querySelectorAll("[data-email-link]").forEach((anchor) => anchor.addEventListener("click", (event) => {
    const contact = person(anchor.dataset.emailLink);
    if (!contact) return;
    event.preventDefault();
    void openLink(contact, contact.outreachStatus !== "not_contacted");
  }));
  root.querySelectorAll("[data-write-open]").forEach((button) => button.addEventListener("click", async () => {
    const result = await run("write", button.dataset.writeOpen, { action: "write" });
    const contact = result.ok ? jobById(job.id)?.contacts.find((item) => item.id === button.dataset.writeOpen) : null;
    if (contact?.email && contact.emailBody) await openLink(contact, false);
  }));
  root.querySelectorAll("[data-follow-up]").forEach((button) => button.addEventListener("click", async () => {
    const id = button.dataset.followUp;
    delete drafts[id];
    const result = await run("follow", id, { action: "write", followUp: true });
    const contact = result.ok ? jobById(job.id)?.contacts.find((item) => item.id === id) : null;
    openPeople.add(id);
    if (contact?.email && contact.emailBody) await openLink(contact, true);
  }));
  root.querySelectorAll("[data-sent]").forEach((button) => button.addEventListener("click", async () => {
    const id = button.dataset.sent;
    justOpened.delete(id);
    await run("status", id, { action: "status", status: "emailed", followedUp: button.dataset.follow === "true" });
  }));
  root.querySelectorAll("[data-status]").forEach((button) => button.addEventListener("click", () => {
    justOpened.delete(button.dataset.status);
    void run("status", button.dataset.status, { action: "status", status: button.dataset.value });
  }));
}
var SNOOZE_MS = 3 * 864e5;
function todayList() {
  if (!store.tracker) return { goal: null, items: [] };
  return reminders(store.tracker, store.marks, store.opened, store.followUps);
}
function wireReminders(root) {
  const items = todayList().items;
  const find = (key) => items.find((item) => item.key === key);
  const mark = async (key, until) => {
    await ask({ type: "reminder-mark", key, until });
    await loadTracker();
  };
  root.querySelectorAll("[data-remind-mark]").forEach((button) => button.addEventListener("click", () => void mark(button.dataset.remindMark)));
  root.querySelectorAll("[data-remind-snooze]").forEach((button) => button.addEventListener("click", () => void mark(button.dataset.remindSnooze, Date.now() + SNOOZE_MS)));
  root.querySelectorAll("[data-remind]").forEach((button) => button.addEventListener("click", async () => {
    const item = find(button.dataset.remind);
    if (!item) return;
    if (item.kind === "sent" && item.contactId && item.applicationId) {
      const followUp = item.title.includes("follow-up");
      await ask({ type: "people", body: { action: "status", applicationId: item.applicationId, contactId: item.contactId, status: "emailed", followedUp: followUp } });
      return void loadTracker();
    }
    if (item.action === "Stop following up" && item.contactId && item.applicationId) {
      await ask({ type: "people", body: { action: "status", applicationId: item.applicationId, contactId: item.contactId, status: "no_response" } });
      return void loadTracker();
    }
    if (item.kind === "finish" && item.applicationId) {
      const job = jobById(item.applicationId);
      if (job?.url) return void chrome.tabs.create({ url: job.url });
    }
    if (item.applicationId) host.openJob(item.applicationId, item.contactId);
  }));
}
var SURE = { confirmed: "Confirmed", likely: "Likely", pressed: "Pressed Apply", viewed: "Viewed" };
var detectedOpen = false;
var ago = (at) => {
  const minutes = Math.round((Date.now() - at) / 6e4);
  if (minutes < 1) return "just now";
  if (minutes < 60) return `${minutes} min ago`;
  const hours = Math.round(minutes / 60);
  if (hours < 24) return `${hours} h ago`;
  return new Date(at).toLocaleDateString("en-US", { month: "short", day: "numeric" });
};
function detectedMenu() {
  const list = store.detected ?? [];
  const asking = list.filter((item) => item.state === "ask").length;
  const row = (item) => {
    const answered = item.state === "yes" || item.state === "no" || item.state === "undone";
    const actions = item.state === "ask" ? `<button type="button" class="solid" data-detected-yes="${item.id}">\u2713 I applied</button><button type="button" class="quiet-link" data-detected-no="${item.id}">\u2717 No</button>` : item.state === "saved" ? `<span class="status done">Saved \u2713</span><button type="button" class="quiet-link" data-detected-undo="${item.id}">Undo</button>` : item.state === "yes" ? `<span class="status done">Added \u2713</span><button type="button" class="quiet-link" data-detected-undo="${item.id}">Undo</button>` : item.state === "seen" ? `<button type="button" class="solid" data-detected-yes="${item.id}">\u2713 I applied</button>` : item.state === "undone" ? `<span class="status">Undone</span>` : `<span class="status">Not applied</span>`;
    const description = (item.description ?? "").trim();
    const info = description || item.poster || item.url ? `
          <details class="detected-info">
            <summary>Job details</summary>
            ${item.poster ? `<p class="small">Hiring: ${escape(item.poster.name)}${item.poster.title ? ` \xB7 ${escape(short(item.poster.title, 80))}` : ""}</p>` : ""}
            ${description ? `<p class="detected-desc">${escape(description.slice(0, 1500))}${description.length > 1500 ? "\u2026" : ""}</p>` : ""}
            ${/^https:\/\//.test(item.url) ? `<a class="quiet-link" href="${escape(item.url)}" target="_blank" rel="noreferrer">Open the job \u2197</a>` : ""}
          </details>` : "";
    return `
      <li class="detected${answered ? " answered" : ""}">
        <div class="detected-text">
          ${item.applicationId ? `<button type="button" class="detected-title" data-open-job="${item.applicationId}">${escape(short(item.title, 70))}</button>` : `<span class="detected-title">${escape(short(item.title, 70))}</span>`}
          <span class="sub">${escape([item.company, item.site, ago(item.at), SURE[item.sure]].filter(Boolean).join(" \xB7 "))}</span>
          ${item.error ? `<span class="small" style="color: var(--warn)">${escape(item.error)}</span>` : ""}
          ${info}
        </div>
        <div class="detected-actions">${actions}</div>
      </li>`;
  };
  return `
    <details class="detected-menu" id="detected-menu" ${detectedOpen ? "open" : ""}>
      <summary><span>Detected jobs${asking ? ` <span class="count">${asking}</span>` : ""}</span><span class="mono">LAST ${Math.min(5, list.length) || 5}</span></summary>
      ${list.length ? `<ul class="detected-list">${list.slice(0, 5).map(row).join("")}</ul><button type="button" class="quiet-link" id="detected-clear">Clear list</button>` : `<p class="note">Jobs you open or apply to show up here, with their details. Ones the site confirms are saved by themselves.</p>`}
    </details>`;
}
function wireDetected(root) {
  const menu = root.querySelector("#detected-menu");
  menu?.addEventListener("toggle", () => {
    detectedOpen = menu.open;
  });
  const act2 = async (message, item2) => {
    const result = await ask(message).catch(() => ({ ok: false, error: "Couldn't reach Unnepo." }));
    if (!result.ok && result.needsForm && item2 && host.addJob) host.addJob(item2);
    await loadTracker();
  };
  const item = (id) => store.detected?.find((entry) => entry.id === id);
  root.querySelectorAll("[data-detected-yes]").forEach((button) => button.addEventListener("click", () => {
    button.disabled = true;
    void act2({ type: "detected-answer", id: button.dataset.detectedYes, applied: true }, item(button.dataset.detectedYes));
  }));
  root.querySelectorAll("[data-detected-no]").forEach((button) => button.addEventListener("click", () => void act2({ type: "detected-answer", id: button.dataset.detectedNo, applied: false })));
  root.querySelectorAll("[data-detected-undo]").forEach((button) => button.addEventListener("click", () => void act2({ type: "detected-undo", id: button.dataset.detectedUndo })));
  root.querySelector("#detected-clear")?.addEventListener("click", () => void act2({ type: "detected-clear" }));
  root.querySelectorAll(".detected-title[data-open-job]").forEach((button) => button.addEventListener("click", () => host.openJob(button.dataset.openJob)));
}
async function refreshDetected() {
  const result = await ask({ type: "detected-list" }).catch(() => ({ ok: false, list: void 0 }));
  if (!result.ok || !result.list) return;
  const changed = JSON.stringify(result.list) !== JSON.stringify(store.detected);
  store.detected = result.list;
  if (changed) host.redraw();
}
var firstEmailCount = () => (store.tracker?.jobs ?? []).filter(needsFirstEmail).length;
function wireBubbles(root) {
  root.querySelectorAll("[data-bubble-open]").forEach((button) => button.addEventListener("click", () => host.openJob(button.dataset.bubbleOpen)));
  root.querySelectorAll("[data-bubble-delete]").forEach((button) => button.addEventListener("click", async () => {
    const job = jobById(button.dataset.bubbleDelete);
    if (!job || !confirm(`Delete ${job.title} at ${job.company} from your tracker? Its people go too.`)) return;
    const key = `delete:${job.id}`;
    store.busy.add(key);
    delete store.notes[key];
    host.redraw();
    const result = await ask({ type: "delete-job", applicationId: job.id }).catch(() => ({ ok: false, error: "Couldn't reach Unnepo." }));
    store.busy.delete(key);
    if (!result.ok) store.notes[key] = result.error ?? "Couldn't delete it.";
    await loadTracker(true);
  }));
}
function wireJobRows(root) {
  root.querySelectorAll(".job-row[data-open-job], .heat-event[data-open-job]").forEach((button) => button.addEventListener("click", () => host.openJob(button.dataset.openJob)));
}

// extension/src/shared/friends.ts
var ask2 = (message) => chrome.runtime.sendMessage(message);
var friends = {
  list: null,
  incoming: [],
  outgoing: [],
  error: "",
  loading: false,
  loadedAt: 0,
  /** What happened after Add, Accept or Remove. */
  note: "",
  noteBad: false,
  busy: false,
  email: ""
};
async function loadFriends() {
  if (friends.loading) return;
  friends.loading = true;
  const result = await ask2({ type: "friends", since: weekStart(/* @__PURE__ */ new Date()).toISOString() }).catch(() => ({ ok: false, error: "Couldn't reach Unnepo." }));
  friends.loading = false;
  friends.loadedAt = Date.now();
  if (result.ok) {
    friends.list = result.friends ?? [];
    friends.incoming = result.incoming ?? [];
    friends.outgoing = result.outgoing ?? [];
    friends.error = "";
  } else friends.error = result.error ?? "Couldn't load your friends.";
  redraw();
}
function ensureFriends(maxAge = 6e4) {
  if (!friends.loading && (!friends.list || Date.now() - friends.loadedAt > maxAge)) void loadFriends();
}
var friendRequests = () => friends.incoming.length;
var initials = (name) => name.split(/\s+/).filter(Boolean).slice(0, 2).map((part2) => part2[0].toUpperCase()).join("") || "?";
function friendsWeekCard(myWeek) {
  ensureFriends();
  const head = (extra = "") => `<div class="row-between"><span class="eyebrow">Friends this week</span>${extra}</div>`;
  if (!friends.list) return "";
  const requests = friends.incoming.length ? `<button type="button" class="note warn nudge" data-go="settings">${friends.incoming.length} friend ${friends.incoming.length === 1 ? "request" : "requests"} waiting. See ${friends.incoming.length === 1 ? "it" : "them"} \u2192</button>` : "";
  if (!friends.list.length) return requests;
  const rows = [{ id: "me", name: "You", applied: myWeek }, ...friends.list].sort((a, b) => b.applied - a.applied);
  const top = Math.max(1, ...rows.map((row) => row.applied));
  return `<section class="page friends-card" aria-label="Friends this week">
    ${head(`<button type="button" class="quiet-link tight" data-go="settings">Add</button>`)}
    <ul class="friend-list">${rows.map((row) => `
      <li class="friend${row.id === "me" ? " me" : ""}">
        <span class="friend-av" aria-hidden="true">${escape(row.id === "me" ? "\u2605" : initials(row.name))}</span>
        <span class="friend-name">${escape(row.name)}</span>
        <span class="friend-bar" aria-hidden="true"><span style="width:${Math.round(row.applied / top * 100)}%"></span></span>
        <span class="friend-count">${row.applied}</span>
      </li>`).join("")}</ul>
    ${requests}
  </section>`;
}
function friendsSettingsCard() {
  ensureFriends();
  const busy = friends.busy ? "disabled" : "";
  const list = friends.list ?? [];
  const row = (name, sub, actions) => `<li class="friend-row"><span class="friend-row-text"><span class="friend-name">${escape(name)}</span>${sub ? `<span class="sub">${escape(sub)}</span>` : ""}</span><span class="friend-actions">${actions}</span></li>`;
  return `<section class="page settings-card" aria-label="Friends">
    <div class="row-between"><span class="eyebrow">Friends</span>${list.length ? `<span class="mono">${list.length}</span>` : ""}</div>
    <p class="small">Add a friend by email. Once they accept, you each see how many jobs the other applied to this week. Nothing else is shared.</p>
    <form class="connect-code" id="friend-form">
      <input class="field" id="friend-email" type="email" placeholder="friend@school.edu" aria-label="Friend's email" value="${escape(friends.email)}" autocomplete="off" required>
      <button type="submit" class="solid" ${busy}>${friends.busy ? "Adding\u2026" : "Add"}</button>
    </form>
    ${friends.note ? `<p class="small" role="status"${friends.noteBad ? ' style="color: var(--warn)"' : ""}>${escape(friends.note)}</p>` : ""}
    ${friends.error && !friends.list ? `<p class="note">${escape(friends.error)}</p>` : ""}
    ${friends.incoming.length ? `<span class="q-label">Requests</span><ul class="friend-rows">${friends.incoming.map((item) => row(item.name, item.email, `<button type="button" class="solid" data-friend-accept="${item.id}" ${busy}>Accept</button><button type="button" class="quiet-link" data-friend-decline="${item.id}" ${busy}>Decline</button>`)).join("")}</ul>` : ""}
    ${list.length ? `<ul class="friend-rows">${list.map((item) => row(item.name, `${item.applied} this week`, `<button type="button" class="quiet-link" data-friend-remove="${item.id}" ${busy}>Remove</button>`)).join("")}</ul>` : ""}
    ${friends.outgoing.length ? `<span class="q-label">Waiting for them to accept</span><ul class="friend-rows">${friends.outgoing.map((item) => row(item.email, "", `<button type="button" class="quiet-link" data-friend-remove="${item.id}" ${busy}>Cancel</button>`)).join("")}</ul>` : ""}
  </section>`;
}
async function act(body, done) {
  friends.busy = true;
  friends.note = "";
  redraw();
  const result = await ask2({ type: "friend-action", body }).catch(() => ({ ok: false, error: "Couldn't reach Unnepo." }));
  friends.busy = false;
  friends.noteBad = !result.ok || body.action === "invite" && (result.status === "sent" || result.status === "waiting") && !result.emailed;
  friends.note = result.ok ? done(result) : result.error ?? "Couldn't do that.";
  await loadFriends();
}
function wireFriends(root) {
  const form = root.querySelector("#friend-form");
  const input = root.querySelector("#friend-email");
  input?.addEventListener("input", () => {
    friends.email = input.value;
  });
  form?.addEventListener("submit", (event) => {
    event.preventDefault();
    const email = input?.value.trim() ?? "";
    if (!email) return;
    void act({ action: "invite", email }, (result) => {
      friends.email = "";
      if (result.status === "accepted") return "They'd already asked you, so you're friends now.";
      if (result.status === "already") return "You're already friends.";
      if (result.status === "waiting") return result.emailed ? "Already sent. Waiting for them to accept." : "Saved, but the email to them didn't go out. Unnepo's email isn't working right now; try adding them again later.";
      return result.emailed ? `Sent. ${email} got an email inviting them to compete.` : `Saved, but the email to ${email} didn't go out. They'll see your request under Me once they sign up.`;
    });
  });
  root.querySelectorAll("[data-friend-accept]").forEach((button) => button.addEventListener("click", () => void act({ action: "respond", id: button.dataset.friendAccept, accept: true }, () => "You're friends now.")));
  root.querySelectorAll("[data-friend-decline]").forEach((button) => button.addEventListener("click", () => void act({ action: "respond", id: button.dataset.friendDecline, accept: false }, () => "Declined.")));
  root.querySelectorAll("[data-friend-remove]").forEach((button) => button.addEventListener("click", () => void act({ action: "remove", id: button.dataset.friendRemove }, () => "Removed.")));
}

// lib/apply/calendar.ts
var ACTIVITY_MARK = {
  applied: { glyph: "\u25CF", color: "#4ADE80", label: "Applied" },
  emailed: { glyph: "\u2709", color: "#C7D7FF", label: "Emailed someone" },
  follow_up: { glyph: "\u21BA", color: "#F5A524", label: "Follow up" },
  interview: { glyph: "\u2605", color: "#4ADE80", label: "Interview" },
  offer: { glyph: "\u25C6", color: "#E6C15A", label: "Offer" },
  rejected: { glyph: "\u2715", color: "#F87171", label: "Said no" }
};
var ACTIVITY_HEAT_FINE = ["#17171B", "#122E1D", "#173A24", "#1C4A2E", "#22603A", "#287543", "#2F9A55", "#3CBC6A", "#4ADE80"];
var HISTORY_KIND = { follow_up: "follow_up", assessment: "interview", interviewing: "interview", offer: "offer", rejected: "rejected" };
var isApplied2 = (job) => job.status === "submitted" || job.status === "applied_manual";
function activityOf(job) {
  const list = [];
  const report = job.fillReport;
  if (isApplied2(job) && countsTowardGoals(job)) list.push({ at: appliedOn(job), kind: "applied" });
  for (const at of Object.values(report?.emailedAt ?? {})) list.push({ at: new Date(at), kind: "emailed" });
  if (report?.reachedOut?.at) list.push({ at: new Date(report.reachedOut.at), kind: "emailed" });
  for (const change of report?.statusHistory ?? []) {
    const kind = HISTORY_KIND[change.status];
    if (kind) list.push({ at: new Date(change.at), kind });
  }
  const seen = /* @__PURE__ */ new Set();
  return list.filter((event) => !Number.isNaN(event.at.getTime())).map((event) => ({ ...event, day: dayKey(event.at), job })).filter((event) => {
    const key = `${event.day}:${event.kind}`;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  }).sort((a, b) => a.at.getTime() - b.at.getTime());
}
function activityByDay(jobs) {
  const map = /* @__PURE__ */ new Map();
  for (const job of jobs) for (const event of activityOf(job)) map.set(event.day, [...map.get(event.day) ?? [], event]);
  return map;
}
function activityGrid(now, weeks) {
  const first = weekStart(now);
  first.setDate(first.getDate() - (weeks - 1) * 7);
  return Array.from({ length: weeks }, (_, week) => Array.from({ length: 7 }, (_2, weekday) => {
    const date = new Date(first);
    date.setDate(first.getDate() + week * 7 + weekday);
    return date;
  }));
}

// extension/src/shared/week.ts
var DAY3 = 864e5;
var pickedDay = "";
function perDay(jobs) {
  const days = /* @__PURE__ */ new Map();
  for (const job of jobs) {
    if (!isAppliedJob(job) || !countsTowardGoals(job)) continue;
    const key = dayKey(appliedOn(job));
    days.set(key, [...days.get(key) ?? [], job]);
  }
  return days;
}
function streakOf(days, now = /* @__PURE__ */ new Date()) {
  const cursor = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  if (!days.get(dayKey(cursor))?.length) cursor.setDate(cursor.getDate() - 1);
  let streak = 0;
  while (days.get(dayKey(cursor))?.length) {
    streak += 1;
    cursor.setDate(cursor.getDate() - 1);
  }
  return streak;
}
function emailsBetween(jobs, from, to) {
  return jobs.reduce((sum, job) => {
    const sent = Object.values(job.fillReport?.emailedAt ?? {}).filter((at) => {
      const time = Date.parse(at);
      return time >= from && time < to;
    }).length;
    const reached = job.fillReport?.reachedOut;
    const own = reached && !sent && Date.parse(reached.at) >= from && Date.parse(reached.at) < to ? reached.count : 0;
    return sum + sent + own;
  }, 0);
}
var FLAME = `<svg width="15" height="15" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M12 2c1 4 5 6 5 11a5 5 0 0 1-10 0c0-2 1-3.5 2-4.5 0 2 1 3 2 3 0-3-1-6 1-9.5z"/></svg>`;
function jobRow(job, sub = "") {
  const title = job.titleMissing ? "Job title missing" : job.title;
  return `<li data-search="${escape(`${title} ${job.company}`.toLowerCase())}"><button type="button" class="job-row" data-open-job="${job.id}">
    <span class="job-row-text"><span class="job-row-title">${escape(title)}</span><span class="job-row-company">${escape(job.company)}${sub ? ` \xB7 ${escape(sub)}` : ""}</span></span>
    ${progressDots(job)}
  </button></li>`;
}
var WEEKS = 12;
var shortDate = (date) => date.toLocaleDateString("en-US", { month: "short", day: "numeric" });
function weekView(now = /* @__PURE__ */ new Date(), under = "") {
  if (!store.tracker) return `<section class="page"><span class="eyebrow">Every day you did something</span><p class="note">${escape(store.error || "Loading your week\u2026")}</p></section>`;
  const jobs = store.tracker.jobs;
  const applied2 = perDay(jobs);
  const byDay = activityByDay(jobs);
  const grid = activityGrid(now, WEEKS);
  const start = weekStart(now);
  const today = dayKey(now);
  if (pickedDay && (pickedDay > today || pickedDay < dayKey(grid[0][0]))) pickedDay = "";
  const weekly = store.tracker.weeklyGoal ?? 0;
  let week = 0;
  for (let index = 0; index < 7; index += 1) week += applied2.get(dayKey(new Date(start.getFullYear(), start.getMonth(), start.getDate() + index)))?.length ?? 0;
  const streak = streakOf(applied2, now);
  const emails = emailsBetween(jobs, start.getTime(), start.getTime() + 7 * DAY3);
  const columns = grid.map((days, index) => `<div class="heat-col">
      <span class="heat-month">${index % 4 === 0 ? escape(shortDate(days[0])) : ""}</span>
      ${days.map((date) => {
    const key = dayKey(date);
    if (key > today) return `<span class="heat-day future"></span>`;
    const count = byDay.get(key)?.length ?? 0;
    return `<button type="button" class="heat-day${key === today ? " today" : ""}${key === pickedDay ? " on" : ""}" data-week-day="${key}" aria-pressed="${key === pickedDay}" aria-label="${escape(shortDate(date))}: ${count} ${count === 1 ? "thing" : "things"}" style="background:${ACTIVITY_HEAT_FINE[Math.min(count, 8)]}"></button>`;
  }).join("")}
    </div>`).join("");
  const letters = ["M", "T", "W", "T", "F", "S", "S"].map((letter2) => `<span>${letter2}</span>`).join("");
  const picked = pickedDay ? byDay.get(pickedDay) ?? [] : [];
  const pickedDate = pickedDay ? /* @__PURE__ */ new Date(`${pickedDay}T00:00:00`) : null;
  const detail = pickedDate ? `
      <div class="heat-detail">
        <div class="row-between"><span class="small"><b>${escape(shortDate(pickedDate))}</b>${pickedDay === today ? " \xB7 today" : ""}</span><button type="button" class="quiet-link tight" data-week-day="">Close</button></div>
        ${picked.length ? `<ul class="heat-events">${picked.map((event) => {
    const mark = ACTIVITY_MARK[event.kind];
    const title = event.job.titleMissing ? "Job title missing" : event.job.title;
    return `<li><button type="button" class="heat-event" data-open-job="${event.job.id}"><span class="heat-glyph" style="color:${mark.color}">${mark.glyph}</span><span>${mark.label}</span><span class="sub">\xB7 ${escape(event.job.company)}, ${escape(title)}</span></button></li>`;
  }).join("")}</ul>` : `<p class="small">A quiet day. Nothing logged.</p>`}
      </div>` : "";
  return `
    <section class="page week-card" aria-label="Every day you did something">
      <div class="row-between">
        <span class="eyebrow">This week \xB7 ${week}${weekly ? ` of ${weekly}` : " applied"}</span>
        <span class="streak${streak ? " lit" : ""}" title="Days in a row with an application">${FLAME}${streak} ${streak === 1 ? "day" : "days"}</span>
      </div>
      ${weekly ? `<div class="bar" role="progressbar" aria-label="Weekly goal" aria-valuemin="0" aria-valuemax="${weekly}" aria-valuenow="${Math.min(week, weekly)}"><div style="width:${Math.min(100, Math.round(week / weekly * 100))}%"></div></div>` : ""}
      <div class="row-between"><span class="small">${weekly ? week >= weekly ? "Weekly goal hit." : `${weekly - week} to go this week.` : "Set a weekly goal on unnepo.com."}</span><span class="small">${emails} ${emails === 1 ? "email" : "emails"} sent</span></div>
      <div class="heat" role="group" aria-label="Every day you did something, last ${WEEKS} weeks">
        <div class="heat-col heat-letters"><span class="heat-month"></span>${letters}</div>
        ${columns}
      </div>
      ${detail}
      ${heatKey()}
    </section>
    ${under}
    ${friendsWeekCard(week)}`;
}
var keyOpen = false;
function heatKey() {
  const steps = ["0", "1", "2", "3", "4", "5", "6", "7", "8+"];
  return `
      <details class="heat-how" id="heat-how" ${keyOpen ? "open" : ""}>
        <summary>How it works</summary>
        <div class="heat-key" aria-label="Key: darker squares are days with less done, brighter ones more">
          <span class="small">Less</span>
          ${steps.map((label, index) => `<span class="heat-key-step"><span class="heat-key-swatch" style="background:${ACTIVITY_HEAT_FINE[index]}"></span><span class="heat-key-num">${label}</span></span>`).join("")}
          <span class="small">More</span>
          <span class="heat-key-step today-key"><span class="heat-key-swatch today"></span><span class="heat-key-num">Today</span></span>
        </div>
        <p class="small heat-key-note">Each square is a day over the last ${WEEKS} weeks. The brighter it is, the more you did that day: each application, email, follow-up, interview, offer or no counts as one, up to 8 or more. Tap a day to see what happened.</p>
      </details>`;
}
function wireWeek(root) {
  const how = root.querySelector("#heat-how");
  how?.addEventListener("toggle", () => {
    keyOpen = how.open;
  });
  root.querySelectorAll("[data-week-day]").forEach((button) => button.addEventListener("click", () => {
    const key = button.dataset.weekDay;
    pickedDay = key && key !== pickedDay ? key : "";
    redraw();
  }));
}
var FILTERS = [["all", "All"], ["reach", "Reach out"], ["waiting", "Waiting"], ["follow", "Follow up"], ["interview", "Interview"]];
var filter = "all";
var query = "";
function matches(job, which) {
  if (which === "all") return true;
  const progress = progressOf2(job);
  if (progress.ended === "Rejected" || !isAppliedJob(job)) return false;
  if (which === "reach") return progress.done === 1;
  if (which === "waiting") return !progress.due && (progress.done === 2 || progress.done === 4);
  if (which === "follow") return progress.due;
  return progress.done >= 5;
}
function showJobs(which) {
  filter = which;
}
function jobsList() {
  if (!store.tracker) return `<p class="note">${escape(store.error || "Loading your jobs\u2026")}</p>`;
  const jobs = store.tracker.jobs;
  const chips = FILTERS.map(([value, label]) => {
    const count = jobs.filter((job) => matches(job, value)).length;
    return `<button type="button" class="chip${filter === value ? " on" : ""}" data-job-filter="${value}" aria-pressed="${filter === value}">${label}<b>${count}</b></button>`;
  }).join("");
  const shown = jobs.filter((job) => matches(job, filter));
  const applied2 = shown.filter(isAppliedJob);
  const saved = shown.filter((job) => !isAppliedJob(job));
  const when3 = (job) => new Date(job.submittedAt ?? job.createdAt).toLocaleDateString("en-US", { month: "short", day: "numeric" });
  const group = (label, list) => list.length ? `
    <div class="row-between"><span class="eyebrow">${label}</span><span class="mono">${list.length}</span></div>
    <ul class="jobs-list">${list.map((job) => jobRow(job, when3(job))).join("")}</ul>` : "";
  return `
    <section class="page jobs-card" aria-label="Your jobs">
      <input class="field search" id="job-search" type="search" placeholder="Search jobs or companies" aria-label="Search jobs or companies" value="${escape(query)}" autocomplete="off">
      <div class="chips" role="group" aria-label="Show">${chips}</div>
      ${shown.length ? `${group("Applied", applied2)}${group("Not applied yet", saved)}` : `<p class="note">${filter === "all" ? "Every job you apply to shows up here." : "No jobs on this step right now."}</p>`}
      <p class="note" id="job-search-none" hidden>No jobs match that.</p>
    </section>`;
}
function applySearch(root) {
  const words = query.trim().toLowerCase();
  let any = false;
  root.querySelectorAll(".jobs-card li[data-search]").forEach((row) => {
    row.hidden = Boolean(words) && !row.dataset.search.includes(words);
    any ||= !row.hidden;
  });
  const none = root.querySelector("#job-search-none");
  if (none) none.hidden = any || !words;
}
function wireJobsList(root) {
  root.querySelectorAll("[data-job-filter]").forEach((button) => button.addEventListener("click", () => {
    filter = button.dataset.jobFilter;
    redraw();
  }));
  const search = root.querySelector("#job-search");
  search?.addEventListener("input", () => {
    query = search.value;
    applySearch(root);
  });
  applySearch(root);
}

// lib/plan.ts
var UPGRADE_URL = "/home?tab=pro";

// extension/src/sidepanel/panel.ts
var app = document.getElementById("app");
var passwordSection = document.getElementById("password");
var tabBar = document.getElementById("tabs");
var jobsBadge = document.getElementById("jobs-count");
var meBadge = document.getElementById("me-count");
var planBadge = document.getElementById("plan-badge");
var TABS = ["home", "jobs", "settings"];
var view = "home";
var openedJob = { id: "", contact: "" };
var jobFrom = "home";
var popup = null;
var escape2 = (text) => text.replace(/[&<>"']/g, (char) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[char]);
var extensionVersion = () => chrome.runtime.getManifest().version_name ?? chrome.runtime.getManifest().version;
var ask3 = (message) => chrome.runtime.sendMessage(message);
var short2 = (text, max = 60) => text.length > max ? `${text.slice(0, max - 1).trimEnd()}\u2026` : text;
var OUCH = ["Ouch!", "Hey! Quit poking me.", "I have eight legs and I'm not afraid to use them.", "OK, that's it. I'm telling the recruiters."];
var MAD_MS = 2200;
var speech = (() => {
  const spider = document.getElementById("spider");
  const line_ = document.getElementById("ticker-line");
  const typed = document.getElementById("typed");
  const said = document.getElementById("said");
  spider.insertAdjacentHTML("beforeend", heroSpiderSvg());
  const reduce = matchMedia("(prefers-reduced-motion: reduce)").matches;
  let lines2 = [""];
  let key = "";
  let line = 0;
  let shown = 0;
  let hold = 0;
  let alerting = false;
  let pokes = 0;
  let calm = 0;
  const draw2 = () => {
    if (calm) return;
    const text = lines2[line] ?? "";
    const typing = shown < text.length;
    typed.textContent = text.slice(0, shown);
    said.textContent = text;
    spider.classList.toggle("talking", typing && text.charAt(shown) !== " " && Math.floor(shown / 2) % 2 === 0);
  };
  const next = () => {
    line = (line + 1) % lines2.length;
    shown = reduce ? lines2[line].length : 0;
    hold = 0;
    draw2();
  };
  setInterval(() => {
    if (calm) return;
    const text = lines2[line] ?? "";
    if (shown < text.length) {
      shown += 1;
      draw2();
    } else if (lines2.length > 1 && ++hold > 70) next();
  }, 45);
  spider.addEventListener("click", () => {
    pokes += 1;
    const ouch = OUCH[Math.min(pokes, OUCH.length) - 1];
    clearTimeout(calm);
    calm = 0;
    typed.textContent = ouch;
    said.textContent = ouch;
    line_.classList.add("alert");
    spider.classList.remove("talking", "mad");
    void spider.offsetWidth;
    spider.classList.add("mad");
    calm = window.setTimeout(() => {
      calm = 0;
      spider.classList.remove("mad");
      line_.classList.toggle("alert", alerting);
      shown = reduce ? (lines2[line] ?? "").length : 0;
      draw2();
    }, MAD_MS);
  });
  return (next2, alert2 = false) => {
    const nextKey = `${alert2}|${next2.join("\n")}`;
    if (nextKey === key) return;
    key = nextKey;
    lines2 = next2.length ? next2 : [""];
    line = 0;
    shown = reduce ? lines2[0].length : 0;
    hold = 0;
    alerting = alert2;
    if (!calm) line_.classList.toggle("alert", alert2);
    draw2();
  };
})();
function goalToday(state) {
  const now = /* @__PURE__ */ new Date();
  const dayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const weekly = state.me?.goal?.weekly ?? null;
  return { done: (state.me?.goal?.appliedAt ?? []).filter((at) => new Date(at) >= dayStart).length, target: weekly ? Math.ceil(weekly / 5) : null };
}
function goalLine(state) {
  const { done, target } = goalToday(state);
  if (!target) return `${done} today so far.`;
  return done >= target ? `${done} of ${target} today. Goal hit.` : `${done} of ${target} today. ${target - done} to go.`;
}
function lines(state) {
  if (!state.connected) return { lines: ["Hi! I'm the Unnepo spider.", "Connect your Unnepo account and I'll fill job applications for you.", "Your job-site passwords never leave this computer."] };
  const { job, page, me } = state;
  if (job?.error) return { lines: [job.error], alert: true };
  if (job?.step && (job.running || job.submission || job.report)) return { lines: [job.step] };
  if (!me.profileReady) return { lines: [me.resume ? "Almost there. Finish your profile and I'm ready." : "Hi! Upload your resume and I'll set up your profile."] };
  if (!jobFound(state) || !page) {
    const due = store.tracker ? dueCount(todayList().items) : 0;
    return { lines: [goalLine(state), due ? `${due} ${due === 1 ? "thing" : "things"} on your list today.` : "Open an application, I'll wait.", "Need a cover letter? Tap Write a cover letter."] };
  }
  const found = `${page.company || page.site} job found.${page.title ? ` ${short2(page.title)}.` : ""}`;
  if (!AUTOFILL_ENABLED) {
    const applying = state.applying;
    if (applying) {
      const open = applying.questions.filter((question) => !question.answered && !applying.answers?.[question.id]?.put).length;
      if (applying.questionsOnly) return { lines: [open ? `${open} ${open === 1 ? "question" : "questions"} to answer. I'm sitting next to ${open === 1 ? "it" : "them"}.` : "Every question here has an answer.", goalLine(state)] };
      return { lines: [applying.uploaded.length ? "Resume's in." : applying.resumeBox ? "Couldn't upload your resume here. Add it yourself." : "No resume upload on this page yet.", open ? `${open} complex ${open === 1 ? "question" : "questions"}. I'm sitting next to ${open === 1 ? "it" : "them"}.` : "No complex questions left on this page.", goalLine(state)] };
    }
    return { lines: [`${page.company || page.site} job. It's under Detected jobs on Jobs.`, goalLine(state)] };
  }
  if (page.posting) return { lines: [found, "Press Autofill. I'll press Apply and crawl it for you.", goalLine(state)] };
  const extra = page.account === "new" ? ", and one new account to make" : page.account === "sign_in" ? ", and I'll sign you in" : "";
  return { lines: [found, `${page.fields} ${page.fields === 1 ? "field" : "fields"}${extra}.`, "Press Autofill and I'll crawl it for you.", goalLine(state)] };
}
function connectView(state) {
  return `
    <section class="page" aria-label="Connect">
      <span class="eyebrow">Get started</span>
      <div class="job">
        <span class="job-title">Connect your Unnepo account</span>
        <span class="job-company">Unnepo fills applications from your profile. Connect once and the extension stays signed in.</span>
      </div>
      <a class="btn primary big" href="${escape2(state.apiBase)}/extension/connect" target="_blank" rel="noreferrer">Connect on Unnepo</a>
      <p class="note">Or paste the code from the Connect page:</p>
      <div class="connect-code">
        <input class="field" type="text" id="code" placeholder="unx_\u2026" autocomplete="off" spellcheck="false" aria-label="Connect code">
        <button type="button" class="solid" id="use-code">Use code</button>
      </div>
    </section>`;
}
function onUnnepo(state) {
  try {
    return Boolean(state.tab && new URL(state.tab.url).origin === new URL(state.apiBase).origin);
  } catch {
    return false;
  }
}
function jobFound(state) {
  const { job, page, tab } = state;
  const onWeb = Boolean(tab && /^https:\/\//.test(tab.url)) && !onUnnepo(state);
  if (dismissal(state) && !job?.running && !job?.submission) return false;
  return onWeb && Boolean(job?.applicationId || job?.running || job?.report || page?.fields || page?.posting);
}
var NOT_JOBS = "notJobs";
var SKIPPED_JOBS = "skippedJobs";
var notJobs = [];
var skippedJobs = [];
void Promise.all([chrome.storage.local.get(NOT_JOBS), chrome.storage.session.get(SKIPPED_JOBS)]).then(([kept, session]) => {
  notJobs = kept[NOT_JOBS] ?? [];
  skippedJobs = session[SKIPPED_JOBS] ?? [];
  void render();
});
var pageKey = (url) => url.split("#")[0];
function dismissal(state) {
  const key = state.tab ? pageKey(state.tab.url) : "";
  return notJobs.includes(key) ? "not_job" : skippedJobs.includes(key) ? "skipped" : null;
}
function dismiss(state, how) {
  const key = state.tab ? pageKey(state.tab.url) : "";
  if (!key) return;
  notJobs = notJobs.filter((item) => item !== key);
  skippedJobs = skippedJobs.filter((item) => item !== key);
  if (how === "not_job") notJobs = [...notJobs, key].slice(-200);
  if (how === "skipped") skippedJobs = [...skippedJobs, key].slice(-200);
  void chrome.storage.local.set({ [NOT_JOBS]: notJobs });
  void chrome.storage.session.set({ [SKIPPED_JOBS]: skippedJobs });
  void render();
}
var usesNow = null;
var usesLine = (note) => note ? `<span class="small uses-left" role="status" style="color: var(--warn)">${escape2(note)}</span>` : "";
var fillPending = null;
var isRunning = (state) => Boolean(state.job?.running) || fillPending !== null && fillPending === state.tab?.id;
function homeLists(state) {
  const noEmail = firstEmailCount();
  const nudge = noEmail ? `<button type="button" class="note warn nudge" data-show-jobs="reach">${noEmail} ${noEmail === 1 ? "job you applied to has" : "jobs you applied to have"} no email sent yet. See them \u2192</button>` : "";
  const list = `<div class="section-divider" role="separator"><span>Your jobs</span></div>${nudge}${jobsList()}<a class="btn" href="${escape2(state.apiBase)}/jobs" target="_blank" rel="noreferrer">Open my dashboard</a>`;
  return `${startCard(state)}${weekView(/* @__PURE__ */ new Date(), list)}`;
}
function startCard(state) {
  const me = state.me;
  if (!me || me.profileReady) return "";
  return `
    <section class="page" aria-label="Get started">
      <span class="eyebrow">Get started \xB7 ${me.completeness}% ready</span>
      <div class="bar" role="progressbar" aria-label="Profile ready" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${me.completeness}"><div style="width:${me.completeness}%"></div></div>
      <p class="note">${me.resume ? "Your resume is in. A few details are still missing" : "Start with your resume: Unnepo fills in your profile from it"}${me.missing?.length ? `: ${escape2(me.missing.join(", "))}.` : "."}</p>
      ${me.resume ? "" : `<button type="button" class="btn primary" id="start-resume" ${resumeBusy ? "disabled" : ""}>${resumeBusy ? "Reading your resume\u2026" : "Upload my resume"}</button>`}
      <a class="btn" href="${escape2(state.apiBase)}/home?edit=profile" target="_blank" rel="noreferrer">Finish my profile</a>
      ${resumeNote ? `<p class="small" role="status">${escape2(resumeNote)}</p>` : ""}
    </section>`;
}
function jobFillPage(state) {
  const { job, page, tab, me } = state;
  let host2 = "";
  try {
    host2 = tab ? new URL(tab.url).hostname.replace(/^www\./, "") : "";
  } catch {
    host2 = "";
  }
  const title = job?.title || page?.title || tab?.title || "This job";
  const size = page?.posting ? "Job posting" : page?.fields ? `${page.fields} ${page.fields === 1 ? "question" : "questions"}` : "";
  const detail = [job?.company || page?.company, page?.site || host2, size].filter(Boolean).join(" \xB7 ");
  return `${setupCard(state)}
    <section class="job-page" aria-label="This job">
      <div><div class="job-name">${escape2(title)}</div><div class="sub job-detail">${escape2(detail)}</div></div>
      <button type="button" class="btn primary big" id="fill" ${me.profileReady ? "" : "disabled"}>${job?.report ? "Fill again" : "Autofill application"}</button>
      ${usesLine(me?.usage?.autofills.note)}
      ${lockedLine(state)}
      ${trialLine(state)}
      <div class="row-between"><button type="button" class="quiet-link" id="skip-job">Skip this job</button><button type="button" class="quiet-link" id="not-job">This isn't a job</button></div>
      <span class="sub">Beta: check every field before you submit.</span>
      ${here.note ? `<p class="small" role="status">${escape2(here.note)}</p>` : ""}
    </section>
    <div class="job-foot">
      <button type="button" class="more-row" data-go="jobs">Cover letter, resume, more <span aria-hidden="true">\u203A</span></button>
      ${goalBar(state)}
    </div>`;
}
var upgradeUrl = (state) => `${state.apiBase}${UPGRADE_URL}`;
function lockedLine(state) {
  const count = state.job?.locked ?? 0;
  if (!count || !state.me?.usage?.free || state.job?.running) return "";
  return `<p class="small locked-line" role="status">${SPARK_SMALL} Pro would answer ${count === 1 ? "this question" : `these ${count} questions`} for you. <a href="${escape2(upgradeUrl(state))}" target="_blank" rel="noreferrer">Get Pro</a></p>`;
}
function trialLine(state) {
  const me = state.me;
  if (!me || me.unlimitedCredits) return "";
  if (me.trial) {
    const left = me.trial.hoursLeft < 24 ? `${me.trial.hoursLeft} ${me.trial.hoursLeft === 1 ? "hour" : "hours"}` : `${me.trial.daysLeft} ${me.trial.daysLeft === 1 ? "day" : "days"}`;
    return `<span class="small"${me.trial.hoursLeft <= 48 ? ' style="color: var(--warn)"' : ""}>Pro trial: ${left} left. <a href="${escape2(upgradeUrl(state))}" target="_blank" rel="noreferrer">Keep Pro</a></span>`;
  }
  if (me.trialEnded && me.usage?.free) {
    return `<span class="small">Your Pro trial ended. Free fills your basic details. <a href="${escape2(upgradeUrl(state))}" target="_blank" rel="noreferrer">Get Pro back</a></span>`;
  }
  return "";
}
function goalBar(state) {
  const { done, target } = goalToday(state);
  return `
    <div class="goal"><span>Today</span><span>${target ? `${done} of ${target}` : done}</span></div>
    ${target ? `<div class="bar" role="progressbar" aria-label="Goal for today" aria-valuemin="0" aria-valuemax="${target}" aria-valuenow="${Math.min(done, target)}"><div style="width:${Math.min(100, Math.round(done / target * 100))}%"></div></div>` : ""}`;
}
function fillingView() {
  return `
    <section class="filling" aria-label="Filling your application">
      <div class="letter-writing">${typingSpiderSvg(120, spiderLook)}</div>
      <button type="button" class="btn big stop" id="stop">Stop, I'll do it myself</button>
    </section>`;
}
var SPARK_SMALL = `<svg width="13" height="13" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M12 2l2.4 7.6L22 12l-7.6 2.4L12 22l-2.4-7.6L2 12l7.6-2.4z"/></svg>`;
var SPARK = SPARK_SMALL.replace('width="13" height="13"', 'class="big-tool-icon" width="20" height="20"');
var withCost = (label, kind) => {
  const usage = lastState?.me?.usage;
  return usage?.free && !lastState?.me?.unlimitedCredits ? `${label} (${usage[kind].left} left today)` : label;
};
var toolCount = (line) => line?.badge ? `<span class="tool-count${line.left === 0 ? " out" : ""}">${escape2(line.badge)}</span>` : "";
function autofillTool(state) {
  const ready = jobFound(state) && !state.job?.running && Boolean(state.me?.profileReady);
  const why = !state.me?.profileReady ? "Finish your profile first." : jobFound(state) ? "Fills this application. You check it and press Submit." : "Open a job application, then press this.";
  return `<button type="button" class="big-tool autofill-tool" id="beta-fill" ${ready ? "" : "disabled"}>
      ${toolCount(state.me?.usage?.autofills)}${SPARK}<span class="big-tool-text"><span>Autofill this application <span class="beta">Beta</span></span><span class="small">${why}</span></span>
    </button>`;
}
function toolsPage(state, extra = "") {
  return `
    <div class="tools">
      <button type="button" class="big-tool" data-popup="cover">${toolCount(state.me?.usage?.letters)}${SPARK}Write a cover letter</button>
      <button type="button" class="big-tool" data-popup="answer">${toolCount(state.me?.usage?.answers)}${SPARK}Answer a question</button>
      ${autofillTool(state)}
      <div class="tool-lines">${resumeLine(state)}${letterLine()}<div id="password-slot"></div></div>
      ${extra}
    </div>`;
}
var details = { key: "", data: null, loading: false };
var detailsKey = (state) => state.tab ? `${state.tab.id}|${pageKey(state.tab.url)}|${state.page?.title ?? ""}|${state.page?.company ?? ""}` : "";
function pageJob(state) {
  if (details.data?.title && details.key === detailsKey(state)) return details.data;
  const title = state.job?.title || state.page?.title;
  return title ? { title, company: state.job?.company || state.page?.company || "", site: state.page?.site ?? "", description: "" } : null;
}
var MINI_SPIDER = `<svg class="mini-spider" viewBox="0 0 ${W} ${H}" width="18" height="${Math.round(18 * H / W)}" shape-rendering="crispEdges" aria-hidden="true"><g transform="rotate(180 ${W / 2} ${H / 2})">${spiderRects(0)}</g></svg>`;
var complex = { busy: false, note: "", drafts: {}, open: /* @__PURE__ */ new Set() };
function answersCost(count) {
  const me = lastState?.me;
  if (!count || me?.unlimitedCredits || !me?.usage?.free) return "";
  return ` (${me.usage.answers.left} left today)`;
}
function wireJobBox(state) {
  const tabId = state.tab?.id;
  if (tabId === void 0) return;
  document.getElementById("begin-applying")?.addEventListener("click", async (event) => {
    const button = event.currentTarget;
    button.disabled = true;
    button.textContent = "Uploading your resume\u2026";
    complex.note = "";
    const result = await ask3({ type: "begin-applying", tabId }).catch(() => ({ ok: false, error: "Couldn't reach the page." }));
    if (!result.ok) complex.note = result.error ?? "Couldn't start.";
    void render();
  });
  document.getElementById("stop-applying")?.addEventListener("click", async () => {
    Object.assign(complex, { busy: false, note: "", drafts: {} });
    complex.open.clear();
    await ask3({ type: "stop-applying", tabId });
    void render();
  });
  document.getElementById("answer-complex")?.addEventListener("click", async () => {
    complex.busy = true;
    complex.note = "";
    void render();
    const result = await ask3({ type: "answer-complex", tabId, job: pageJob(state) }).catch(() => ({ ok: false, error: "Couldn't reach Unnepo." }));
    complex.busy = false;
    complex.note = !result.ok ? result.error ?? "Couldn't answer them." : result.stopped ? result.stopped : result.written ? `Answered ${result.written}. Check each one on the page.` : "Couldn't write any of these. Answer them yourself.";
    void render();
  });
  app.querySelectorAll("[data-show-question]").forEach((button) => button.addEventListener("click", () => void ask3({ type: "show-question", tabId, id: button.dataset.showQuestion })));
  app.querySelectorAll("details[data-answer-id]").forEach((box) => box.addEventListener("toggle", () => {
    if (box.open) complex.open.add(box.dataset.answerId);
    else complex.open.delete(box.dataset.answerId);
  }));
  app.querySelectorAll("[data-draft]").forEach((box) => box.addEventListener("input", () => {
    complex.drafts[box.dataset.draft] = box.value;
  }));
  app.querySelectorAll("[data-put]").forEach((button) => button.addEventListener("click", async () => {
    const id = button.dataset.put;
    const text = complex.drafts[id] ?? state.applying?.answers?.[id]?.text ?? "";
    const result = await ask3({ type: "put-answer", tabId, id, text }).catch(() => ({ ok: false, reason: "Couldn't reach the page." }));
    if (result.ok) delete complex.drafts[id];
    complex.note = result.ok ? "Put in the box." : result.reason ?? "Couldn't put it in.";
    if (document.activeElement instanceof HTMLElement) document.activeElement.blur();
    await refresh();
    void render();
  }));
  app.querySelectorAll("[data-copy]").forEach((button) => button.addEventListener("click", () => {
    const id = button.dataset.copy;
    const text = complex.drafts[id] ?? state.applying?.answers?.[id]?.text ?? "";
    void navigator.clipboard.writeText(text).then(() => {
      complex.note = "Copied.";
      void render();
    }, () => void 0);
  }));
}
var hereLinks = () => {
  const busy = here.step === "reading" || here.step === "saving";
  return `<div class="row-between"><button type="button" class="quiet-link" id="here-applied" ${busy ? "disabled" : ""}>I already applied</button><button type="button" class="quiet-link" id="here-later" ${busy ? "disabled" : ""}>Save for later</button></div>`;
};
function homeView(state) {
  if (isRunning(state)) return fillingView();
  ensureTracker();
  const note = here.note ? `<p class="small" role="status">${escape2(here.note)}</p>` : "";
  const card = openedCard(state);
  if (state.job?.submission || state.job?.error) return card + homeLists(state);
  if (card) return here.step === "check" ? card : card + homeLists(state);
  if (AUTOFILL_ENABLED && jobFound(state)) return jobFillPage(state);
  if (!AUTOFILL_ENABLED) return note + homeLists(state);
  const how = dismissal(state);
  const onWeb = Boolean(state.tab && /^https:\/\//.test(state.tab.url)) && !onUnnepo(state);
  return `${how ? `<div class="row-between"><span class="sub">${how === "skipped" ? "Job skipped." : "Marked as not a job."}</span><button type="button" class="quiet-link" id="undo-dismiss">Undo</button></div>` : ""}
    ${onWeb && !how ? hereLinks() : ""}${note}${homeLists(state)}`;
}
var back = () => `<button type="button" class="back" data-go="${view === "feedback" ? "settings" : jobFrom}"><span aria-hidden="true">\u2039</span> Back</button>`;
function jobView() {
  ensureTracker();
  const job = jobById(openedJob.id);
  if (!job) return store.tracker ? `<p class="note">That job isn't in your tracker any more.</p>` : `<p class="note">Loading the job\u2026</p>`;
  return jobPage(job, openedJob.contact || void 0);
}
function pageView(state) {
  const heading = (text) => `<div class="row-between"><span class="heading">${text}</span></div>`;
  const pages = {
    job: jobView,
    jobs: () => jobsView(state),
    feedback: () => `${heading("Feedback")}${issuesCard()}`,
    // Me: who you are and your plan, friends, how Unnepo behaves, then help. Sign out and the version last.
    settings: () => `${profileCard(state)}
      ${friendsSettingsCard()}
      ${trackingSettings(state)}
      <section class="page settings-card" aria-label="Help">
        <span class="eyebrow">Help</span>
        ${part("activity", "What Unnepo noticed lately", () => activityCard())}
        <button type="button" class="more-row" data-go="feedback">Report a problem or send feedback <span aria-hidden="true">\u203A</span></button>
      </section>
      <div class="row-between settings-foot"><button type="button" class="quiet" id="disconnect">Sign out</button><span class="mono">V${escape2(extensionVersion())}</span></div>`
  };
  return (TABS.includes(view) ? "" : back()) + pages[view]();
}
var onFree = (state) => Boolean(state?.connected && state.me?.usage?.free);
var openParts = /* @__PURE__ */ new Set();
var part = (id, title, body) => `
  <details class="part" data-part-id="${id}" ${openParts.has(id) ? "open" : ""}>
    <summary>${title}</summary>
    ${openParts.has(id) ? body() : ""}
  </details>`;
var SETUP_SKIPPED = "setupSkipped";
var setupSkipped = null;
void chrome.storage.local.get(SETUP_SKIPPED).then((stored) => {
  setupSkipped = stored[SETUP_SKIPPED] ?? "";
  void render();
});
var setupDraft = {};
var setupNote = "";
var setupSaving = false;
var SETUP_KEYS = ["salaryExpectation", "earliestStart", "willingToRelocate", "inPerson", "authorizedUS", "needsSponsorship", "classYear"];
var setupMissing = (setup) => SETUP_KEYS.filter((key) => key === "classYear" ? setup.hasSchool && !setup.classYear : setup[key] === null || setup[key] === "");
function setupCard(state) {
  const setup = state.me?.setup;
  if (!AUTOFILL_ENABLED || !setup || setupSkipped === null || state.job?.running || state.job?.report) return "";
  const missing = setupMissing(setup);
  if (!missing.length || setupSkipped === missing.join(",")) return "";
  const yesNo = (key, question) => {
    const value = setupDraft[key];
    const pick = (on, label) => `<button type="button" class="choice${value === on ? " on" : ""}" data-setup="${key}" data-value="${on}" aria-pressed="${value === on}">${label}</button>`;
    return `<div class="question"><span class="q-label">${question}</span><div class="choices">${pick(true, "Yes")}${pick(false, "No")}</div></div>`;
  };
  const text = (key, question, placeholder) => `<label class="question"><span class="q-label">${question}</span><input class="field" data-setup-text="${key}" value="${escape2(String(setupDraft[key] ?? ""))}" maxlength="80" placeholder="${placeholder}"></label>`;
  const fields = {
    salaryExpectation: () => text("salaryExpectation", "Pay you're looking for", "$20/hour, or Open to discussion"),
    earliestStart: () => text("earliestStart", "Earliest start date", "June 2027"),
    willingToRelocate: () => yesNo("willingToRelocate", "Willing to relocate?"),
    inPerson: () => yesNo("inPerson", "Open to working in person?"),
    authorizedUS: () => yesNo("authorizedUS", "Authorized to work in the U.S.?"),
    needsSponsorship: () => yesNo("needsSponsorship", "Will you need visa sponsorship?"),
    classYear: () => `<label class="question"><span class="q-label">Year in school</span><select class="field" data-setup-text="classYear"><option value="">Choose\u2026</option>${[["freshman", "Freshman"], ["sophomore", "Sophomore"], ["junior", "Junior"], ["senior", "Senior"], ["graduate", "Graduate student"]].map(([value, label]) => `<option value="${value}"${setupDraft.classYear === value ? " selected" : ""}>${label}</option>`).join("")}</select></label>`
  };
  return `
    <section class="page" aria-label="Quick answers">
      <span class="eyebrow">Before you fill \xB7 ${missing.length} quick ${missing.length === 1 ? "answer" : "answers"}</span>
      <p class="note">Most forms ask these. Answer once and Unnepo fills them everywhere.</p>
      <div class="letter-form">${missing.map((key) => fields[key]()).join("")}
        <div class="links">
          <button type="button" class="solid" id="setup-save" ${setupSaving ? "disabled" : ""}>${setupSaving ? "Saving\u2026" : "Save"}</button>
          <button type="button" class="link" id="setup-skip">Skip for now</button>
        </div>
      </div>
      ${setupNote ? `<p class="small" role="status">${escape2(setupNote)}</p>` : ""}
    </section>`;
}
function wireSetup(state) {
  app.querySelectorAll("[data-setup]").forEach((button) => button.addEventListener("click", () => {
    setupDraft[button.dataset.setup] = button.dataset.value === "true";
    void render();
  }));
  app.querySelectorAll("[data-setup-text]").forEach((box) => box.addEventListener(box instanceof HTMLSelectElement ? "change" : "input", () => {
    setupDraft[box.dataset.setupText] = box.value;
  }));
  document.getElementById("setup-skip")?.addEventListener("click", () => {
    const missing = state.me?.setup ? setupMissing(state.me.setup).join(",") : "";
    setupSkipped = missing;
    void chrome.storage.local.set({ [SETUP_SKIPPED]: missing });
    void render();
  });
  document.getElementById("setup-save")?.addEventListener("click", async () => {
    setupSaving = true;
    setupNote = "";
    void render();
    const result = await ask3({ type: "save-setup", answers: setupDraft }).catch(() => ({ ok: false, error: "Couldn't reach Unnepo." }));
    setupSaving = false;
    setupNote = result.ok ? "Saved. These fill by themselves from now on." : result.error ?? "Couldn't save.";
    if (document.activeElement?.closest(".letter-form")) document.activeElement.blur();
    void render();
  });
}
var linkReading = false;
async function readJobLink(url) {
  if (!/^https:\/\/\S+\.\S+/.test(url.trim())) return { info: null, error: "Put in the job's link first (it starts with https://)." };
  linkReading = true;
  void render();
  const result = await ask3({ type: "read-link", url: url.trim() }).catch(() => ({ info: null, error: "Couldn't reach Unnepo." }));
  linkReading = false;
  return result;
}
var keepTyped = (typed, read) => typed.trim() && !BOARD_COMPANY.test(typed.trim()) && !STATUS_TITLE.test(typed.trim()) ? typed : read || typed;
var STATUS_TITLE = /^(applied( on .+| \d+ \w+ ago| today| yesterday)?|application (sent|submitted|received).*|job title missing)$/i;
var BOARD_COMPANY = /^(handshake|joinhandshake|ziprecruiter|indeed|glassdoor|linkedin|wellfound|dice|simplify|built ?in|monster|simplyhired|careerbuilder|wayup|idealist|usajobs|localhost|jobs?|careers?)$/i;
var here = { key: "", step: "idle", applied: true, job: null, note: "", auto: false, savedUrl: "" };
function openedCard(state) {
  const key = state.tab ? `${state.tab.id}|${state.tab.url}` : "";
  if (here.key !== key && here.step !== "saving") Object.assign(here, { key, step: "idle", job: null, note: "" });
  if (here.step === "saved") {
    return `<section class="page" aria-label="Saved"><p class="note ok" role="status">${escape2(here.note)}</p>${here.savedUrl ? `<div class="links"><button type="button" class="link" data-open-saved="${escape2(here.savedUrl)}">See it and the people there</button></div>` : ""}</section>`;
  }
  if (!state.tab || !/^https:\/\//.test(state.tab.url) || onUnnepo(state) || state.job?.running || state.job?.submission) return "";
  if (here.step === "check" || here.step === "saving" && !here.auto) {
    const job = here.job;
    const ready = job.title.trim().length >= 2 && job.company.trim().length >= 2 && here.step !== "saving";
    return `
    <section class="page" aria-label="Check the job">
      <span class="eyebrow">${here.applied ? "I applied" : "Save for later"} \xB7 read from the ${escape2(job.from)}</span>
      <div class="letter-form" id="here-form">
        <label class="question"><span class="q-label">Job title</span><input class="field" id="here-title" value="${escape2(job.title)}" maxlength="200"></label>
        <label class="question"><span class="q-label">Company</span><input class="field" id="here-company" value="${escape2(job.company)}" maxlength="200" placeholder="Type the company"></label>
        <label class="question"><span class="q-label">Job posting link</span><input class="field" id="here-link" value="${escape2(job.link)}" maxlength="2000"></label>
        <div class="links"><button type="button" class="link" id="here-fill" ${linkReading ? "disabled" : ""}>${linkReading ? "Reading the link\u2026" : "Fill in the job information"}</button></div>
        ${job.description ? `<p class="small">With the job description (${job.description.length.toLocaleString()} characters), for cover letters and finding people.</p>` : `<p class="small">No job description on this page.</p>`}
        <div class="links">
          <button type="button" class="solid" id="here-save" ${ready ? "" : "disabled"}>${here.step === "saving" ? "Saving\u2026" : here.applied ? "Save as applied" : "Save for later"}</button>
          <button type="button" class="link" id="here-cancel">Cancel</button>
        </div>
      </div>
      ${here.note ? `<p class="small" role="status">${escape2(here.note)}</p>` : ""}
    </section>`;
  }
  if (here.step === "reading" || here.step === "saving") return `<p class="note" role="status">${here.step === "reading" ? "Reading the job\u2026" : "Saving\u2026"}</p>`;
  return "";
}
function wireOpened(state) {
  if (!state.tab) return;
  const tabId = state.tab.id;
  const read = async (applied2) => {
    Object.assign(here, { step: "reading", applied: applied2, note: "", auto: false });
    view = "home";
    void render();
    const result = await ask3({ type: "read-opened-job", tabId }).catch(() => ({ ok: false, error: "Couldn't reach the page." }));
    if (!result.ok || !result.job) {
      Object.assign(here, { step: "idle", note: result.error ?? "Couldn't read this page." });
      return void render();
    }
    here.job = result.job;
    here.auto = true;
    return save();
  };
  const save = async () => {
    if (!here.job) return;
    here.step = "saving";
    here.note = "";
    if (document.activeElement?.closest("#here-form")) document.activeElement.blur();
    void render();
    const result = await ask3({ type: "save-opened-job", tabId, applied: here.applied, job: here.job }).catch(() => ({ ok: false, error: "Couldn't reach Unnepo." }));
    const named = result.companyMissing ? result.title ?? "The job" : `${result.title} at ${result.company}`;
    if (result.ok) void loadTracker(true);
    if (result.ok) Object.assign(here, { step: "saved", savedUrl: result.id ?? "", note: `\u2713 Success! ${named} ${here.applied ? "is added to your Applied jobs" : "is saved for later"}.${result.companyMissing ? " Unnepo is finding the company from the job's link." : ""}` });
    else Object.assign(here, { step: "check", note: result.error ?? "Couldn't save it." });
    void render();
  };
  document.getElementById("here-applied")?.addEventListener("click", () => void read(true));
  document.getElementById("here-later")?.addEventListener("click", () => void read(false));
  document.getElementById("here-cancel")?.addEventListener("click", () => {
    Object.assign(here, { step: "idle", job: null, note: "" });
    void render();
  });
  for (const [id, key] of [["here-title", "title"], ["here-company", "company"], ["here-link", "link"]]) {
    const box = document.getElementById(id);
    box?.addEventListener("input", () => {
      if (!here.job) return;
      here.job[key] = box.value;
      const save2 = document.getElementById("here-save");
      if (save2) save2.disabled = here.job.title.trim().length < 2 || here.job.company.trim().length < 2;
    });
  }
  document.getElementById("here-save")?.addEventListener("click", () => void save());
  document.getElementById("here-fill")?.addEventListener("click", async () => {
    if (!here.job) return;
    const result = await readJobLink(here.job.link);
    if (result.info && here.job) {
      here.job.title = keepTyped(here.job.title, result.info.title);
      here.job.company = keepTyped(here.job.company, result.info.company);
      if (result.info.description.length > here.job.description.length) here.job.description = result.info.description;
      here.note = here.job.company.trim() ? "Filled in from the link. Check it, then save it." : "Filled in from the link. Type the company: the page didn't say.";
    } else here.note = result.error ?? "Couldn't read the link.";
    void render();
  });
}
var activityLog = null;
function activityCard() {
  if (activityLog === null) {
    void ask3({ type: "activity-log" }).then((result) => {
      activityLog = result.log ?? [];
      void render();
    }, () => void 0);
    return "";
  }
  const when3 = (at) => new Date(at).toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" });
  return `
    <section class="view" aria-label="Activity">
      ${activityLog.length ? `<ul class="needs activity">${activityLog.slice(0, 15).map((item) => `<li><span class="mono small">${when3(item.at)}</span> ${escape2(item.text)}</li>`).join("")}</ul>` : `<p class="note">Nothing yet. Apply to a job and what Unnepo notices shows up here.</p>`}
    </section>`;
}
var pasteText = "";
var letterSource = "job";
function popupShell(title, body, step = 0, steps = 0) {
  const bars = steps > 1 ? `<div class="steps" role="img" aria-label="Question ${step + 1} of ${steps}">${Array.from({ length: steps }, (_, at) => `<div class="${at <= step ? "on" : ""}"></div>`).join("")}</div>` : "";
  return `
    <div class="dim" id="popup-dim"></div>
    <section class="sheet" id="popup" role="dialog" aria-modal="true" aria-label="${escape2(title)}" tabindex="-1">
      <div class="popup-head"><span class="popup-title">${escape2(title)}</span><button type="button" class="popup-x" id="popup-close" aria-label="Close">\xD7</button></div>
      ${bars}
      ${body}
      ${step > 0 ? `<button type="button" class="back" id="popup-back"><span aria-hidden="true">\u2039</span> Back</button>` : ""}
    </section>`;
}
var option = (attr, value, label, hint, on) => `<button type="button" class="opt${on ? " on" : ""}" data-${attr}="${value}" aria-pressed="${on}">${label}<small>${hint}</small></button>`;
function coverPopup(state) {
  const forJob = jobFound(state);
  const busy = letterStep === "writing" || letterStep === "revising" || letterStep === "saving";
  const note = letterNote ? `<p class="small" role="status">${escape2(letterNote)}</p>` : "";
  if (busy || letter && letterStep === "written" && letterSource === (forJob ? "job" : "paste")) {
    return popupShell("Your cover letter", `${writingSpider()}${letter ? writtenLetter(busy, forJob) : ""}${note}`);
  }
  const highlights = state.me?.highlights ?? [];
  const steps = [...forJob ? [] : ["paste"], "format", "length", "tone", "mention"];
  const step = Math.min(popup.step, steps.length - 1);
  popup.step = step;
  const title = state.job?.title || state.page?.title;
  const company = state.job?.company || state.page?.company;
  const forLine = forJob && title ? `<div class="sub">For ${escape2(title)}${company ? ` at ${escape2(company)}` : ""}</div>` : "";
  const pick = (name, value, label, hint) => option("letter", `${name}:${value}`, label, hint, letterChoices[name] === value);
  const bodies = {
    paste: ["Paste the job description", () => `<div class="letter-form flat"><textarea class="field letter-input paste" id="paste-desc" rows="8" maxlength="8000" aria-label="Job description" placeholder="Paste the whole job description">${escape2(pasteText)}</textarea><button type="button" class="btn primary big" id="popup-next" ${pasteButton().disabled ? "disabled" : ""}>${pasteButton().label}</button></div>`],
    format: ["How should it be built?", () => `<div class="stack tight">${pick("format", "match", "Match the job (recommended)", "Answers the posting's top asks, one by one")}${pick("format", "problem", "Problem, then solution", "Names what the role needs, shows you've done it")}${pick("format", "achievement", "Lead with a win", "Opens with your strongest result")}${pick("format", "story", "Short story", "Opens with a real moment from your experience")}</div>`],
    length: ["How long should it be?", () => `<div class="stack tight">${pick("length", "short", "Short", "A few lines")}${pick("length", "standard", "Standard", "The usual cover letter")}${pick("length", "detailed", "Detailed", "More on your experience")}</div>`],
    tone: ["What tone?", () => `<div class="stack tight">${pick("tone", "professional", "Professional", "Polished and direct")}${pick("tone", "warm", "Warm", "Friendly and personal")}${pick("tone", "confident", "Confident", "Leads with what you've done")}${pick("tone", "enthusiastic", "Enthusiastic", "Shows you're excited")}</div>`],
    mention: [highlights.length ? "Mention specific things from your resume" : "Anything to mention?", () => `<div class="letter-form flat">${highlights.length ? `<div class="choices" role="group" aria-label="Things from your resume">${highlights.map((item) => `<button type="button" class="choice${letterChoices.picked.includes(item) ? " on" : ""}" data-highlight="${escape2(item)}" aria-pressed="${letterChoices.picked.includes(item)}">${escape2(item)}</button>`).join("")}</div>` : ""}<textarea class="field letter-input" id="letter-mention" rows="2" maxlength="400" aria-label="Anything else to mention (optional)" placeholder="${highlights.length ? "Anything else? Optional" : "Optional: a project, why this company, a skill to lead with\u2026"}">${escape2(letterChoices.mention)}</textarea><button type="button" class="btn primary big" id="letter-write">${SPARK_SMALL}${withCost("Write cover letter", "letters")}</button>${usesLine(usesNow?.letters.note)}</div>`]
  };
  const [question, body] = bodies[steps[step]];
  return popupShell(question, `${forLine}${body()}${note}`, step, steps.length);
}
var pasteButton = () => {
  const typed = pasteText.trim().length;
  return { label: typed ? "Next" : "Write generic one", disabled: typed > 0 && typed < 80 };
};
var answering = { mode: "", question: "", length: "paragraph", answer: "", busy: false, finding: false, note: "" };
function answerPopup(state) {
  const note = answering.note ? `<p class="small" role="status">${escape2(answering.note)}</p>` : "";
  if (popup.step === 0) {
    answering.mode = "";
    const choose = (value, label, hint) => `<button type="button" class="opt" data-answer-mode="${value}">${label}<small>${hint}</small></button>`;
    return popupShell("Answer a question", `<div class="stack tight">
      ${choose("one", "One question", "Paste a question and get an answer to copy")}
      ${choose("all", "All the questions on this page", "Finds the written questions on this application and answers each one")}
    </div>${note}`);
  }
  if (answering.mode === "all") return allQuestionsPopup(state, note);
  if (answering.busy) return popupShell("Writing your answer", `<div class="letter-writing" role="status">${typingSpiderSvg(120, spiderLook)}<span class="small">Writing your answer\u2026</span></div>`);
  if (answering.answer) {
    return popupShell("Your answer", `
      <section class="letter-form flat">
        <label class="q-label" for="answer-text">Check it, change it, then copy it.</label>
        <textarea class="cv-text" id="answer-text">${escape2(answering.answer)}</textarea>
        <div class="links"><button type="button" class="solid" id="answer-copy">Copy</button><button type="button" class="link" id="answer-again">Answer another</button></div>
      </section>${note}`);
  }
  const pick = (value, label, hint) => option("answer-length", value, label, hint, answering.length === value);
  if (popup.step === 1) return popupShell("Paste the question", `<div class="letter-form flat"><textarea class="field letter-input" id="answer-q" rows="5" maxlength="600" aria-label="The question from the form" placeholder="e.g. Describe a time you led a team">${escape2(answering.question)}</textarea><button type="button" class="btn primary big" id="popup-next" ${answering.question.trim() ? "" : "disabled"}>Next</button></div>${note}`, 1, 3);
  return popupShell("How long should it be?", `<div class="stack tight">${pick("short", "A few sentences", "For short boxes on a form")}${pick("paragraph", "A paragraph", "The usual length")}${pick("long", "Longer", "For essay questions")}</div><button type="button" class="btn primary big" id="answer-write">${SPARK_SMALL}${withCost("Answer question", "answers")}</button>${usesLine(usesNow?.answers.note)}${note}`, 2, 3);
}
function allQuestionsPopup(state, note) {
  const title = "Questions on this page";
  if (answering.finding) return popupShell(title, `<div class="letter-writing" role="status">${typingSpiderSvg(110, spiderLook)}<span class="small">Looking for questions\u2026</span></div>`, 1, 0);
  const applying = state.applying;
  const questions = applying?.questions ?? [];
  if (!questions.length) {
    return popupShell(title, `<p class="note">No written questions on this page. Open the application's questions, then look again.</p>
      <button type="button" class="btn primary big" id="find-questions">Look again</button>${note}`, 1, 0);
  }
  const answers = applying.answers ?? {};
  const unanswered = questions.filter((question) => !question.answered && !answers[question.id]?.text);
  const notPut = questions.filter((question) => answers[question.id]?.text && !answers[question.id]?.put);
  const row = (question, index) => {
    const answer = answers[question.id];
    const draft = complex.drafts[question.id] ?? answer?.text ?? "";
    const status = answer?.put ? `<span class="status done">In the box \u2713</span>` : question.answered ? `<span class="status done">Already answered</span>` : "";
    return `<li class="q-row all${answer?.put ? " done" : ""}">
      <div class="q-body">
        <div class="row-between"><span class="mono">Q${index + 1}</span>${status}</div>
        <button type="button" class="q-label-link" data-show-question="${escape2(question.id)}" title="Show it on the page">${escape2(short2(question.label, 220))}${question.required ? ' <span class="req">*</span>' : ""}</button>
        ${answer?.error ? `<span class="small" style="color: var(--warn)">${escape2(answer.error)}</span>` : ""}
        ${answer?.text ? `<div class="letter-form flat"><textarea class="field letter-input" rows="5" data-draft="${escape2(question.id)}" aria-label="Answer to ${escape2(short2(question.label, 60))}">${escape2(draft)}</textarea>
          <div class="links"><button type="button" class="link" data-put="${escape2(question.id)}">${answer.put ? "Put it in again" : "Put it in the box"}</button><button type="button" class="link" data-copy="${escape2(question.id)}">Copy</button></div></div>` : question.answered ? "" : `<span class="small">Not answered yet.</span>`}
      </div>
    </li>`;
  };
  const action = complex.busy ? `<div class="letter-writing" role="status">${typingSpiderSvg(90, spiderLook)}<span class="small">Answering ${unanswered.length} ${unanswered.length === 1 ? "question" : "questions"}\u2026</span></div>` : unanswered.length ? `<button type="button" class="btn primary big" id="answer-all">${SPARK_SMALL}Answer ${unanswered.length === questions.length ? "all " : ""}${unanswered.length} ${unanswered.length === 1 ? "question" : "questions"}${answersCost(unanswered.length)}</button>${usesLine(usesNow?.answers.note)}` : notPut.length > 1 ? `<button type="button" class="btn primary big" id="put-all">Put all ${notPut.length} in their boxes</button>` : "";
  return popupShell(title, `
    <div class="q-head"><span class="heading">${questions.length} ${questions.length === 1 ? "question" : "questions"}</span><button type="button" class="quiet-link tight" id="find-questions">Look again</button></div>
    ${action}
    <ul class="q-list">${questions.map(row).join("")}</ul>
    <span class="sub">Written from your resume and profile. Read each one before you submit. Tap a question to see it on the page.</span>
    ${complex.note ? `<p class="small" role="status">${escape2(complex.note)}</p>` : ""}${note}`, 1, 0);
}
function popupView(state) {
  if (!popup || !state.connected || isRunning(state)) return "";
  return popup.kind === "cover" ? coverPopup(state) : answerPopup(state);
}
function closePopup() {
  popup = null;
  if (document.activeElement instanceof HTMLElement) document.activeElement.blur();
  void render();
}
document.addEventListener("keydown", (event) => {
  if (event.key === "Escape" && popup) closePopup();
});
var popupFocused = "";
function focusPopup() {
  const box = document.getElementById("popup");
  const key = box ? box.getAttribute("aria-label") ?? "" : "";
  if (key === popupFocused) return;
  if (box && !popupFocused) box.classList.add("entering");
  popupFocused = key;
  if (box) (box.querySelector("textarea:not(.cv-text)") ?? box).focus({ preventScroll: true });
}
function wirePopup() {
  app.querySelectorAll("[data-popup]").forEach((button) => button.addEventListener("click", () => {
    popup = { kind: button.dataset.popup, step: 0 };
    void render();
  }));
  document.getElementById("popup-close")?.addEventListener("click", closePopup);
  document.getElementById("popup-dim")?.addEventListener("click", closePopup);
  const move = (by) => () => {
    if (!popup) return;
    popup.step = Math.max(0, popup.step + by);
    if (document.activeElement instanceof HTMLElement) document.activeElement.blur();
    void render();
  };
  document.getElementById("popup-next")?.addEventListener("click", move(1));
  document.getElementById("popup-back")?.addEventListener("click", move(-1));
}
async function findQuestions(tabId) {
  answering.finding = true;
  answering.note = "";
  complex.note = "";
  void render();
  const result = await ask3({ type: "begin-applying", tabId, questionsOnly: true }).catch(() => ({ ok: false, error: "Couldn't reach the page. Reload it and try again." }));
  answering.finding = false;
  if (!result.ok) answering.note = result.error ?? "Couldn't read the page.";
  await refresh();
  void render();
}
function wireAnswer(tabId) {
  app.querySelectorAll("[data-answer-mode]").forEach((button) => button.addEventListener("click", () => {
    answering.mode = button.dataset.answerMode;
    answering.note = "";
    if (popup) popup.step = 1;
    if (answering.mode === "all") void findQuestions(tabId);
    else void render();
  }));
  document.getElementById("find-questions")?.addEventListener("click", () => void findQuestions(tabId));
  document.getElementById("answer-all")?.addEventListener("click", async () => {
    complex.busy = true;
    complex.note = "";
    void render();
    const result = await ask3({ type: "answer-complex", tabId, job: lastState ? pageJob(lastState) : null, put: false }).catch(() => ({ ok: false, error: "Couldn't reach Unnepo." }));
    complex.busy = false;
    complex.note = !result.ok ? result.error ?? "Couldn't answer them." : result.stopped ? result.stopped : result.written ? `Answered ${result.written}. Read each one, then put it in its box or copy it.` : "Couldn't write any of these. Answer them yourself.";
    await refresh();
    void render();
  });
  document.getElementById("put-all")?.addEventListener("click", async () => {
    const applying = lastState?.applying;
    if (!applying) return;
    let put = 0;
    for (const question of applying.questions) {
      const answer = applying.answers?.[question.id];
      if (!answer?.text || answer.put) continue;
      const text = complex.drafts[question.id] ?? answer.text;
      const result = await ask3({ type: "put-answer", tabId, id: question.id, text }).catch(() => ({ ok: false }));
      if (result.ok) {
        put += 1;
        delete complex.drafts[question.id];
      }
    }
    complex.note = put ? `Put ${put} in their boxes. Check them on the page.` : "Couldn't put them in. Copy each one instead.";
    await refresh();
    void render();
  });
  const box = document.getElementById("answer-q");
  box?.addEventListener("input", () => {
    answering.question = box.value;
    const next = document.getElementById("popup-next");
    if (next) next.disabled = !box.value.trim();
  });
  app.querySelectorAll("[data-answer-length]").forEach((button) => button.addEventListener("click", () => {
    answering.length = button.dataset.answerLength ?? "paragraph";
    void render();
  }));
  document.getElementById("answer-write")?.addEventListener("click", async () => {
    answering.busy = true;
    answering.note = "";
    void render();
    const result = await ask3({ type: "answer-question", tabId, question: answering.question, length: answering.length, job: lastState && jobFound(lastState) ? pageJob(lastState) : null }).catch(() => ({ ok: false, error: "Couldn't reach Unnepo." }));
    answering.busy = false;
    if (result.ok && result.answer) answering.answer = result.answer;
    else answering.note = result.error ?? "Couldn't write this one.";
    void render();
  });
  const written = document.getElementById("answer-text");
  written?.addEventListener("input", () => {
    answering.answer = written.value;
  });
  document.getElementById("answer-copy")?.addEventListener("click", () => {
    void navigator.clipboard.writeText(answering.answer).then(() => {
      answering.note = "Copied.";
      void render();
    }, () => {
      answering.note = "Couldn't copy. Select the text and copy it.";
      void render();
    });
  });
  document.getElementById("answer-again")?.addEventListener("click", () => {
    Object.assign(answering, { question: "", answer: "", note: "" });
    if (popup) popup.step = 1;
    void render();
  });
}
var letter = null;
var letterStep = "closed";
var letterNote = "";
var letterEdited = false;
var letterFor = "";
var letterChoices = { format: "match", length: "standard", tone: "professional", picked: [], mention: "", edit: "" };
var writingSpider = () => letterStep === "writing" || letterStep === "revising" ? `<div class="letter-writing" role="status">${typingSpiderSvg(150, spiderLook)}<span class="small">${letterStep === "writing" ? "Writing your cover letter\u2026" : "Rewriting your cover letter\u2026"}</span></div>` : "";
function writtenLetter(busy, forJob) {
  return `
    <div class="letter-form" id="letter-form">
      <textarea class="cv-text" id="letter-text" aria-label="Your cover letter. Edit it right here, or select part of it to have it rewritten." ${busy ? "readonly" : ""}>${escape2(letter.text)}</textarea>
      <div class="part-bar" id="part-bar" hidden role="group" aria-label="Change the selected part">
        <span class="small">Selected part:</span>
        <div class="choices">
          <button type="button" class="choice" data-part="shorter">Shorter</button>
          <button type="button" class="choice" data-part="specific">More specific</button>
          <button type="button" class="choice" data-part="confident">More confident</button>
          <button type="button" class="choice" data-part="rewrite">Rewrite</button>
        </div>
        <div class="connect-code"><input class="field" id="part-own" maxlength="300" placeholder="Or say how: mention my internship\u2026"><button type="button" class="solid" id="part-go">Go</button></div>
      </div>
      <div class="links">
        <button type="button" class="solid" id="letter-save" ${letterEdited && !busy ? "" : "hidden"}>${letterStep === "saving" ? "Saving\u2026" : "Save my edits"}</button>
        <button type="button" class="link" id="letter-copy">Copy</button>
        <button type="button" class="link" id="letter-download">Download PDF</button>
        <button type="button" class="link" id="letter-open">Open PDF</button>
        ${forJob ? `<button type="button" class="link" data-attach-letter ${attachBusy ? "disabled" : ""}>${attachBusy ? "Attaching\u2026" : "Attach to application"}</button>` : ""}
      </div>
      ${forJob && attachNote ? `<p class="small" role="status">${escape2(attachNote)}</p>` : ""}
      <label class="question"><span class="q-label">Any edits you'd like to make?</span>
        <textarea class="field letter-input" id="letter-edit" rows="2" maxlength="600" placeholder="Shorter, mention my internship, sound more excited\u2026">${escape2(letterChoices.edit)}</textarea>
      </label>
      <div class="links">
        <button type="button" class="solid" id="letter-revise" ${busy || !letterChoices.edit.trim() ? "disabled" : ""}>${letterStep === "revising" ? "Rewriting\u2026" : "Make these edits"}</button>
        <button type="button" class="link" id="letter-restart" ${busy ? "disabled" : ""}>Start over</button>
      </div>
      <p class="small">Written from your profile and resume. Click into it to change anything.${forJob ? " Your saved version is what Unnepo attaches when this application asks for a cover letter." : ""}</p>
    </div>`;
}
var letterBlobUrl = () => {
  const bytes = Uint8Array.from(atob(letter.pdfBase64), (char) => char.charCodeAt(0));
  return URL.createObjectURL(new Blob([bytes], { type: "application/pdf" }));
};
async function writeLetter(tabId, revise, fromPaste = false, save = false, part2) {
  letterStep = save ? "saving" : revise || part2 ? "revising" : "writing";
  letterNote = "";
  letterSource = fromPaste ? "paste" : "job";
  if (document.activeElement?.closest(".letter-form")) document.activeElement.blur();
  void render();
  const source = fromPaste && !pasteText.trim() ? { generic: true } : {};
  const options = part2 ? { previous: letter?.text ?? "", part: part2.part, ask: part2.ask } : save ? { text: letter?.text ?? "" } : revise ? { previous: letter?.text ?? "", edit: letterChoices.edit } : { format: letterChoices.format, length: letterChoices.length, tone: letterChoices.tone, mention: [...letterChoices.picked, letterChoices.mention.trim()].filter(Boolean).join("; ") };
  const job = !fromPaste && lastState ? pageJob(lastState) : null;
  const result = await ask3({ type: "generate-letter", tabId, options: { ...options, ...source }, ...fromPaste ? { description: pasteText } : {}, ...job ? { job } : {} }).catch(() => ({ ok: false, error: "Couldn't reach Unnepo." }));
  if (result.ok && result.doc) {
    letter = result.doc;
    letterStep = "written";
    letterEdited = false;
    if (revise) letterChoices.edit = "";
    if (save) letterNote = "Saved. The PDF has your edits.";
    if (result.doc.upgrade && !save) letterNote = `A general letter. ${result.doc.upgrade}`;
  } else {
    letterStep = letter ? "written" : "closed";
    letterNote = result.error ?? "Couldn't write the cover letter.";
  }
  if (document.activeElement?.closest(".letter-form")) document.activeElement.blur();
  void render();
}
function wireLetter(tabId, fromPaste) {
  document.getElementById("letter-restart")?.addEventListener("click", () => {
    letterStep = "closed";
    letterNote = "";
    if (popup) popup.step = 0;
    void render();
  });
  app.querySelectorAll("[data-letter]").forEach((button) => button.addEventListener("click", () => {
    const [name, value] = (button.dataset.letter ?? "").split(":");
    letterChoices[name] = value;
    if (popup) popup.step += 1;
    void render();
  }));
  app.querySelectorAll("[data-highlight]").forEach((button) => button.addEventListener("click", () => {
    const item = button.dataset.highlight ?? "";
    letterChoices.picked = letterChoices.picked.includes(item) ? letterChoices.picked.filter((other) => other !== item) : [...letterChoices.picked, item];
    if (document.activeElement instanceof HTMLElement) document.activeElement.blur();
    void render();
  }));
  const mention = document.getElementById("letter-mention");
  mention?.addEventListener("input", () => {
    letterChoices.mention = mention.value;
  });
  const edits = document.getElementById("letter-edit");
  const revise = document.getElementById("letter-revise");
  edits?.addEventListener("input", () => {
    letterChoices.edit = edits.value;
    if (revise && letterStep === "written") revise.disabled = !edits.value.trim();
  });
  document.getElementById("letter-write")?.addEventListener("click", () => void writeLetter(tabId, false, fromPaste));
  revise?.addEventListener("click", () => void writeLetter(tabId, true, fromPaste));
  const paste = document.getElementById("paste-desc");
  paste?.addEventListener("input", () => {
    pasteText = paste.value;
    const next = document.getElementById("popup-next");
    if (next) {
      next.disabled = pasteButton().disabled;
      next.textContent = pasteButton().label;
    }
  });
  const typed = document.getElementById("letter-text");
  const partBar = document.getElementById("part-bar");
  let part2 = "";
  const showPartBar = () => {
    if (!typed || !partBar) return;
    const chosen = typed.value.slice(typed.selectionStart, typed.selectionEnd);
    if (chosen.trim().length >= 12) part2 = chosen;
    partBar.hidden = !part2 || chosen.trim().length < 12 && document.activeElement === typed;
  };
  typed?.addEventListener("select", showPartBar);
  typed?.addEventListener("mouseup", showPartBar);
  typed?.addEventListener("keyup", showPartBar);
  const rewrite = (ask4) => {
    if (!part2 || !ask4.trim()) return;
    if (letterEdited) letterEdited = false;
    void writeLetter(tabId, false, fromPaste, false, { part: part2, ask: ask4 });
  };
  partBar?.querySelectorAll("[data-part]").forEach((button) => button.addEventListener("click", () => rewrite(button.dataset.part)));
  document.getElementById("part-go")?.addEventListener("click", () => rewrite(document.getElementById("part-own").value));
  const save = document.getElementById("letter-save");
  typed?.addEventListener("input", () => {
    letter.text = typed.value;
    letterEdited = true;
    if (save) save.hidden = false;
  });
  save?.addEventListener("click", () => void writeLetter(tabId, false, fromPaste, true));
  const pdfReady = async () => {
    if (letterEdited) await writeLetter(tabId, false, fromPaste, true);
    return !letterEdited;
  };
  document.getElementById("letter-copy")?.addEventListener("click", () => {
    void navigator.clipboard.writeText(letter.text).then(() => {
      letterNote = "Copied.";
      void render();
    }, () => {
      letterNote = "Couldn't copy. Select the text and copy it.";
      void render();
    });
  });
  document.getElementById("letter-download")?.addEventListener("click", async () => {
    if (!await pdfReady()) return;
    const link = document.createElement("a");
    link.href = letterBlobUrl();
    link.download = letter.fileName;
    link.click();
  });
  document.getElementById("letter-open")?.addEventListener("click", async () => {
    if (await pdfReady()) void chrome.tabs.create({ url: letterBlobUrl() });
  });
}
var resumeNote = "";
var resumeBusy = false;
function resumeLine(state) {
  const resume = state.me.resume;
  const name = resume ? escape2(resume.fileName) : "None yet";
  const note = resumeNote || (resume && !resume.file ? "Unnepo only has this resume's text, not the file. Change it so it can be attached." : "");
  return `
    <div class="tool-line">
      <span class="tool-what">Resume</span>
      ${resume?.file ? `<button type="button" class="resume-link" id="open-resume" title="Open ${name}" ${resumeBusy ? "disabled" : ""}><span class="resume-link-name">${name}</span></button>` : `<span class="tool-value">${name}</span>`}
      <button type="button" class="tool-change" id="replace-resume" ${resumeBusy ? "disabled" : ""}>${resume ? "Change" : "Upload"}</button>
    </div>
    ${resume?.file ? `<button type="button" class="btn attach-btn" id="attach-resume" ${resumeAttach.busy ? "disabled" : ""}>${resumeAttach.busy ? "Attaching\u2026" : "Attach resume to this application"}</button>` : ""}
    ${resumeAttach.note ? `<p class="small tool-note" role="status">${escape2(resumeAttach.note)}</p>` : ""}
    ${note ? `<p class="small tool-note" role="status">${escape2(note)}</p>` : ""}`;
}
var resumeAttach = { busy: false, note: "" };
async function attachResume() {
  const tabId = lastState?.tab?.id;
  if (tabId === void 0 || resumeAttach.busy) return;
  resumeAttach.busy = true;
  resumeAttach.note = "";
  void render();
  const result = await ask3({ type: "attach-resume", tabId }).catch(() => ({ ok: false, error: "Couldn't reach the page. Reload it and try again." }));
  resumeAttach.busy = false;
  resumeAttach.note = result.ok && result.attached?.length ? `\u2713 Attached to \u201C${short2(result.attached[0], 40)}\u201D. Check it on the page.` : result.error ?? "Couldn't attach it.";
  void render();
}
var attachNote = "";
var attachBusy = false;
function letterLine() {
  if (!letter?.pdfBase64) return "";
  return `
    <div class="tool-line">
      <span class="tool-what">Cover letter</span>
      <span class="tool-value">${escape2(letter.fileName)}</span>
      <button type="button" class="tool-change" data-attach-letter ${attachBusy ? "disabled" : ""}>${attachBusy ? "Attaching\u2026" : "Attach"}</button>
    </div>
    ${attachNote ? `<p class="small tool-note" role="status">${escape2(attachNote)}</p>` : ""}`;
}
async function attachLetter() {
  const tabId = lastState?.tab?.id;
  if (!letter?.pdfBase64 || tabId === void 0 || attachBusy) return;
  if (letterEdited) {
    attachNote = "Save your edits to the letter first, so the PDF has them.";
    return void render();
  }
  attachBusy = true;
  attachNote = "";
  void render();
  const result = await ask3({ type: "attach-letter", tabId, file: { name: letter.fileName, mime: "application/pdf", base64: letter.pdfBase64 } }).catch(() => ({ ok: false, error: "Couldn't reach the page. Reload it and try again." }));
  attachBusy = false;
  attachNote = result.ok && result.attached?.length ? `\u2713 Attached to \u201C${short2(result.attached[0], 40)}\u201D. Check it on the page.` : result.error ?? "Couldn't attach it.";
  void render();
}
async function seeResume() {
  resumeBusy = true;
  resumeNote = "Opening\u2026";
  void render();
  const result = await ask3({ type: "get-resume" });
  resumeBusy = false;
  if (result.ok && result.file) {
    const bytes = Uint8Array.from(atob(result.file.base64), (char) => char.charCodeAt(0));
    void chrome.tabs.create({ url: URL.createObjectURL(new Blob([bytes], { type: result.file.mime })) });
    resumeNote = "";
  } else {
    resumeNote = `${result.error ?? "Couldn't open your resume."} Change it to fix this.`;
  }
  void render();
}
async function replaceResume(file) {
  if (!/\.(pdf|docx)$/i.test(file.name)) {
    resumeNote = "Choose a PDF or DOCX file.";
    return void render();
  }
  if (file.size > 10 * 1024 * 1024) {
    resumeNote = "Resumes need to be 10 MB or smaller.";
    return void render();
  }
  resumeBusy = true;
  resumeNote = "Uploading and reading your resume\u2026";
  void render();
  const bytes = new Uint8Array(await file.arrayBuffer());
  let binary = "";
  for (let index = 0; index < bytes.length; index += 32768) binary += String.fromCharCode(...bytes.subarray(index, index + 32768));
  const result = await ask3({ type: "upload-resume", name: file.name, mime: file.type || "application/pdf", base64: btoa(binary) });
  resumeBusy = false;
  resumeNote = result.ok ? "New resume saved. It goes on every application from now on." : result.error ?? "Upload failed.";
  void render();
}
function profileCard(state) {
  const me = state.me;
  const missing = me.missing ?? [];
  const credits = me.unlimitedCredits ? "Unlimited" : me.trial ? "Pro trial" : me.usage?.free ? "Resets every day" : `${me.usage?.credits ?? me.credits * 5} credits left`;
  const plan = me.trial ? "Pro trial" : (me.effectivePlan ?? me.plan ?? "free").replace(/^\w/, (letter2) => letter2.toUpperCase());
  const name = me.user.name || me.user.email;
  const initials2 = name.split(/[\s@.]+/).filter(Boolean).slice(0, 2).map((part2) => part2[0].toUpperCase()).join("");
  return `
    <section class="page settings-card" aria-label="Account">
      <div class="account-head">
        <span class="account-av" aria-hidden="true">${escape2(initials2 || "?")}</span>
        <span class="account-text"><span class="account-name">${escape2(name)}</span>${me.user.name ? `<span class="sub">${escape2(me.user.email)}</span>` : ""}</span>
      </div>
      <div class="account-plan"><span><strong>${escape2(plan)}</strong> \xB7 ${credits}</span><a class="link" href="${escape2(state.apiBase)}/home?tab=settings#plans" target="_blank" rel="noreferrer">Plans \u2197</a></div>
      ${me.admin ? adminPlanSwitch(me.planPreview ?? null) : ""}
      ${me.usage?.free ? `<span class="small">Left today: ${me.usage.letters.left} cover letters \xB7 ${me.usage.answers.left} answers \xB7 ${me.usage.autofills.left} autofills. People: ${escape2(me.usage.people.badge ?? `${me.usage.people.left} left`)}</span>` : ""}
      ${me.completeness < 100 ? `<div class="row-between"><span class="small"${!me.profileReady ? ' style="color: var(--warn)"' : ""}>Profile ${me.completeness}% done${missing.length ? `: ${missing.map(escape2).join(", ")}` : ""}</span></div>
      <div class="bar" role="progressbar" aria-label="Profile ready" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${me.completeness}"><div style="width:${me.completeness}%"></div></div>` : ""}
      <a class="link" href="${escape2(state.apiBase)}/home?edit=profile" target="_blank" rel="noreferrer">${me.completeness < 100 ? "Finish my profile" : "Edit my profile"} \u2197</a>
    </section>`;
}
var planSwitching = false;
function adminPlanSwitch(preview) {
  const chip = (value, label) => {
    const on = (preview ?? "real") === value;
    return `<button type="button" class="chip${on ? " on" : ""}" data-plan-preview="${value}" aria-pressed="${on}" ${planSwitching ? "disabled" : ""}>${label}</button>`;
  };
  return `<div class="row-between"><span class="small">Admin \xB7 view as</span><div class="chips" role="group" aria-label="View Unnepo as">${chip("real", "My plan")}${chip("free", "Free")}${chip("pro", "Pro")}</div></div>`;
}
function wirePlanSwitch() {
  document.querySelectorAll("[data-plan-preview]").forEach((button) => button.addEventListener("click", async () => {
    const value = button.dataset.planPreview;
    planSwitching = true;
    void render();
    const result = await ask3({ type: "plan-preview", plan: value === "real" ? null : value }).catch(() => ({ ok: false, error: "Couldn't reach Unnepo." }));
    planSwitching = false;
    if (!result.ok) alert(result.error ?? "Couldn't switch plans.");
    void loadTracker(true);
    void render();
  }));
}
var issueList = null;
var issueNote = "";
var issuesLoading = false;
async function loadIssues() {
  if (issuesLoading) return;
  issuesLoading = true;
  const result = await ask3({ type: "list-issues" }).catch(() => ({ issues: [] }));
  issuesLoading = false;
  issueList = result.issues ?? [];
  void render();
}
var KIND = { fill: "Didn't fill", site: "Site error", stopped: "Stopped", note: "Your note" };
var when2 = (at) => new Date(at).toLocaleString(void 0, { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" });
function issuesText(list) {
  const head = `Unnepo extension issues (V${extensionVersion()}), copied ${(/* @__PURE__ */ new Date()).toLocaleString()}. ${list.length} ${list.length === 1 ? "entry" : "entries"}, newest first.`;
  const rows = list.map((issue, index) => [
    `${index + 1}. ${when2(issue.at)} \xB7 ${KIND[issue.kind]} \xB7 ${issue.site || "no page"}`,
    issue.question ? `   Question: ${issue.question}` : "",
    `   ${issue.what}`,
    issue.page ? `   Page: ${issue.page}` : ""
  ].filter(Boolean).join("\n"));
  return [head, "", ...rows].join("\n");
}
function issuesCard() {
  if (!issueList) void loadIssues();
  const list = issueList ?? [];
  return `
    <section class="view issues" aria-label="Issues">
      <span class="mono">${list.length} SAVED</span>
      <p class="small">Problems Unnepo ran into, and ones you report. Copy them all to send to support. Kept only on this computer.</p>
      <div class="letter-form">
        <textarea class="field letter-input" id="issue-note" rows="2" maxlength="500" placeholder="What went wrong? (saved with this tab's page)" aria-label="Report a problem">${escape2(issueNote)}</textarea>
        <div class="links">
          <button type="button" class="solid" id="add-issue" ${issueNote.trim() ? "" : "disabled"}>Report a problem</button>
          ${list.length ? `<button type="button" class="link" id="copy-issues">Copy all</button><button type="button" class="link" id="clear-issues">Clear</button>` : ""}
        </div>
        <span class="small" id="issues-status" role="status"></span>
      </div>
      ${!issueList ? `<p class="note">Loading\u2026</p>` : !list.length ? `<p class="note">Nothing yet. Problems show up here as Unnepo fills applications.</p>` : `
        <ul class="issue-list">${list.slice(0, 50).map((issue) => `
          <li>
            <span class="issue-top"><span class="status${issue.kind === "note" ? " done" : ""}">${KIND[issue.kind]}</span><span class="mono">${escape2(when2(issue.at))}</span></span>
            ${issue.question ? `<span class="issue-question">${escape2(short2(issue.question, 80))}</span>` : ""}
            <span class="small">${escape2(short2(issue.what, 160))}</span>
            ${issue.site ? `<span class="mono">${escape2(issue.site)}</span>` : ""}
          </li>`).join("")}</ul>
        ${list.length > 50 ? `<p class="small">Showing the newest 50. Copy all includes all ${list.length}.</p>` : ""}`}
    </section>`;
}
function wireIssues() {
  const note = document.getElementById("issue-note");
  const add = document.getElementById("add-issue");
  const said = (text) => {
    const status = document.getElementById("issues-status");
    if (status) status.textContent = text;
  };
  note?.addEventListener("input", () => {
    issueNote = note.value;
    if (add) add.disabled = !note.value.trim();
  });
  add?.addEventListener("click", async () => {
    const text = issueNote.trim();
    if (!text) return;
    await ask3({ type: "add-issue", note: text });
    issueNote = "";
    issueList = null;
    void render();
  });
  document.getElementById("copy-issues")?.addEventListener("click", async () => {
    await navigator.clipboard.writeText(issuesText(issueList ?? [])).then(() => said("Copied. Paste it into your chat."), () => said("Couldn't copy. Try again."));
  });
  document.getElementById("clear-issues")?.addEventListener("click", async () => {
    if (!confirm("Clear the issues list? Copy it first if you still need it.")) return;
    await ask3({ type: "clear-issues" });
    issueList = null;
    void render();
  });
}
var passwordMode = "hidden";
var passwordNote = "";
var passwordCopied = false;
var COPY_ICON = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="9" y="9" width="11" height="11" rx="2"/><path d="M5 15V5a1 1 0 0 1 1-1h10"/></svg>`;
async function renderPassword() {
  const { password } = await ask3({ type: "get-password" });
  if (!password) return;
  const rules = (value) => PASSWORD_RULES.map((rule) => `<li class="${rule.test(value) ? "met" : ""}">${escape2(rule.label)}</li>`).join("");
  const editing2 = passwordMode === "editing";
  passwordSection.innerHTML = `
    <div class="tool-line">
      <span class="tool-what">Job-site password</span>
      ${passwordCopied ? `<span class="tool-value copied" role="status">\u2713 Copied</span>` : editing2 ? `<span class="tool-value"></span>` : `<button type="button" class="stars" id="copy-password" aria-label="Copy job-site password" title="Copy">************${COPY_ICON}</button>`}
      <button type="button" class="tool-change" id="${editing2 ? "cancel-password" : "change-password"}">${editing2 ? "Cancel" : "Change"}</button>
    </div>
    ${editing2 ? `
      <input class="field" type="text" id="new-password" autocomplete="off" spellcheck="false" placeholder="Your new password" aria-label="New password">
      <ul class="rules" id="rules">${rules("")}</ul>
      <p class="small">Accounts Unnepo already made keep working with the password they were made with.</p>
      <div class="links"><button type="button" class="solid" id="save-password" disabled>Save password</button><button type="button" class="link" id="regenerate-password">Make a new one for me</button></div>
    ` : ""}
    ${passwordNote ? `<p class="small tool-note" role="status">${escape2(passwordNote)}</p>` : ""}`;
  const redraw2 = (mode, note = "") => {
    passwordMode = mode;
    passwordNote = note;
    void renderPassword();
  };
  document.getElementById("copy-password")?.addEventListener("click", async () => {
    await navigator.clipboard.writeText(password).then(() => {
      passwordCopied = true;
      setTimeout(() => {
        passwordCopied = false;
        void renderPassword();
      }, 1500);
      redraw2(passwordMode);
    }, () => redraw2(passwordMode, "Couldn't copy. Try again."));
  });
  document.getElementById("change-password")?.addEventListener("click", () => redraw2("editing"));
  document.getElementById("cancel-password")?.addEventListener("click", () => redraw2("hidden"));
  document.getElementById("regenerate-password")?.addEventListener("click", async () => {
    if (!confirm("Make a new password? Accounts Unnepo already made keep working: it remembers the password each one was made with. Accounts you made yourself aren't changed.")) return;
    await ask3({ type: "new-password" });
    redraw2("hidden", "New password made. Press the stars to copy it.");
  });
  const input = document.getElementById("new-password");
  const save = document.getElementById("save-password");
  input?.focus();
  input?.addEventListener("input", () => {
    document.getElementById("rules").innerHTML = rules(input.value);
    save.disabled = unmetRules(input.value).length > 0;
  });
  save?.addEventListener("click", async () => {
    const result = await ask3({ type: "set-password", value: input.value });
    if (result.ok) redraw2("hidden", "Password saved.");
    else passwordNote = `Still needs: ${(result.unmet ?? []).join(", ").toLowerCase()}.`;
  });
}
var manualJob = { open: false, key: "", title: "", company: "", url: "", stage: "applied", note: "", saving: false, readFor: "", description: "" };
function startManualJob(state) {
  const key = state.tab?.url ?? "";
  if (manualJob.key === key) return;
  const parts = (state.tab?.title ?? "").replace(/^\(\d+\)\s*/, "").split(/ [|\-–] /).map((part2) => part2.trim()).filter(Boolean);
  const url = /^https:\/\//.test(key) ? key : "";
  Object.assign(manualJob, { key, title: parts.length >= 2 ? parts[0] : "", company: parts.length >= 3 ? parts[1] : "", url, note: "", saving: false, readFor: "", description: "" });
}
function manualJobForm() {
  if (!manualJob.open) return `<button type="button" class="btn" id="add-job-open">+ Add a job I applied to</button>${manualJob.note ? `<p class="small" role="status">${escape2(manualJob.note)}</p>` : ""}`;
  const ready = manualJob.title.trim().length >= 2 && manualJob.company.trim().length >= 2;
  const stage = (value, label) => `<option value="${value}"${manualJob.stage === value ? " selected" : ""}>${label}</option>`;
  return `
    <div class="letter-form" id="add-job-form">
      <span class="eyebrow">Add a job</span>
      <label class="question"><span class="q-label">Job title</span><input class="field" id="mj-title" value="${escape2(manualJob.title)}" maxlength="200" placeholder="Growth Marketing Intern"></label>
      <label class="question"><span class="q-label">Company</span><input class="field" id="mj-company" value="${escape2(manualJob.company)}" maxlength="200" placeholder="MealPal"></label>
      <label class="question"><span class="q-label">Job link</span><input class="field" id="mj-url" value="${escape2(manualJob.url)}" maxlength="2000" placeholder="https://\u2026"></label>
      <div class="links"><button type="button" class="link" id="mj-fill" ${linkReading ? "disabled" : ""}>${linkReading ? "Reading the link\u2026" : "Fill in the job information"}</button></div>
      <label class="question"><span class="q-label">Status</span><select class="field" id="mj-stage">${stage("applied", "Applied")}${stage("in_progress", "Not applied yet")}${stage("follow_up", "Follow up")}${stage("interviewing", "Interviewing")}${stage("rejected", "Rejected")}</select></label>
      <div class="links">
        <button type="button" class="solid" id="mj-save" ${ready && !manualJob.saving ? "" : "disabled"}>${manualJob.saving ? "Adding\u2026" : "Add to tracker"}</button>
        <button type="button" class="link" id="mj-cancel">Cancel</button>
      </div>
      ${manualJob.note ? `<p class="small" role="status">${escape2(manualJob.note)}</p>` : ""}
    </div>`;
}
function wireManualJob(state) {
  document.getElementById("add-job-open")?.addEventListener("click", () => {
    startManualJob(state);
    manualJob.open = true;
    manualJob.note = "";
    void render();
  });
  document.getElementById("mj-cancel")?.addEventListener("click", () => {
    manualJob.open = false;
    void render();
  });
  for (const [id, key] of [["mj-title", "title"], ["mj-company", "company"], ["mj-url", "url"], ["mj-stage", "stage"]]) {
    const box = document.getElementById(id);
    box?.addEventListener(box instanceof HTMLSelectElement ? "change" : "input", () => {
      manualJob[key] = box.value;
      const save = document.getElementById("mj-save");
      if (save) save.disabled = manualJob.title.trim().length < 2 || manualJob.company.trim().length < 2 || manualJob.saving;
    });
  }
  const fillManual = async (force) => {
    const url = manualJob.url.trim();
    if (linkReading) return;
    if (!force && (!/^https:\/\/\S+\.\S+/.test(url) || url === manualJob.readFor)) return;
    manualJob.readFor = url;
    manualJob.note = "";
    const result = await readJobLink(url);
    if (result.info) {
      manualJob.title = keepTyped(manualJob.title, result.info.title);
      manualJob.company = keepTyped(manualJob.company, result.info.company);
      manualJob.description ||= result.info.description;
      manualJob.note = manualJob.company.trim() ? "Filled in from the link. Check it, then add it." : "Filled in from the link. Type the company: the page didn't say.";
    } else manualJob.note = result.error ?? "Couldn't read the link. Type the details.";
    void render();
  };
  document.getElementById("mj-url")?.addEventListener("change", () => void fillManual(false));
  document.getElementById("mj-fill")?.addEventListener("click", () => void fillManual(true));
  document.getElementById("mj-save")?.addEventListener("click", async () => {
    manualJob.saving = true;
    manualJob.note = "";
    void render();
    const result = await ask3({ type: "add-job", job: { title: manualJob.title, company: manualJob.company, url: manualJob.url.trim(), stage: manualJob.stage, description: manualJob.description } }).catch(() => ({ ok: false, error: "Couldn't reach Unnepo." }));
    manualJob.saving = false;
    if (result.ok) {
      manualJob.note = `Added: ${manualJob.title} at ${manualJob.company}.`;
      manualJob.open = false;
      manualJob.key = "";
      void loadTracker(true);
    } else manualJob.note = result.error ?? "Couldn't add it.";
    if (document.activeElement?.closest(".letter-form")) document.activeElement.blur();
    void render();
  });
}
function jobsView(state) {
  ensureTracker();
  return `
    <div class="jobs-log">
      ${manualJobForm()}
      ${jobFound(state) && !manualJob.open ? hereLinks() : ""}
      ${here.note ? `<p class="small" role="status">${escape2(here.note)}</p>` : ""}
      ${detectedMenu()}
    </div>
    <div class="section-divider" role="separator"><span>Tools</span></div>
    ${toolsPage(state)}`;
}
var tracking = null;
void chrome.storage.local.get(["autoDetect", "mailer", "notify"]).then((stored) => {
  tracking = { autoDetect: stored.autoDetect === "ask" ? "ask" : "auto", mailer: stored.mailer ?? "gmail", notify: stored.notify !== false };
});
function trackingSettings(state) {
  if (!tracking) return "";
  const option2 = (name, value, label, on) => `<label class="check"><input type="radio" name="${name}" value="${value}" ${on ? "checked" : ""}>${label}</label>`;
  const mail = (value, label) => `<option value="${value}"${tracking.mailer === value ? " selected" : ""}>${label}</option>`;
  return `
    <section class="page settings-card" aria-label="Settings">
      <span class="eyebrow">Settings</span>
      <div class="stack tight">
        <span class="q-label">When a site confirms you applied</span>
        ${option2("auto-detect", "auto", "Save it to my jobs (with Undo)", tracking.autoDetect === "auto")}
        ${option2("auto-detect", "ask", "Ask me first", tracking.autoDetect === "ask")}
      </div>
      <label class="question"><span class="q-label">Email links open in</span>
        <select class="field" id="mailer">${mail("gmail", "Gmail")}${mail("outlook", "Outlook on the web")}${mail("mailto", "My computer's mail app")}</select>
      </label>
      <label class="check"><input type="checkbox" id="notify" ${tracking.notify ? "checked" : ""}>Remind me once a day when follow-ups are due</label>
      <label class="check"><input type="checkbox" id="pause" ${state.autoSubmit ? "" : "checked"}><span>Autofill <span class="beta">Beta</span> stops at Submit so I can check it</span></label>
    </section>`;
}
function wireTracking() {
  app.querySelectorAll('input[name="auto-detect"]').forEach((input) => input.addEventListener("change", () => {
    tracking.autoDetect = input.value;
    void chrome.storage.local.set({ autoDetect: input.value });
  }));
  document.getElementById("mailer")?.addEventListener("change", (event) => {
    const value = event.target.value;
    tracking.mailer = value;
    store.mailer = value;
    void chrome.storage.local.set({ mailer: value });
    event.target.blur();
  });
  document.getElementById("notify")?.addEventListener("change", (event) => {
    tracking.notify = event.target.checked;
    void chrome.storage.local.set({ notify: tracking.notify });
  });
}
var resumeInput = document.getElementById("resume-input");
resumeInput.addEventListener("change", () => {
  const file = resumeInput.files?.[0];
  resumeInput.value = "";
  if (file) void replaceResume(file);
});
var dressed = "";
var spiderLook;
function dressSpider(look) {
  const key = look ? `${look.skin}|${look.school ?? ""}` : "";
  if (!look || key === dressed) return;
  dressed = key;
  spiderLook = look;
  const spider = document.getElementById("spider");
  spider.querySelector("svg")?.remove();
  spider.insertAdjacentHTML("beforeend", heroSpiderSvg(look));
}
var travelling = 0;
var heroRect = () => document.querySelector("#spider svg").getBoundingClientRect();
function laptopRect() {
  const svg = app.querySelector(".letter-writing svg");
  if (!svg) return null;
  const box = svg.getBoundingClientRect();
  const scale = box.width / 60;
  return { left: box.left + 10 * scale, top: box.top + scale, width: 40 * scale, height: 30 * scale };
}
function travel(from, to, ms, landed) {
  const trip = ++travelling;
  document.querySelector(".rappel")?.remove();
  const anchorX = heroRect().left + heroRect().width / 2;
  const box = document.createElement("div");
  box.className = "rappel";
  box.setAttribute("aria-hidden", "true");
  box.innerHTML = `<div class="rappel-thread"></div><div class="rappel-spider">${document.querySelector("#spider svg").outerHTML}</div>`;
  document.body.append(box);
  const thread = box.children[0];
  const spider = box.children[1];
  const place = (x, y, shrink = 1) => {
    const dx = x + from.width / 2 - anchorX;
    const dy = y + 12;
    thread.style.transform = `translate(${anchorX}px, 0) rotate(${-Math.atan2(dx, dy)}rad)`;
    thread.style.height = `${Math.hypot(dx, dy) * shrink}px`;
  };
  const start = performance.now();
  const frame = (now) => {
    if (trip !== travelling) return box.remove();
    const t = Math.min(1, (now - start) / ms);
    const eased = t < 0.5 ? 2 * t * t : 1 - (2 - 2 * t) ** 2 / 2;
    const sway = Math.sin(t * Math.PI * 3) * 8 * (1 - t);
    const x = Math.round((from.left + (to.left - from.left) * eased + sway) / 2) * 2;
    const y = Math.round((from.top + (to.top - from.top) * eased) / 2) * 2;
    spider.style.transform = `translate(${x}px, ${y}px)`;
    place(x, y);
    if (t < 1) return void requestAnimationFrame(frame);
    spider.remove();
    landed();
    const pulled = performance.now();
    const pull = (later) => {
      if (trip !== travelling) return box.remove();
      const left = 1 - (later - pulled) / 200;
      if (left <= 0) return box.remove();
      place(x, y, left);
      requestAnimationFrame(pull);
    };
    requestAnimationFrame(pull);
  };
  requestAnimationFrame(frame);
}
var stillMotion = matchMedia("(prefers-reduced-motion: reduce)").matches;
var lastFill = null;
function moveSpider(state, shown, wasAt) {
  const running = isRunning(state);
  const same = lastFill?.tab === state.tab?.id;
  const started = shown && same && running && !lastFill.running;
  const ended = !shown && same && !running && lastFill.shown;
  lastFill = { tab: state.tab?.id, running, shown };
  const { classList } = document.body;
  const at = laptopRect();
  if (started && at && !stillMotion) {
    classList.add("spider-away", "spider-landing");
    travel(heroRect(), at, 1200, () => classList.remove("spider-landing"));
  } else if (ended && wasAt && !stillMotion) {
    classList.add("spider-away");
    classList.remove("spider-landing");
    travel(wasAt, heroRect(), 900, () => classList.remove("spider-away"));
  } else if (shown !== classList.contains("spider-away") && !document.querySelector(".rappel-spider")) {
    classList.toggle("spider-away", shown);
    classList.remove("spider-landing");
  }
}
var lastState = null;
var drawnFrom = "";
var fetching = false;
var fetchAgain = false;
async function refresh() {
  if (fetching) {
    fetchAgain = true;
    return;
  }
  fetching = true;
  try {
    do {
      fetchAgain = false;
      const state = await ask3({ type: "state" });
      const json = JSON.stringify(state);
      lastState = state;
      if (json !== drawnFrom) drawnFrom = draw(state) ? json : "";
    } while (fetchAgain);
  } finally {
    fetching = false;
  }
}
async function render() {
  if (lastState) draw(lastState);
  await refresh();
}
function draw(state) {
  usesNow = state.me?.usage ?? null;
  const jobName = (state.job?.title || state.page?.title || "").toLowerCase();
  const letterJob = state.tab && jobName ? `${state.tab.id}|${jobName}` : letterFor;
  if (letterJob !== letterFor) {
    if (letterFor && letterSource === "job" && letterStep !== "writing" && letterStep !== "revising") {
      letter = null;
      letterStep = "closed";
      letterNote = "";
      letterChoices.picked = [];
      letterChoices.mention = "";
      letterChoices.edit = "";
    }
    letterFor = letterJob;
  }
  dressSpider(state.me?.spider);
  const said = lines(state);
  speech(said.lines, said.alert);
  if (!state.connected) view = "home";
  if (state.job?.running && fillPending === state.tab?.id) fillPending = null;
  tabBar.hidden = !state.connected;
  planBadge.innerHTML = !state.connected || !state.me ? "" : onFree(state) ? `<a class="plan-badge" href="${escape2(upgradeUrl(state))}" target="_blank" rel="noreferrer">Upgrade to Pro</a>` : `<span class="plan-badge pro">${state.me.trial ? "Pro trial" : "Pro"}</span>`;
  const tabNow = view === "job" ? jobFrom : view === "feedback" ? "settings" : view;
  const badge = (element, count) => {
    element.textContent = count ? String(count) : "";
    element.hidden = !count;
  };
  const asking = (store.detected ?? []).filter((item) => item.state === "ask").length;
  badge(jobsBadge, state.connected ? firstEmailCount() + asking : 0);
  badge(meBadge, state.connected ? friendRequests() : 0);
  tabBar.querySelectorAll("[data-tab]").forEach((tab) => {
    const on = tab.dataset.tab === tabNow;
    tab.classList.toggle("on", on);
    if (on) tab.setAttribute("aria-current", "page");
    else tab.removeAttribute("aria-current");
  });
  if (!state.connected && document.getElementById("code") === document.activeElement) return false;
  if (document.activeElement?.closest(".letter-form") && document.activeElement.matches("textarea, input")) return false;
  if (document.activeElement?.matches("#password input")) return false;
  if (document.activeElement?.matches("#job-search, #friend-email")) return false;
  if (document.activeElement instanceof HTMLSelectElement && app.contains(document.activeElement)) return false;
  if (document.activeElement?.closest("#here-form") && document.activeElement.matches("input")) return false;
  document.body.append(passwordSection);
  const shown = state.connected && view === "home" && isRunning(state);
  const wasAt = shown ? null : laptopRect();
  if (shown) popup = null;
  app.innerHTML = !state.connected ? connectView(state) : `${view === "home" ? homeView(state) : pageView(state)}${popupView(state)}`;
  focusPopup();
  moveSpider(state, shown, wasAt);
  const slot = document.getElementById("password-slot");
  passwordSection.hidden = !slot;
  if (!state.connected) {
    passwordMode = "hidden";
    passwordSection.innerHTML = "";
  }
  if (slot) {
    slot.append(passwordSection);
    if (!passwordSection.innerHTML.trim()) void renderPassword();
  }
  app.querySelectorAll("[data-go]").forEach((button) => button.addEventListener("click", () => go(button.dataset.go)));
  app.querySelectorAll("details.part").forEach((details2) => details2.addEventListener("toggle", () => {
    const id = details2.dataset.partId;
    if (details2.open === openParts.has(id)) return;
    if (details2.open) openParts.add(id);
    else openParts.delete(id);
    void render();
  }));
  wireJobRows(app);
  app.querySelectorAll("[data-open-saved]").forEach((button) => button.addEventListener("click", () => openJob(button.dataset.openSaved)));
  if (state.connected) {
    wireDetected(app);
    wireReminders(app);
    wireBubbles(app);
    wireWeek(app);
    wireFriends(app);
    wireJobsList(app);
    app.querySelectorAll("[data-show-jobs]").forEach((button) => button.addEventListener("click", () => {
      showJobs("reach");
      go("home");
    }));
    const job = view === "job" ? jobById(openedJob.id) : null;
    if (job) wireJobPage(app, job);
    wireTracking();
  }
  document.getElementById("use-code")?.addEventListener("click", async () => {
    const code = document.getElementById("code").value.trim();
    if (code.startsWith("unx_")) await ask3({ type: "connect", token: code });
    void render();
  });
  document.getElementById("fill")?.addEventListener("click", () => {
    const tabId = state.tab.id;
    fillPending = tabId;
    void ask3({ type: "fill", tabId });
    setTimeout(() => {
      if (fillPending === tabId) {
        fillPending = null;
        void render();
      }
    }, 5e3);
    void render();
  });
  document.getElementById("beta-fill")?.addEventListener("click", () => {
    const tabId = state.tab.id;
    fillPending = tabId;
    void ask3({ type: "fill", tabId, beta: true });
    setTimeout(() => {
      if (fillPending === tabId) {
        fillPending = null;
        void render();
      }
    }, 5e3);
    go("home");
  });
  document.getElementById("stop")?.addEventListener("click", () => {
    fillPending = null;
    void ask3({ type: "stop", tabId: state.tab.id });
  });
  document.getElementById("skip-job")?.addEventListener("click", () => dismiss(state, "skipped"));
  document.getElementById("not-job")?.addEventListener("click", () => dismiss(state, "not_job"));
  document.getElementById("undo-dismiss")?.addEventListener("click", () => dismiss(state, null));
  document.getElementById("disconnect")?.addEventListener("click", async () => {
    await ask3({ type: "disconnect" });
    void render();
  });
  wirePopup();
  wireLetter(state.tab?.id ?? 0, !jobFound(state));
  wireAnswer(state.tab?.id ?? 0);
  wireSetup(state);
  wirePlanSwitch();
  wireOpened(state);
  wireJobBox(state);
  document.getElementById("open-resume")?.addEventListener("click", () => void seeResume());
  document.getElementById("replace-resume")?.addEventListener("click", () => resumeInput.click());
  document.getElementById("attach-resume")?.addEventListener("click", () => void attachResume());
  document.querySelectorAll("[data-attach-letter]").forEach((button) => button.addEventListener("click", () => void attachLetter()));
  document.getElementById("start-resume")?.addEventListener("click", () => resumeInput.click());
  wireIssues();
  wireManualJob(state);
  document.getElementById("pause")?.addEventListener("change", (event) => void ask3({ type: "set-auto-submit", value: !event.target.checked }));
  return true;
}
function openJob(id, contact = "") {
  if (!id) return go(jobFrom);
  openedJob = { id, contact };
  if (TABS.includes(view)) jobFrom = view;
  go("job");
}
function addDetected(item) {
  Object.assign(manualJob, { open: true, key: item.url, title: item.title, company: item.company, url: item.url, stage: "applied", note: "Unnepo didn't catch the company. Fill it in, then add it.", saving: false, readFor: "", description: item.description ?? "" });
  go("jobs");
}
setHost({ redraw: () => void render(), openJob, upgradeUrl: () => lastState ? upgradeUrl(lastState) : "", addJob: addDetected });
function go(next) {
  view = next;
  window.scrollTo(0, 0);
  void render();
}
tabBar.querySelectorAll("[data-tab]").forEach((tab) => tab.addEventListener("click", () => go(tab.dataset.tab)));
chrome.runtime.onMessage.addListener((message) => {
  if (message?.type === "tracker-changed") return void loadTracker();
  if (message?.type !== "state-changed") return;
  void refreshDetected();
  activityLog = null;
  if (view === "feedback") void loadIssues();
  else void refresh();
});
chrome.tabs.onUpdated.addListener((id, info) => {
  const job = lastState?.job;
  if (info.status === "loading" && id === lastState?.tab?.id && job?.error && !job.running) void ask3({ type: "clear-error", tabId: id });
  if (info.status === "complete") void refresh();
  else if (info.url && id === lastState?.tab?.id) {
    void refresh();
    for (const wait of [1200, 3e3, 6500]) setTimeout(() => void refresh(), wait);
  }
});
function holdOpen() {
  void chrome.windows.getCurrent().then((win) => {
    if (win.id === void 0) return;
    const port = chrome.runtime.connect({ name: `panel:${win.id}` });
    port.onDisconnect.addListener(() => setTimeout(holdOpen, 1e3));
  }).catch(() => void 0);
}
holdOpen();
void render();
