// extension/src/shared/steps.ts
var stepText = (step) => step ? `step ${step.index} of ${step.total}${step.name ? ` (${step.name})` : ""}` : "the start";
function wentBack(before, after, applyShown) {
  if (!before) return false;
  if (!after) return applyShown;
  return after.total === before.total && after.index < before.index;
}

// extension/src/shared/password.ts
var LOWER = "abcdefghijkmnpqrstuvwxyz";
var UPPER = "ABCDEFGHJKLMNPQRSTUVWXYZ";
var DIGITS = "23456789";
var SPECIAL = "!@#$%*?";
var PASSWORD_RULES = [
  { label: "A numeric character", test: (value) => /\d/.test(value) },
  { label: "An uppercase character", test: (value) => /[A-Z]/.test(value) },
  { label: "An alphabetic character", test: (value) => /[A-Za-z]/.test(value) },
  { label: "A special character", test: (value) => /[^A-Za-z0-9\s]/.test(value) },
  { label: "A lowercase character", test: (value) => /[a-z]/.test(value) },
  { label: "A minimum of 8 characters", test: (value) => value.length >= 8 }
];
function unmetRules(value) {
  return PASSWORD_RULES.filter((rule) => !rule.test(value)).map((rule) => rule.label);
}
function randomIndex(max) {
  const limit = Math.floor(4294967296 / max) * max;
  const buffer = new Uint32Array(1);
  for (; ; ) {
    crypto.getRandomValues(buffer);
    if (buffer[0] < limit) return buffer[0] % max;
  }
}
function generatePassword(length = 16) {
  const all = LOWER + UPPER + DIGITS + SPECIAL;
  const chars = [LOWER, UPPER, DIGITS, SPECIAL].map((set) => set[randomIndex(set.length)]);
  while (chars.length < Math.max(length, 8)) chars.push(all[randomIndex(all.length)]);
  for (let index = chars.length - 1; index > 0; index -= 1) {
    const other = randomIndex(index + 1);
    [chars[index], chars[other]] = [chars[other], chars[index]];
  }
  return chars.join("");
}

// extension/src/shared/types.ts
var LINKEDIN = /(^|\.)linkedin\.com$/i;
var AUTOFILL_ENABLED = false;

// extension/src/content/quick-apply.ts
var QUICK_BOARDS = /(^|\.)((joinhandshake|linkedin|ziprecruiter|indeed|simplyhired|wellfound|glassdoor|dice|builtin|monster|careerbuilder|wayup)\.com|simplify\.jobs|idealist\.org|usajobs\.gov)$/;

// extension/src/shared/job-page.ts
var JOB_HOSTS = /(^|\.)(greenhouse\.io|lever\.co|ashbyhq\.com|myworkdayjobs\.com|workday\.com|icims\.com|smartrecruiters\.com|jobvite\.com|taleo\.net|bamboohr\.com|workable\.com|recruitee\.com|jazzhr\.com|applytojob\.com|breezy\.hr|successfactors\.(com|eu)|oraclecloud\.com|paylocity\.com|ultipro\.com|adp\.com|rippling\.com|dover\.com|teamtailor\.com|personio\.(de|com)|pinpointhq\.com|joinhandshake\.com|ziprecruiter\.com|indeed\.com|simplyhired\.com|wellfound\.com|glassdoor\.com|dice\.com|builtin\.com|monster\.com|careerbuilder\.com|wayup\.com|simplify\.jobs|idealist\.org|usajobs\.gov)$/i;
var JOB_PATH = /\/(jobs?|careers?|positions?|openings?|vacanc(y|ies)|requisitions?|opportunit(y|ies)|apply|postings?|job-?details?|roles?)(\/|$|[?#-])/i;
var JOB_SUBDOMAIN = /^(jobs|careers|apply|boards|job-boards|hire|recruiting|talent)\./i;
var LIST_PATH = /\/(jobs|careers)\/?(search|results)?\/?$|[?&](q|keywords?|query)=/i;
function isJobPage(page) {
  let url;
  try {
    url = new URL(page.url);
  } catch {
    return false;
  }
  if (!/^https?:$/.test(url.protocol)) return false;
  if (page.ats && page.ats !== "other") return true;
  if (/(^|\.)linkedin\.com$/i.test(url.hostname)) return /\/jobs\/view\/|[?&]currentJobId=\d/.test(url.pathname + url.search);
  if (JOB_HOSTS.test(url.hostname)) return true;
  if ((page.description ?? "").trim().length >= 200) return true;
  const saysJob = JOB_PATH.test(url.pathname + url.search) || JOB_SUBDOMAIN.test(url.hostname);
  if (saysJob && (page.fields ?? 0) >= 3) return true;
  return saysJob && !LIST_PATH.test(url.pathname + url.search);
}
function sendsApplication(label) {
  const text = label.replace(/\s+/g, " ").trim();
  return /^(1-click apply|one-click apply|quick apply|easy apply|instant apply|submit( my)? application|send( my)? application|apply with (my )?(profile|resume))$/i.test(text);
}

// lib/apply/follow-ups.ts
var FOLLOW_UP_BUSINESS_DAYS = 5;
function businessDaysBetween(from, to) {
  let days = 0;
  const day = new Date(Date.UTC(from.getUTCFullYear(), from.getUTCMonth(), from.getUTCDate()));
  const end = Date.UTC(to.getUTCFullYear(), to.getUTCMonth(), to.getUTCDate());
  while (day.getTime() < end) {
    day.setUTCDate(day.getUTCDate() + 1);
    const weekday = day.getUTCDay();
    if (weekday !== 0 && weekday !== 6) days += 1;
  }
  return days;
}
function followUpsDue(apps, now = /* @__PURE__ */ new Date()) {
  return apps.flatMap((app) => (app.contacts ?? []).flatMap((person) => {
    const at = app.fillReport?.emailedAt?.[person.id];
    if (person.outreachStatus !== "emailed" || !at) return [];
    const days = businessDaysBetween(new Date(at), now);
    return days >= FOLLOW_UP_BUSINESS_DAYS ? [{ applicationId: app.id, contactId: person.id, name: person.name, company: app.company, title: app.title, emailedAt: at, days }] : [];
  })).sort((a, b) => a.emailedAt.localeCompare(b.emailedAt));
}

// lib/apply/stats.ts
var NO_RESPONSE_DAYS = 28;
var isApplied = (status) => status === "submitted" || status === "applied_manual";
function stageOf(app, now = Date.now()) {
  if (!isApplied(app.status)) return "in_progress";
  if (app.fillReport?.outcome) return app.fillReport.outcome;
  const last = Math.max(Date.parse(app.submittedAt ?? app.createdAt ?? "") || 0, Date.parse(app.fillReport?.lastEmailAt ?? "") || 0);
  return last && now - last > NO_RESPONSE_DAYS * 864e5 ? "no_response" : "submitted";
}

// lib/apply/next-up.ts
var DAY = 864e5;
var FINISH_DAYS = 30;
var UPDATE_DAYS = 14;
var SHOWN = 5;
function daysAgo(at, now) {
  const start = (date) => new Date(date.getFullYear(), date.getMonth(), date.getDate()).getTime();
  return Math.round((start(now) - start(new Date(at))) / DAY);
}
function dayWords(at, now) {
  const days = daysAgo(at, now);
  if (days <= 0) return "Today";
  if (days === 1) return "Yesterday";
  return new Date(at).toLocaleDateString("en-US", { month: "short", day: "numeric" });
}
function nextUp(apps, options = {}) {
  const shown = options.shown ?? SHOWN;
  const now = options.now ?? /* @__PURE__ */ new Date();
  const role = (app) => app.titleMissing ? "" : app.title;
  const named = apps.filter((app) => !app.companyMissing);
  const goal = { today: options.goal?.today ?? 0, daily: options.goal?.daily ?? 0, week: options.goal?.week ?? 0, weekly: options.goal?.weekly ?? 0 };
  const goalItems = [];
  const leftToday = Math.max(0, goal.daily - goal.today);
  const leftWeek = Math.max(0, goal.weekly - goal.week);
  if (leftToday > 0 || leftWeek > 0) {
    const left = leftToday || leftWeek;
    goalItems.push({
      key: `goal:${goal.today}:${goal.week}`,
      kind: "goal",
      title: `Apply to ${left} more ${left === 1 ? "job" : "jobs"}${leftToday ? " today" : " this week"}`,
      detail: [goal.daily ? `${goal.today} of ${goal.daily} today` : "", goal.weekly ? `${goal.week} of ${goal.weekly} this week` : ""].filter(Boolean).join(" \xB7 "),
      when: `${left} to go`,
      action: "Find a job"
    });
  }
  const replied = named.filter((app) => stageOf(app) === "follow_up").map((app) => {
    const change = [...app.fillReport?.statusHistory ?? []].reverse().find((item) => item.status !== "applied" && item.status !== "incomplete");
    return { app, at: Date.parse(change?.at ?? app.fillReport?.lastEmailAt ?? app.submittedAt ?? app.createdAt), summary: change?.summary ?? "" };
  }).sort((a, b) => b.at - a.at);
  const followItems = replied.map(({ app, at, summary }) => ({
    key: `reply:${app.id}`,
    kind: "reply",
    applicationId: app.id,
    title: `Follow up with ${app.company}`,
    detail: [role(app), summary].filter(Boolean).join(" \xB7 "),
    when: dayWords(at, now),
    action: "Open job"
  }));
  for (const due of followUpsDue(named, now)) {
    followItems.push({
      key: `follow:${due.contactId}`,
      kind: "follow_up",
      applicationId: due.applicationId,
      contactId: due.contactId,
      title: `Follow up with ${due.name}`,
      detail: `${due.company} \xB7 emailed ${due.days} business days ago`,
      when: `${due.days} business days`,
      action: "Write follow-up"
    });
  }
  const appItems = named.filter((app) => !isApplied(app.status) && now.getTime() - Date.parse(app.createdAt) <= FINISH_DAYS * DAY).sort((a, b) => Date.parse(b.createdAt) - Date.parse(a.createdAt)).map((app) => ({
    key: `finish:${app.id}`,
    kind: "finish",
    applicationId: app.id,
    title: role(app) ? `Finish ${role(app)} at ${app.company}` : `Finish your application at ${app.company}`,
    detail: "Started, not submitted",
    when: "In progress",
    action: "Finish application"
  }));
  const dueIds = new Set(followItems.map((item) => item.applicationId));
  for (const app of named.filter((app2) => ["submitted", "no_response"].includes(stageOf(app2, now.getTime())) && !dueIds.has(app2.id)).filter((app2) => now.getTime() - Date.parse(app2.fillReport?.lastEmailAt ?? app2.submittedAt ?? app2.createdAt) >= UPDATE_DAYS * DAY).sort((a, b) => Date.parse(a.submittedAt ?? a.createdAt) - Date.parse(b.submittedAt ?? b.createdAt))) {
    appItems.push({
      key: `update:${app.id}`,
      kind: "update",
      applicationId: app.id,
      title: `Heard back from ${app.company}?`,
      detail: [role(app), `applied ${daysAgo(Date.parse(app.submittedAt ?? app.createdAt), now)} days ago`].filter(Boolean).join(" \xB7 "),
      when: "Update status",
      action: "Update status"
    });
  }
  return {
    goals: { ...goal, items: goalItems },
    follow_ups: { replied: replied.length, count: followItems.length, items: followItems.slice(0, shown) },
    applications: { count: appItems.length, items: appItems.slice(0, shown) }
  };
}

// extension/src/shared/reminders.ts
var MAX_FOLLOW_UPS = 2;
var SENT_ASK_MS = 60 * 60 * 1e3;
var DAY2 = 864e5;
function goalCounts(tracker2, now) {
  const dayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
  const weekStart = new Date(dayStart - (now.getDay() + 6) % 7 * DAY2).getTime();
  const applied = tracker2.jobs.filter((job) => isApplied(job.status) && !job.fillReport?.notCounted).map((job) => Date.parse(job.submittedAt ?? job.createdAt));
  const weekly = tracker2.weeklyGoal ?? 0;
  return { today: applied.filter((at) => at >= dayStart).length, daily: weekly ? Math.ceil(weekly / 5) : 0, week: applied.filter((at) => at >= weekStart).length, weekly };
}
function reminders(tracker2, marks, opened, followUps, now = /* @__PURE__ */ new Date()) {
  const next = nextUp(tracker2.jobs, { now, goal: goalCounts(tracker2, now), shown: 100 });
  const hidden = (key) => Boolean(marks[key]?.done || marks[key]?.until && marks[key].until > now.getTime());
  const contact = (id) => tracker2.jobs.flatMap((job) => job.contacts).find((person) => person.id === id);
  const sent = Object.entries(opened).filter(([id, item]) => now.getTime() - item.at >= SENT_ASK_MS && (item.followUp || contact(id)?.outreachStatus === "not_contacted")).map(([id, item]) => ({
    key: `sent:${id}:${item.at}`,
    kind: "sent",
    applicationId: item.applicationId,
    contactId: id,
    title: `Did you send your ${item.followUp ? "follow-up" : "email"} to ${item.name}?`,
    detail: item.company,
    when: "",
    action: "Yes, I sent it"
  }));
  const follow = next.follow_ups.items.map((item) => item.kind === "follow_up" && item.contactId && (followUps[item.contactId] ?? 0) >= MAX_FOLLOW_UPS ? { ...item, title: `No reply from ${item.title.replace(/^Follow up with /, "")}`, detail: `${item.detail} \xB7 followed up ${MAX_FOLLOW_UPS} times`, action: "Stop following up" } : item);
  const today = [...sent, ...follow, ...next.applications.items].filter((item) => !hidden(item.key));
  return { goal: next.goals, items: today };
}
function dueCount(items) {
  return items.filter((item) => item.kind !== "finish").length;
}

// lib/apply/job-title.ts
var MONTH = "(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\\.?";
var WHEN = `( on .+| \\d+ ?(m|min|minutes?|h|hours?|d|days?|w|weeks?|months?) ago| today| yesterday| just now| ${MONTH} \\d{1,2}.*| \\d{1,2}/\\d{1,2}.*)`;
var STATUS = new RegExp(
  `^([\u2713\u2714\u2611]\\s*)?(applied${WHEN}?[.!]?|you(?:'|\u2019| ha)ve applied.*|you applied.*|already applied.*|application (sent|submitted|received|complete|completed|viewed|in progress)\\b.*|your application (was |has been )?(sent|submitted|received).*|(saved|viewed|submitted|withdrawn|archived|not interested)${WHEN}?|(posted|updated|reposted|closes|closing|deadline)\\b.*|no longer accepting.*|this job (has )?(expired|closed).*|(apply|applying) (to|for|at) .+|(details|questions|documents|attachments|information|info) (from|for) .+)$`,
  "i"
);
var DATE_ONLY = new RegExp(`^${MONTH} \\d{1,2}(, \\d{4})?$`, "i");
var PAGE_NAME = /^(jobs?|job search|search( jobs| results)?|find (a )?jobs?|browse jobs|all jobs|saved jobs|recommended( jobs)?|jobs for you|job (postings?|board|listings?)|postings?|listings?|careers?|career (center|centre|services)|home|explore|discover|internships?( and jobs)?|opportunities|open (roles|positions)|positions|(my )?applications|messages|inbox|events|employers|companies|dashboard|feed|notifications|profile)$/i;
var SITE_MENU = /^(\d+\+? (new |unread )?(notifications?|messages?|alerts?)|(new |unread )?(notifications?|messages?) \(\d+\)|my network|messaging|me|for business|try premium.*|skip to (main )?content|home|jobs home)$/i;
var SITE_TALK = /\b(your feedback|feedback helps|give feedback|share (your )?feedback|are these (results|jobs) (helpful|relevant)|(was|is) this (page |job |result )?(helpful|relevant)|rate (this|your)|take (our|a|the) survey|how (are|did) we do|sign in to|log in to|join (now )?to (see|view|apply)|create (an|your) account|something went wrong|page (not found|unavailable)|access denied|verify (you are|you're) (a )?human|no longer available|we use cookies|accept (all )?cookies|showing \d+|\d+[,\d]* (results|jobs|openings)|results? for\b|jobs? (you may|you might|based on|recommended)|similar jobs|people also viewed|try premium|premium members)\b/i;
var SITE_PROMO = /(\bstay (on top of|up to date|in the loop)\b|\bjob alerts?\b|\b(set|create|turn on|get|manage) (an? |your |job )?alerts?\b|\bget notified\b|\bnotify me\b|\bnew (job )?openings\b|\bnever miss\b|©|\(c\) \d{4}|\bcopyright\b|\ball rights reserved\b|\bcorporation\b.*\d{3}|\b(user agreement|privacy policy|cookie policy|copyright policy|community guidelines|about accessibility|brand policy|guest controls)\b|\bopen to work\b|\bupdate your (profile|preferences)\b)/i;
var SENTENCE_START = /^(are|is|was|were|do|does|did|can|could|would|should|will|have|has|how|what|why|when|where|who|which|we|we're|we've|you|you're|your|our|this|these|that|please|thanks|thank you|sorry|oops|welcome|hi|hello|looking for|want to|ready to|don't|didn't)\b/i;
function siteSentence(line) {
  const words = line.split(" ").length;
  if (SITE_TALK.test(line) || SITE_PROMO.test(line)) return true;
  if (/\?/.test(line)) return true;
  if (/[.!…]\s+\S/.test(line) || /\.\.\.$|…$/.test(line) && words > 4) return true;
  if (SENTENCE_START.test(line) && words >= 3) return true;
  return words > 16;
}
function notJobTitle(text) {
  const line = text.replace(/\s+/g, " ").trim();
  return line.length < 2 || line.length > 150 || STATUS.test(line) || DATE_ONLY.test(line) || PAGE_NAME.test(line) || SITE_MENU.test(line) || siteSentence(line);
}

// extension/src/shared/applied-line.ts
var MONTHS = ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"];
var MONTH2 = "(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\\.?";
var WHEN2 = `(${MONTH2} \\d{1,2}(?:st|nd|rd|th)?(?:,? \\d{4})?|\\d{1,2}/\\d{1,2}(?:/\\d{2,4})?|\\d{4}-\\d{2}-\\d{2}|\\d+ ?(?:s|sec|seconds?|m|mins?|minutes?|h|hrs?|hours?|d|days?|w|wks?|weeks?|mo|months?) ago|today|yesterday|just now)`;
var APPLIED_LINE = new RegExp(`^([\u2713\u2714\u2611]\\s*)?(you )?(applied|application (?:submitted|sent|received)|submitted)[\\s:\xB7\u2022,-]*(on\\s+)?${WHEN2}\\.?$`, "i");
function appliedDay(text, now = /* @__PURE__ */ new Date()) {
  const iso = (date) => `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
  const lower = text.toLowerCase();
  if (/\b(today|just now|\d+ ?(s|sec|seconds?|m|mins?|minutes?|h|hrs?|hours?) ago)\b/.test(lower)) return iso(now);
  if (/\byesterday\b/.test(lower)) return iso(new Date(now.getFullYear(), now.getMonth(), now.getDate() - 1));
  const ago = lower.match(/\b(\d+) ?(d|days?|w|wks?|weeks?|mo|months?) ago\b/);
  if (ago) {
    const n = Number(ago[1]);
    const days = /^d/.test(ago[2]) ? n : /^w/.test(ago[2]) ? n * 7 : n * 30;
    return iso(new Date(now.getFullYear(), now.getMonth(), now.getDate() - days));
  }
  const isoDay = lower.match(/\b(\d{4})-(\d{2})-(\d{2})\b/);
  if (isoDay) return `${isoDay[1]}-${isoDay[2]}-${isoDay[3]}`;
  const named = lower.match(new RegExp(`\\b${MONTH2} (\\d{1,2})(?:st|nd|rd|th)?(?:,? (\\d{4}))?`));
  if (named) {
    const month = MONTHS.indexOf(named[1].slice(0, 3));
    let date = new Date(named[3] ? Number(named[3]) : now.getFullYear(), month, Number(named[2]));
    if (!named[3] && date.getTime() > now.getTime() + 864e5) date = new Date(now.getFullYear() - 1, month, Number(named[2]));
    return iso(date);
  }
  const slash = lower.match(/\b(\d{1,2})\/(\d{1,2})(?:\/(\d{2,4}))?\b/);
  if (slash) {
    const year = slash[3] ? slash[3].length === 2 ? 2e3 + Number(slash[3]) : Number(slash[3]) : now.getFullYear();
    return iso(new Date(year, Number(slash[1]) - 1, Number(slash[2])));
  }
  return "";
}

// extension/src/background.ts
var DEFAULT_API = "https://www.unnepo.com";
var ALLOWED_API = /^(https:\/\/(www\.)?unnepo\.com|https:\/\/unneponew\.vercel\.app|http:\/\/localhost(:\d+)?)$/;
var MOVED_API = /^https:\/\/(unneponew\.vercel\.app|unnepo\.com)$/;
async function settings() {
  const stored = await chrome.storage.local.get(["token", "apiBase", "autoSubmit"]);
  const saved = stored.apiBase;
  const apiBase = !saved || MOVED_API.test(saved) && !MOVED_API.test(DEFAULT_API) ? DEFAULT_API : saved;
  return { token: stored.token ?? null, apiBase, autoSubmit: Boolean(stored.autoSubmit) };
}
async function jobSitePassword() {
  const stored = (await chrome.storage.local.get("jobSitePassword")).jobSitePassword;
  if (stored) return stored;
  const password = generatePassword();
  await chrome.storage.local.set({ jobSitePassword: password });
  return password;
}
async function dropdownWay(host) {
  const stored = (await chrome.storage.local.get("dropdownWays")).dropdownWays;
  return stored?.[host];
}
async function rememberDropdownWay(host, attempts) {
  const worked = { click: 0, keyboard: 0 };
  for (const attempt of attempts) if (attempt.ok && attempt.type === "combobox" && (attempt.method === "click" || attempt.method === "keyboard")) worked[attempt.method] += 1;
  if (!worked.click && !worked.keyboard) return;
  const best = worked.keyboard > worked.click ? "keyboard" : "click";
  const stored = (await chrome.storage.local.get("dropdownWays")).dropdownWays ?? {};
  if (stored[host] === best) return;
  const kept = Object.entries({ ...stored, [host]: best }).slice(-300);
  await chrome.storage.local.set({ dropdownWays: Object.fromEntries(kept) });
}
var ISSUES_KEPT = 200;
var SAME_ISSUE_MS = 30 * 60 * 1e3;
async function issues() {
  return (await chrome.storage.local.get("issues")).issues ?? [];
}
function issuePage(url) {
  try {
    const parsed = new URL(url);
    return { site: parsed.hostname, page: `${parsed.origin}${parsed.pathname}` };
  } catch {
    return { site: "", page: "" };
  }
}
async function addIssues(url, items) {
  if (!items.length) return;
  const where = issuePage(url);
  const list = await issues();
  const now = Date.now();
  const recent = (item) => list.some((known) => known.kind === item.kind && known.page === where.page && known.question === item.question && known.what === item.what && now - Date.parse(known.at) < SAME_ISSUE_MS);
  const fresh = items.filter((item) => item.kind === "note" || !recent(item)).map((item) => ({
    id: `${now.toString(36)}${Math.random().toString(36).slice(2, 7)}`,
    at: new Date(now).toISOString(),
    ...where,
    kind: item.kind,
    what: item.what.replace(/\s+/g, " ").trim().slice(0, ISSUE_CHARS),
    ...item.question ? { question: item.question.slice(0, 200) } : {}
  }));
  if (!fresh.length) return;
  await chrome.storage.local.set({ issues: [...fresh.reverse(), ...list].slice(0, ISSUES_KEPT) });
  void chrome.runtime.sendMessage({ type: "state-changed" }).catch(() => void 0);
}
var ISSUE_CHARS = 2500;
async function jobs() {
  return (await chrome.storage.session.get("jobs")).jobs ?? {};
}
async function saveJob(tabId, patch) {
  const all = await jobs();
  if (patch === null) delete all[tabId];
  else all[tabId] = { ...all[tabId] ?? {}, ...patch, tabId };
  await chrome.storage.session.set({ jobs: all });
  void chrome.runtime.sendMessage({ type: "state-changed" }).catch(() => void 0);
}
var ApiError = class extends Error {
  constructor(message, status, code = "") {
    super(message);
    this.status = status;
    this.code = code;
  }
  status;
  code;
};
async function api(method, path, body) {
  const { token, apiBase } = await settings();
  if (!token) throw new ApiError("Connect the extension to Unnepo first.", 401);
  const response = await fetch(`${apiBase}/api/extension/${path}`, {
    method,
    headers: { Authorization: `Bearer ${token}`, ...body === void 0 ? {} : { "Content-Type": "application/json" } },
    body: body === void 0 ? void 0 : JSON.stringify(body)
  });
  const payload = await response.json().catch(() => ({}));
  if (response.status === 401) {
    await chrome.storage.local.remove("token");
    void chrome.runtime.sendMessage({ type: "state-changed" }).catch(() => void 0);
  }
  if (!response.ok) throw new ApiError(payload.error || `Unnepo answered ${response.status}.`, response.status, payload.code ?? "");
  const spent = payload?.counted === true;
  if (method !== "GET") await meChanged(path, spent);
  if (spent) void chrome.runtime.sendMessage({ type: "state-changed" }).catch(() => void 0);
  return payload;
}
var ME_FRESH_MS = 2e4;
var QUIET = /* @__PURE__ */ new Set(["activity", "attempts", "map", "answers", "read-link", "job-info"]);
var meCalls = 0;
var reading = null;
var meCopy = async () => (await chrome.storage.session.get("meCopy")).meCopy ?? null;
async function meChanged(path, spent = false) {
  meCalls += 1;
  const copy = await meCopy();
  if (copy) await chrome.storage.session.set({ meCopy: { ...copy, at: 0, waitForNew: copy.waitForNew || spent || !QUIET.has(path) } });
}
function readMe(token) {
  if (reading?.call === meCalls) return reading.result;
  const call = meCalls;
  const result = api("GET", "me").then(async (me) => {
    const before = await meCopy();
    if (call === meCalls) await chrome.storage.session.set({ meCopy: { token, at: Date.now(), waitForNew: false, me } });
    if (before?.token === token && JSON.stringify(before.me) !== JSON.stringify(me)) void chrome.runtime.sendMessage({ type: "state-changed" }).catch(() => void 0);
    return me;
  }).finally(() => {
    if (reading?.call === call) reading = null;
  });
  reading = { call, result };
  return result;
}
async function currentMe(token) {
  const copy = await meCopy();
  if (copy?.token !== token) return readMe(token).catch(() => null);
  if (copy.waitForNew) return readMe(token).catch(() => copy.me);
  if (Date.now() - copy.at > ME_FRESH_MS) void readMe(token).catch(() => void 0);
  return copy.me;
}
async function resumeFile() {
  const { token, apiBase } = await settings();
  const response = await fetch(`${apiBase}/api/extension/resume`, { headers: { Authorization: `Bearer ${token}` } }).catch(() => null);
  if (!response) return { file: null, error: "Couldn't reach Unnepo to get your resume." };
  if (!response.ok) {
    const message = (await response.json().catch(() => ({}))).error;
    return { file: null, error: message || `Unnepo couldn't send your resume (${response.status}).` };
  }
  const name = response.headers.get("content-disposition")?.match(/filename="([^"]+)"/)?.[1] ?? "Resume.pdf";
  const bytes = new Uint8Array(await response.arrayBuffer());
  let binary = "";
  for (let index = 0; index < bytes.length; index += 32768) binary += String.fromCharCode(...bytes.subarray(index, index + 32768));
  return { file: { name, mime: response.headers.get("content-type") ?? "application/pdf", base64: btoa(binary) }, error: null };
}
var resumeReady = null;
function readyResume() {
  if (!resumeReady || Date.now() - resumeReady.at > 10 * 6e4) {
    const got = resumeFile().then((result) => {
      if (!result.file) resumeReady = null;
      return result;
    });
    resumeReady = { at: Date.now(), got };
  }
  return resumeReady.got;
}
async function applyingAll() {
  return (await chrome.storage.session.get("applying")).applying ?? {};
}
async function saveApplying(tabId, value) {
  const all = await applyingAll();
  if (value) all[tabId] = value;
  else delete all[tabId];
  await chrome.storage.session.set({ applying: all });
  void chrome.runtime.sendMessage({ type: "state-changed" }).catch(() => void 0);
}
async function readJobDetails(tabId) {
  const scan = await look(tabId);
  if (!scan) return null;
  const top = await send(tabId, { type: "job-details" }, 0).catch(() => null);
  const frame = formFrame.get(tabId) ?? 0;
  const form = frame ? await send(tabId, { type: "job-details" }, frame).catch(() => null) : null;
  const details = top ?? form;
  if (!details) return null;
  if (form && top) Object.assign(details, { questions: form.questions, uploads: form.uploads, resumeBox: form.resumeBox });
  if (!details.title) details.title = scan.title;
  if (!details.company) details.company = scan.company;
  return details;
}
async function attachEverywhere(tabId, message) {
  await look(tabId);
  const frames = await chrome.webNavigation.getAllFrames({ tabId }).catch(() => null) ?? [{ frameId: 0, url: "" }];
  const attached = [];
  for (const frame of frames.filter((item) => item.frameId === 0 || /^https:\/\//.test(item.url) && !SKIP_FRAME.test(item.url))) {
    const result = await send(tabId, message, frame.frameId).catch(() => null);
    attached.push(...result?.attached ?? []);
  }
  return attached;
}
async function beginApplying(tabId, questionsOnly) {
  const before = (await applyingAll())[tabId];
  const onlyQuestions = questionsOnly ?? Boolean(before?.questionsOnly);
  const resume = onlyQuestions ? { file: null, error: null } : await readyResume();
  await look(tabId);
  const tab = await chrome.tabs.get(tabId).catch(() => null);
  const result = await send(tabId, { type: "begin-applying", resume: resume.file });
  const applying = { ...result, uploaded: [.../* @__PURE__ */ new Set([...before?.uploaded ?? [], ...result.uploaded])], url: tab?.url ?? "", resumeError: resume.file || onlyQuestions ? null : resume.error, answers: before?.answers ?? {}, questionsOnly: onlyQuestions };
  await saveApplying(tabId, applying);
  void log(`Began applying${result.uploaded.length ? `: resume uploaded to "${result.uploaded[0].slice(0, 40)}"` : ""}. ${result.questions.length} complex ${result.questions.length === 1 ? "question" : "questions"} found.`);
  return applying;
}
async function uploadResume(name, mime, base64) {
  const { token, apiBase } = await settings();
  const bytes = Uint8Array.from(atob(base64), (char) => char.charCodeAt(0));
  const form = new FormData();
  form.append("file", new File([bytes], name, { type: mime }));
  const response = await fetch(`${apiBase}/api/extension/resume`, { method: "POST", headers: { Authorization: `Bearer ${token}` }, body: form });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(payload.error || `Upload failed (${response.status}).`);
}
var SITE_NAMES = { greenhouse: "Greenhouse", lever: "Lever", ashby: "Ashby", workday: "Workday", other: "" };
var peeks = /* @__PURE__ */ new Map();
async function peek(tabId, url) {
  if (!/^https:\/\//.test(url)) return null;
  try {
    if (new URL(url).origin === new URL((await settings()).apiBase).origin) return null;
  } catch {
    return null;
  }
  const cached = peeks.get(tabId);
  if (cached && cached.url === url && Date.now() - cached.at < 4e3) return cached.page;
  const scan = await look(tabId);
  if (!scan) return null;
  const host = new URL(scan.url).hostname;
  const known = Boolean((await knownAccounts())[accountKey(scan.url)]);
  const status = await send(tabId, { type: "status", knownAccount: known }).catch(() => null);
  const accountPage = scan.passwordBoxes > 0 || scan.ats === "workday";
  const page = {
    // "jobs.jobylon.com" reads as "Jobylon".
    site: SITE_NAMES[scan.ats] || ((name) => name.charAt(0).toUpperCase() + name.slice(1))(host.replace(/^(www|jobs|careers|boards|apply|job-boards|hire|recruiting)\./, "").split(".")[0]),
    title: scan.title,
    company: scan.company,
    fields: scan.fields.length + scan.passwordBoxes,
    // An Apply button counts only on a page that is a job: a LinkedIn search or feed is full of Easy Apply buttons.
    posting: Boolean(status?.apply) && scan.fields.length < 3 && isJobPage({ url: scan.jobUrl || scan.url, ats: scan.ats, description: scan.description, fields: scan.fields.length }),
    account: accountPage ? known ? "sign_in" : "new" : null,
    mentionsCv: scan.mentionsCv
  };
  if (!(linkedInJobId(scan.url) && !scan.description)) peeks.set(tabId, { url, at: Date.now(), page });
  void rememberSeen(tabId, scan);
  return page;
}
async function seenJobs() {
  return (await chrome.storage.session.get("seen")).seen ?? {};
}
var sameCompany = (a, b) => {
  const word = (name) => name.toLowerCase().replace(/[^a-z0-9 ]/g, "").split(" ").find((part) => part.length >= 3) ?? "";
  const [x, y] = [word(a), word(b)];
  return Boolean(x && y) && (x.startsWith(y) || y.startsWith(x));
};
function linkedInJobId(href) {
  try {
    const url = new URL(href);
    if (!/(^|\.)linkedin\.com$/.test(url.hostname)) return "";
    return url.pathname.match(/\/jobs\/view\/(?:[^/]*?-)?(\d{6,})/)?.[1] ?? url.searchParams.get("currentJobId") ?? "";
  } catch {
    return "";
  }
}
var otherLinkedInJob = (a, b) => Boolean(linkedInJobId(a) && linkedInJobId(b) && linkedInJobId(a) !== linkedInJobId(b));
async function rememberSeen(tabId, scan) {
  if (!scan.title.trim() || !scan.company.trim()) return;
  if (!isJobPage({ url: scan.jobUrl || scan.url, ats: scan.ats, description: scan.description, fields: scan.fields.length })) return;
  const all = await seenJobs();
  const before = all[tabId];
  const form = scan.fields.length >= 3;
  const other = Boolean(before && otherLinkedInJob(before.url, scan.jobUrl || scan.url));
  if (before?.description && !scan.description && sameCompany(before.company, scan.company) && !other) {
    if (form && !before.form) {
      all[tabId] = { ...before, form: true };
      await chrome.storage.session.set({ seen: all });
    }
    return;
  }
  const same = before && sameCompany(before.company, scan.company) && !other;
  all[tabId] = { url: scan.jobUrl || scan.url, title: scan.title, company: scan.company, description: scan.description, poster: scan.poster, at: Date.now(), pressed: same && before?.pressed, form: form || same && before?.form, sent: same && before?.sent };
  await chrome.storage.session.set({ seen: all });
  if (!form && !/^job title missing$/i.test(scan.title) && !notJobTitle(scan.title)) await noteViewed(all[tabId]).catch(() => void 0);
}
chrome.tabs.onCreated.addListener((tab) => {
  if (tab.id === void 0 || tab.openerTabId === void 0) return;
  void seenJobs().then(async (all) => {
    const from = all[tab.openerTabId];
    if (from?.pressed && Date.now() - from.at < 10 * 60 * 1e3) {
      all[tab.id] = { ...from, at: Date.now(), pressed: true, form: false, sent: false };
      await chrome.storage.session.set({ seen: all });
    }
  });
});
var HOW_SAID = {
  site_confirmed: "the site confirmed it",
  page_said: "the page said so",
  button_changed: "the Apply button changed",
  board_saved: "the job board saved it",
  linkedin_easy_apply: "LinkedIn Easy Apply",
  you_marked: "you marked it",
  added_by_hand: "added by you"
};
async function addMaybe(item) {
  if (!item.title.trim()) return;
  await noteDetected({ ...item, sure: "pressed", state: "ask" });
  void log(`Not confirmed: ${item.title}${item.company ? ` at ${item.company}` : ""}. It's under Detected jobs on Home.`);
}
var DETECTED_KEPT = 5;
var SURE_HOWS = /* @__PURE__ */ new Set(["site_confirmed", "board_saved", "linkedin_easy_apply"]);
async function detectedList() {
  return (await chrome.storage.local.get("detected")).detected ?? [];
}
async function saveDetectedList(list) {
  const kept = [...list];
  while (kept.length > DETECTED_KEPT) {
    const viewed = kept.map((item) => item.state).lastIndexOf("seen");
    kept.splice(viewed >= 0 ? viewed : kept.length - 1, 1);
  }
  await chrome.storage.local.set({ detected: kept });
  void updateBadge();
  void chrome.runtime.sendMessage({ type: "state-changed" }).catch(() => void 0);
}
async function savesByItself() {
  return (await chrome.storage.local.get("autoDetect")).autoDetect !== "ask";
}
var siteName = (url) => {
  try {
    return new URL(url).hostname.replace(/^www\./, "");
  } catch {
    return "";
  }
};
async function noteDetected(item) {
  const list = await detectedList();
  const index = list.findIndex((other) => item.applicationId && other.applicationId === item.applicationId || other.url && item.url && sameJobPage(other.url, item.url) && sameJobTitle(other, item) || item.company && sameJobTitle(other, item));
  const before = index >= 0 ? list[index] : null;
  const keep = before && (before.state === "saved" || before.state === "yes" || before.state === "no") && item.state === "ask";
  const next = keep ? { ...before, at: Date.now() } : { ...before, ...item, id: before?.id ?? crypto.randomUUID(), at: Date.now(), site: siteName(item.url) || before?.site || "" };
  if (index >= 0) list.splice(index, 1);
  await saveDetectedList([next, ...list]);
  return next;
}
async function noteViewed(seen) {
  if ((await trackerCopy())?.data.jobs.some((job) => !job.titleMissing && sameJobTitle(job, seen))) return;
  const list = await detectedList();
  const index = list.findIndex((other) => other.url && seen.url && sameJobPage(other.url, seen.url) && sameJobTitle(other, seen) || sameJobTitle(other, seen));
  const before = index >= 0 ? list[index] : null;
  if (before && before.state !== "seen") return;
  const description = seen.description || before?.description;
  const poster = seen.poster ?? before?.poster;
  if (before && index === 0 && before.title === seen.title && before.company === seen.company && before.description === description && JSON.stringify(before.poster) === JSON.stringify(poster)) return;
  const next = { id: before?.id ?? crypto.randomUUID(), url: seen.url, title: seen.title, company: seen.company, description, poster, site: siteName(seen.url), at: Date.now(), sure: "viewed", state: "seen" };
  if (index >= 0) list.splice(index, 1);
  await saveDetectedList([next, ...list]);
}
async function dropDetected(job) {
  const list = await detectedList();
  const kept = list.filter((other) => !(sameJobTitle(other, job) || job.url && other.url && sameJobPage(other.url, job.url) && sameJobTitle(other, job)));
  if (kept.length !== list.length) await saveDetectedList(kept);
}
var BOARD_WORD = /^(app|www|handshake|joinhandshake|ziprecruiter|indeed|glassdoor|linkedin|wellfound|dice|simplify|built ?in|monster|simplyhired|careerbuilder|wayup|idealist|usajobs|jobs?|careers?)$/i;
async function log(text) {
  const list = (await chrome.storage.local.get("activityLog")).activityLog ?? [];
  await chrome.storage.local.set({ activityLog: [{ at: Date.now(), text: text.slice(0, 200) }, ...list].slice(0, 30) });
  void chrome.runtime.sendMessage({ type: "state-changed" }).catch(() => void 0);
}
async function tabGone(tabId) {
  const [job, seen] = [(await jobs())[tabId], (await seenJobs())[tabId]];
  if (job?.applicationId && !job.submission && (job.report?.filled.length || job.clickedAt)) {
    await addMaybe({ url: job.url, title: job.title, company: job.company, applicationId: job.applicationId });
  } else if (seen?.pressed && (seen.form || seen.sent) && !job?.submission) {
    await addMaybe({ url: seen.url, title: seen.title, company: seen.company, description: seen.description });
  }
  const all = await seenJobs();
  if (all[tabId]) {
    delete all[tabId];
    await chrome.storage.session.set({ seen: all });
  }
  await saveJob(tabId, null);
}
function sameJobPage(a, b) {
  try {
    const [x, y] = [new URL(a), new URL(b)];
    if (x.hostname !== y.hostname || x.pathname.replace(/\/$/, "") !== y.pathname.replace(/\/$/, "")) return false;
    return ["jid", "currentJobId", "jobId", "job_id", "id", "lvk"].every((key) => x.searchParams.get(key) === y.searchParams.get(key));
  } catch {
    return false;
  }
}
var sameJobTitle = (job, seen) => job.title.trim().toLowerCase() === seen.title.trim().toLowerCase() && (!job.company || !seen.company || sameCompany(job.company, seen.company));
async function recordSeen(tabId, text, how = "page_said") {
  const job = (await jobs())[tabId];
  let seen = (await seenJobs())[tabId];
  if (job?.applicationId && (!seen || (!job.url || sameJobPage(job.url, seen.url) || !job.submission && sameApplication(job.url, seen.url)) && (!job.submission || sameJobTitle(job, seen)))) return record(tabId, SURE_HOWS.has(how) ? "confirmed" : "likely", text, how);
  if (!seen) {
    const scan = await look(tabId).catch(() => null);
    if (scan?.description) await rememberSeen(tabId, scan);
    seen = (await seenJobs())[tabId];
  }
  if (!seen) return void log(`The page says you applied, but no job was seen in this tab, so nothing was added.`);
  const caught = how !== "you_marked";
  if (caught && !(SURE_HOWS.has(how) && await savesByItself())) {
    await noteDetected({ url: seen.url, title: seen.title, company: seen.company, description: seen.description, poster: seen.poster, sure: "likely", state: "ask" });
    return void log(`The page looks applied (${HOW_SAID[how]}). It's under Detected jobs on Home.`);
  }
  let screenshot;
  try {
    const tab = await chrome.tabs.get(tabId);
    if (tab.active) screenshot = await chrome.tabs.captureVisibleTab(tab.windowId, { format: "jpeg", quality: 60 });
  } catch {
  }
  try {
    const saved = await saveSubmission({ url: seen.url, title: seen.title, company: seen.company, description: seen.description, poster: seen.poster, confidence: "likely", text, screenshot, how });
    celebrate(tabId);
    await saveJob(tabId, { applicationId: saved.application.id, title: saved.application.title, company: saved.application.company, url: seen.url, host: new URL(seen.url).hostname, submission: "likely", clickedAt: Date.now(), step: `Saved to your tracker: ${saved.application.title} at ${saved.application.company}.` });
    void log(`Saved: ${saved.application.title} at ${saved.application.company} (${HOW_SAID[how]}).`);
    if (caught) await noteDetected({ url: seen.url, title: saved.application.title, company: saved.application.company, applicationId: saved.application.id, sure: SURE_HOWS.has(how) ? "confirmed" : "likely", state: "saved" });
  } catch (error) {
    await saveJob(tabId, { error: error instanceof Error ? `Couldn't save this application: ${error.message}` : "Couldn't save this application." });
    await addMaybe({ url: seen.url, title: seen.title, company: seen.company, description: seen.description });
  }
}
async function state() {
  const { token, apiBase, autoSubmit } = await settings();
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  let me = null;
  if (token) me = await currentMe(token);
  if (me?.spider) void chrome.storage.local.set({ spider: me.spider });
  const saved = tab?.id !== void 0 ? (await jobs())[tab.id] ?? null : null;
  let job = saved && !saved.running && !saved.submission && saved.url && tab?.url && sameHost(saved.url, tab.url) && !sameApplication(saved.url, tab.url) ? null : saved;
  const page = me && tab?.id !== void 0 && !job?.running ? await peek(tab.id, tab.url ?? "").catch(() => null) : null;
  if (job?.submission && job.url && tab?.url && sameHost(job.url, tab.url) && QUICK_BOARDS.test(new URL(tab.url).hostname) && page?.title && page.company && !sameJobTitle(job, page)) job = null;
  const maybe = (me?.maybe ?? []).filter((item) => Date.now() - Date.parse(item.at) > 12e4);
  const applying = tab?.id !== void 0 ? (await applyingAll())[tab.id] ?? null : null;
  const listed = tab?.id !== void 0 ? (await boardLists())[tab.id] : void 0;
  const boardList = me && listed && tab?.url && pageKey(listed.url) === pageKey(tab.url) ? { site: siteName(listed.url), total: listed.items.length, missing: await missingFromBoard(listed) } : null;
  return { connected: Boolean(token && me), me, page, tab: tab?.id !== void 0 ? { id: tab.id, url: tab.url ?? "", title: tab.title ?? "" } : null, job, autoSubmit, apiBase, maybe, applying, boardList };
}
var formFrame = /* @__PURE__ */ new Map();
var send = (tabId, message, frameId = formFrame.get(tabId) ?? 0) => chrome.tabs.sendMessage(tabId, message, { frameId });
var SKIP_FRAME = /recaptcha|hcaptcha|captcha|turnstile|challenges\.cloudflare|arkoselabs|funcaptcha|doubleclick|googlesyndication|googletagmanager|youtube\.com|vimeo\.com|js\.stripe\.com|facebook\.com|linkedin\.com\/(embed|px)/i;
function sameApplication(before, after) {
  if (!before) return false;
  try {
    const [a, b] = [new URL(before), new URL(after)];
    if (a.hostname !== b.hostname) return false;
    const [x, y] = [a.pathname.split("/").filter(Boolean), b.pathname.split("/").filter(Boolean)];
    let shared = 0;
    while (shared < x.length && x[shared] === y[shared]) shared += 1;
    return a.pathname === b.pathname || shared >= 3 || shared >= 2 && shared === Math.min(x.length, y.length);
  } catch {
    return false;
  }
}
function sameHost(a, b) {
  try {
    return new URL(a).hostname === new URL(b).hostname;
  } catch {
    return false;
  }
}
var signature = (scan) => `${scan.url}|${scan.passwordBoxes}|${scan.fields.map((field) => field.label).join("|")}`;
var hasForm = (scan) => scan.useServerSchema || scan.fields.length > 0 || scan.passwordBoxes > 0;
var REVIEW_SOURCES = {
  ai: "Written by AI.",
  cache: "Written by AI for a question like this before."
};
var wait = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
var runs = /* @__PURE__ */ new Map();
var runCounter = 0;
var stillRunning = (tabId, run2) => runs.get(tabId) === run2;
async function knownAccounts() {
  return (await chrome.storage.local.get("accounts")).accounts ?? {};
}
async function rememberAccount(key, password) {
  const all = await knownAccounts();
  if (!password && typeof all[key] === "object") return;
  await chrome.storage.local.set({ accounts: { ...all, [key]: password ? { password, at: Date.now() } : true } });
}
async function passwordFor(key) {
  const account = (await knownAccounts())[key];
  return typeof account === "object" ? account.password : jobSitePassword();
}
function accountKey(url) {
  const parsed = new URL(url);
  if (!/myworkday(jobs|site)\.com$/.test(parsed.hostname)) return parsed.hostname;
  const parts = parsed.pathname.split("/").filter((part) => part && !/^[a-z]{2}-[A-Z]{2}$/.test(part) && part !== "recruiting");
  return `${parsed.hostname}/${parts[0] ?? ""}`;
}
async function look(tabId) {
  try {
    const tab = await chrome.tabs.get(tabId);
    if (!tab.url) return null;
    const frames = await chrome.webNavigation.getAllFrames({ tabId }).catch(() => null) ?? [{ frameId: 0, url: "" }];
    const frameIds = frames.filter((frame) => frame.frameId === 0 || /^https:\/\//.test(frame.url) && !SKIP_FRAME.test(frame.url)).map((frame) => frame.frameId);
    await chrome.scripting.executeScript({ target: { tabId, frameIds }, files: ["content/fill.js"] }).catch(() => void 0);
    const scans = await chrome.scripting.executeScript({
      target: { tabId, frameIds },
      func: () => window.__unnepo?.scan() ?? null
    });
    const found = scans.filter((result) => result.result).map((result) => ({ frameId: result.frameId, scan: result.result }));
    const weight = (scan) => (scan.useServerSchema ? 1e3 : 0) + scan.fields.length + scan.passwordBoxes;
    const top = found.find((item) => item.frameId === 0);
    const best = found.reduce((pick, item) => !pick || weight(item.scan) > weight(pick.scan) ? item : pick, top);
    if (!best) return null;
    formFrame.set(tabId, best.frameId);
    return best.scan;
  } catch {
    return null;
  }
}
var ACTION_STEP = {
  apply: "Opening the application\u2026",
  create_account: "Creating your account\u2026",
  sign_in: "Signing in\u2026",
  next: "Going to the next page\u2026",
  submit: "Submitting\u2026"
};
async function run(tabId) {
  const runId = ++runCounter;
  runs.set(tabId, runId);
  const earlier = (await jobs())[tabId];
  await saveJob(tabId, { running: true, step: "Reading the page\u2026", report: null, submission: null, error: null, clickedAt: null, llmCalls: 0, cv: false });
  const filledAll = [];
  const toCheck = /* @__PURE__ */ new Map();
  const noteCheck = (answers) => {
    for (const answer of answers) {
      if (!answer.values.length || answer.type === "file" || !REVIEW_SOURCES[answer.source ?? ""]) continue;
      toCheck.set(answer.label, answer.why?.trim() ? `${REVIEW_SOURCES[answer.source]} ${answer.why.trim()}`.slice(0, 220) : REVIEW_SOURCES[answer.source]);
    }
  };
  let applicationId = "";
  let posting = null;
  let filledKey = "";
  let pressedKey = "";
  let presses = 0;
  let errorValues = null;
  const signInFailedAt = /* @__PURE__ */ new Set();
  let triedApply = false;
  const started = Date.now();
  const trail = [];
  const note = (line) => {
    const at = Math.round((Date.now() - started) / 1e3);
    trail.push(`${at}s ${line}`);
    if (trail.length > 25) trail.shift();
  };
  const story = (lead) => {
    const lines = [...trail];
    while (lines.length && `${lead} What happened: ${lines.join("; ")}`.length > ISSUE_CHARS) lines.shift();
    return lines.length ? `${lead} What happened: ${lines.join("; ")}` : lead;
  };
  const questions = (fields) => {
    const shown = fields.slice(0, 6).map((field) => `${field.type} "${field.label.replace(/\s+/g, " ").slice(0, 30)}"`).join(", ");
    return fields.length > 6 ? `${shown} and ${fields.length - 6} more` : shown;
  };
  const pressed = (what, label) => {
    note(`pressed "${(what?.label || label).slice(0, 60)}"${what?.id ? ` [${what.id}]` : ""}${what?.overlay ? " via overlay" : ""}`);
  };
  let furthest = null;
  let seenStep = null;
  let lastPath = "";
  const stepFills = /* @__PURE__ */ new Map();
  const filledKeys = /* @__PURE__ */ new Set();
  const waitForChange = async (key, buttonsBefore, known, timeout = 12e3) => {
    const until = Date.now() + timeout;
    while (Date.now() < until && stillRunning(tabId, runId)) {
      await wait(300);
      const after = await look(tabId);
      if (!after) continue;
      const now = await send(tabId, { type: "status", knownAccount: known }).catch(() => null);
      if (signature(after) !== key || now && `${now.action?.kind}|${now.action?.label}|${now.apply}` !== buttonsBefore) return;
    }
  };
  let pressedAt2 = 0;
  let resume;
  let resumeError = null;
  const resumePromise = resumeFile();
  let llmCalls = 0;
  let lastStep = "";
  let resumeUploaded = false;
  let settling = "";
  let settleTries = 0;
  let spidersOut = false;
  let spidersDropped = false;
  let lastUrl = "";
  const spiders = (on) => {
    if (on === spidersOut) return;
    spidersOut = on;
    void send(tabId, { type: "spiders", on, drop: on && !spidersDropped }, 0).catch(() => void 0);
    if (on) spidersDropped = true;
  };
  const step = async (text, extra = {}) => {
    if (text === lastStep && !Object.keys(extra).length) return;
    lastStep = text;
    await saveJob(tabId, { step: text, ...extra });
  };
  try {
    const first = await look(tabId);
    if (!first) throw new Error("Couldn't read this page. Reload it, then press Fill.");
    if (first.embeddedForm && !first.fields.length && !first.passwordBoxes) throw new Error(`This page shows the form inside another site. Open the form directly, then press Fill: ${first.embeddedForm}`);
    spiders(true);
    const firstHost = new URL(first.url).hostname;
    if (earlier?.applicationId && !earlier.submission && sameApplication(earlier.url, first.url)) applicationId = earlier.applicationId;
    if (!hasForm(first) || first.fields.length < 3) posting = { url: first.url, title: first.title, company: first.company, description: first.description, poster: first.poster };
    while (stillRunning(tabId, runId)) {
      if ((await jobs())[tabId]?.submission) break;
      const scan = await look(tabId);
      if (!scan) {
        await wait(400);
        continue;
      }
      if (scan.url !== lastUrl && spidersOut) void send(tabId, { type: "spiders", on: true, drop: false }, 0).catch(() => void 0);
      lastUrl = scan.url;
      const site = accountKey(scan.url);
      const known = Boolean((await knownAccounts())[site]);
      const status = await send(tabId, { type: "status", knownAccount: known }).catch(() => null);
      if (!status) {
        await wait(400);
        continue;
      }
      if (!stillRunning(tabId, runId)) break;
      const path = (() => {
        try {
          return new URL(scan.url).pathname;
        } catch {
          return scan.url;
        }
      })();
      if (path !== lastPath) {
        note(`page ${path.slice(-80)}`);
        lastPath = path;
      }
      const now = status.step ?? null;
      if (stepText(now) !== stepText(seenStep)) {
        note(`now on ${stepText(now)}`);
        seenStep = now;
      }
      const submitted = status.confirmed || trail.some((line) => /pressed "[^"]*submit/i.test(line));
      if (!submitted && wentBack(furthest, now, Boolean(status.apply || status.action?.kind === "apply"))) {
        throw new Error(`Workday went back from ${stepText(furthest)} to ${stepText(now)}, so Unnepo stopped instead of filling it all again. Go back to ${stepText(furthest)} and press Fill. What happened is under Feedback.`);
      }
      if (now && (!furthest || now.total !== furthest.total || now.index > furthest.index)) furthest = now;
      if (!triedApply) {
        triedApply = true;
        if (status.apply) {
          await step("Opening the application\u2026");
          const reply2 = await send(tabId, { type: "press", first: true }).catch(() => ({ pressed: false, what: void 0 }));
          if (reply2.pressed) pressed(reply2.what, status.apply);
          if (reply2.pressed) await waitForChange(signature(scan), `${status.action?.kind}|${status.action?.label}|${status.apply}`, known, 4e3);
          continue;
        }
      }
      if (status.accountExists && !known) {
        await rememberAccount(site);
        continue;
      }
      if (status.signInFailed) {
        if (!signInFailedAt.has(site)) void addIssues(scan.url, [{ kind: "stopped", what: "The site didn't accept the sign-in." }]).catch(() => void 0);
        signInFailedAt.add(site);
        const account = (await knownAccounts())[site];
        await step(typeof account === "object" ? `The site didn't accept the password Unnepo made this account with. Use "Forgot your password?" on the site, set it to your Unnepo job-site password (Show, then Copy, below), and press Fill again.` : `This site already has an account for your email, with a password Unnepo doesn't know. Use "Forgot your password?" on the site, set it to your Unnepo job-site password (Show, then Copy, below), and press Fill again.`);
        await wait(1500);
        continue;
      }
      if (status.captcha) {
        await step("A CAPTCHA is on the page. Solve it and Unnepo carries on. Unnepo never solves CAPTCHAs.");
        await wait(1200);
        continue;
      }
      if (status.verifyEmail) {
        await step("The site sent you an email to verify your account. Open the link, come back to this tab, and Unnepo carries on.");
        await wait(1500);
        continue;
      }
      const key = signature(scan);
      const stepKey = status.step ? `${status.step.index}/${status.step.total}` : "";
      if (hasForm(scan) && key !== filledKey && !stepKey && filledKeys.has(key)) {
        throw new Error("Unnepo is back on a page it already filled, so it stopped instead of filling it again. Go to where you were and press Fill. What happened is on your issues list (Profile).");
      }
      if (hasForm(scan) && key !== filledKey && stepKey && (stepFills.get(stepKey) ?? 0) >= 2) {
        note(`didn't fill ${stepText(status.step)} a third time`);
        filledKey = key;
      }
      if (hasForm(scan) && key !== filledKey && stepKey && !stepFills.has(stepKey) && settleTries < 8 && settling !== `${stepKey}|${key}`) {
        if (!settling.startsWith(`${stepKey}|`)) settleTries = 0;
        settling = `${stepKey}|${key}`;
        settleTries += 1;
        await wait(900);
        continue;
      }
      if (hasForm(scan) && key !== filledKey) {
        if (stepKey) stepFills.set(stepKey, (stepFills.get(stepKey) ?? 0) + 1);
        filledKeys.add(key);
        note(`filling ${status.step ? stepText(status.step) : "the page"}: ${scan.fields.length} questions${scan.fields.length ? ` (${questions(scan.fields)})` : ""}`);
        if (!applicationId && (scan.fields.length || scan.useServerSchema)) {
          await step("Opening the job in Unnepo\u2026");
          const where = posting ?? { url: scan.url, title: scan.title, company: scan.company, description: scan.description, poster: scan.poster };
          const job2 = await api("POST", "jobs", where);
          applicationId = job2.application.id;
          await saveJob(tabId, { applicationId, title: job2.application.title, company: job2.application.company, url: where.url, host: firstHost });
        }
        const formFields = !scan.useServerSchema && !scan.fields.length ? null : scan.useServerSchema ? [] : scan.fields;
        let wantsCoverLetter = scan.fields.some((field) => field.type === "file" && /cover ?letter/i.test(`${field.label} ${field.section}`));
        const resumeBox = scan.useServerSchema || scan.fields.some((field) => field.type === "file" && !/cover ?letter/i.test(field.label));
        const workday = scan.ats === "workday";
        if (resumeBox && workday && resumeUploaded) note("didn't upload the resume again");
        const wantsResume = resumeBox && !(workday && resumeUploaded);
        if (scan.mentionsCv) await saveJob(tabId, { cv: true });
        const password = await passwordFor(accountKey(scan.url));
        const pageHost = new URL(scan.url).hostname;
        const dropdownFirst = await dropdownWay(pageHost);
        const fillWith = (answers, files = {}, schema = scan.useServerSchema) => send(tabId, { type: "fill", plan: { ats: scan.ats, useServerSchema: schema, answers, resume: files.resume ?? null, coverLetter: files.coverLetter ?? null, autoSubmit: false, password, dropdownFirst } }).catch(() => null);
        const merge = (into, next) => !into ? next : !next ? into : {
          ...next,
          filled: [...into.filled, ...next.filled],
          failed: [...into.failed.filter((item) => !next.filled.includes(item.label)), ...next.failed],
          attempts: [...into.attempts ?? [], ...next.attempts ?? []]
        };
        await step("Filling the form\u2026");
        const known2 = applicationId && formFields ? await api("POST", "map", { applicationId, fields: formFields, ai: false }).catch(() => ({ answers: [], llmCalls: 0 })) : { answers: [], llmCalls: 0 };
        if (scan.useServerSchema && known2.answers.some((answer) => answer.id === "cover_letter")) wantsCoverLetter = true;
        if (wantsResume && resume === void 0) {
          const got = await resumePromise;
          resume = got.file;
          resumeError = got.error;
        }
        if (!stillRunning(tabId, runId)) break;
        const letterSoon = wantsCoverLetter && applicationId ? api("POST", "cover-letter", { applicationId }).catch(() => null) : null;
        const answered = new Set(known2.answers.filter((answer) => answer.values.length).map((answer) => answer.id));
        const left = scan.useServerSchema ? null : scan.fields.filter((field) => field.type !== "file" && !answered.has(field.id));
        const askRest = applicationId && formFields && (scan.useServerSchema || left.length) ? api("POST", "map", { applicationId, fields: scan.useServerSchema ? [] : left }).catch(() => null) : Promise.resolve(null);
        noteCheck(known2.answers);
        let report = await fillWith(known2.answers, { resume: wantsResume ? resume ?? null : null });
        for (const attempt of report?.attempts ?? []) {
          if (attempt.type !== "file" || !attempt.ok) continue;
          note(`uploaded a file into "${attempt.label.slice(0, 30)}"`);
          if (workday) resumeUploaded = true;
        }
        if (applicationId && formFields && (scan.useServerSchema || left.length) && stillRunning(tabId, runId)) {
          await step("Answering the rest\u2026");
          const more = await askRest;
          llmCalls += more?.llmCalls ?? 0;
          await saveJob(tabId, { locked: more?.locked?.length ?? 0 });
          const fresh = (more?.answers ?? []).filter((answer) => answer.values.length && !answered.has(answer.id) && answer.type !== "file");
          noteCheck(fresh);
          if (fresh.length) report = merge(report, await fillWith(fresh));
        }
        const unmatched = (report?.failed ?? []).filter((item) => item.id && item.options?.length);
        if (applicationId && !scan.useServerSchema && unmatched.length && stillRunning(tabId, runId)) {
          const fields = unmatched.flatMap((item) => {
            const field = scan.fields.find((candidate) => candidate.id === item.id);
            return field ? [{ ...field, options: item.options }] : [];
          });
          const tried = new Map(unmatched.map((item) => [item.id, item.reason]));
          const picked = fields.length ? await api("POST", "map", { applicationId, fields }).catch(() => null) : null;
          llmCalls += picked?.llmCalls ?? 0;
          const again = (picked?.answers ?? []).filter((answer) => answer.values.length && !tried.get(answer.id)?.includes(`"${answer.values[0]}"`));
          noteCheck(again);
          if (again.length) report = merge(report, await fillWith(again));
        }
        if (report && scan.useServerSchema && applicationId) {
          const extra = await send(tabId, { type: "leftovers", ids: known2.answers.map((answer) => answer.id) }).catch(() => ({ fields: [] }));
          if (extra.fields.length) {
            const leftovers = await api("POST", "map", { applicationId, fields: extra.fields }).catch(() => null);
            if (leftovers?.answers.length) {
              llmCalls += leftovers.llmCalls;
              noteCheck(leftovers.answers);
              report = merge(report, await fillWith(leftovers.answers, {}, false));
            }
          }
        }
        if (wantsCoverLetter && applicationId && stillRunning(tabId, runId)) {
          await step("Attaching your cover letter\u2026");
          const letter = await (letterSoon ?? api("POST", "cover-letter", { applicationId }).catch(() => null));
          if (letter) {
            const file = { name: letter.fileName, mime: "application/pdf", base64: letter.pdfBase64 };
            const letterAnswer = scan.useServerSchema ? [{ id: "cover_letter", label: "Cover letter", type: "file", required: false, values: [file.name], source: "ai", why: null }] : [];
            report = merge(report, await fillWith(letterAnswer, { coverLetter: file }));
          }
        }
        await saveJob(tabId, { llmCalls });
        if (report && wantsResume && !resume && resumeError) report = { ...report, failed: [...report.failed, { label: "Resume", reason: resumeError }] };
        if (report) {
          filledAll.push(...report.filled);
          const filledSet = new Set(filledAll);
          const check = [...toCheck].filter(([label]) => filledSet.has(label)).map(([label, why]) => ({ label, why }));
          await saveJob(tabId, { report: { ...report, filled: [...filledAll], check }, llmCalls });
          if (applicationId) void api("POST", "activity", { applicationId, kind: "filled", fields: report.filled.length, needs: report.needsYou.length, ms: report.ms }).catch(() => void 0);
          void log(`Filled ${report.filled.length} fields on ${new URL(scan.url).hostname.replace(/^www\./, "")}${report.needsYou.length ? `, ${report.needsYou.length} left for you` : ""}.`);
          void addIssues(scan.url, report.failed.map((item) => ({ kind: "fill", question: item.label, what: `Couldn't fill: ${item.reason}` }))).catch(() => void 0);
          if (report.attempts?.length) {
            void rememberDropdownWay(pageHost, report.attempts).catch(() => void 0);
            if (applicationId) void api("POST", "attempts", { applicationId, attempts: report.attempts }).catch(() => void 0);
          }
        }
        filledKey = key;
        continue;
      }
      const unanswered = [...status.flagged, ...status.needsYou, ...((await jobs())[tabId]?.report?.failed ?? []).map((item) => item.label)];
      void send(tabId, { type: "mark-needs", labels: unanswered, check: (await jobs())[tabId]?.report?.check ?? [] }).catch(() => void 0);
      if (status.formErrors.length || status.flagged.length) {
        if (errorValues === null) errorValues = status.valuesKey;
        if (status.valuesKey === errorValues) {
          const job2 = (await jobs())[tabId];
          const needs = [.../* @__PURE__ */ new Set([...status.flagged, ...status.needsYou])];
          if (job2?.report) await saveJob(tabId, { report: { ...job2.report, needsYou: needs } });
          const said = status.formErrors[0] ? `The site says: "${status.formErrors[0].slice(0, 140)}". ` : "The site flagged some answers. ";
          void addIssues(scan.url, [{ kind: "site", what: `${said}${status.flagged.length ? `Flagged: ${status.flagged.slice(0, 5).join(", ")}.` : ""}`.trim() }]).catch(() => void 0);
          await step(`${said}${needs.length ? `Check ${needs.slice(0, 3).join(", ")}${needs.length > 3 ? ` and ${needs.length - 3} more` : ""}. ` : ""}Unnepo won't go on until you've fixed it.`);
          await wait(1200);
          continue;
        }
      }
      if (status.needsYou.length) {
        void addIssues(scan.url, status.needsYou.map((label) => ({ kind: "fill", question: label, what: "Unnepo couldn't answer this, so you had to." }))).catch(() => void 0);
        const job2 = (await jobs())[tabId];
        if (job2?.report) await saveJob(tabId, { report: { ...job2.report, needsYou: status.needsYou } });
        await step(`Waiting for you: ${status.needsYou.slice(0, 3).join(", ")}${status.needsYou.length > 3 ? ` and ${status.needsYou.length - 3} more` : ""}. Unnepo carries on when they're filled.`);
        await wait(1e3);
        continue;
      }
      const job = (await jobs())[tabId];
      if (job?.report?.needsYou.length) await saveJob(tabId, { report: { ...job.report, needsYou: [] } });
      const action = status.action;
      if (action?.kind === "apply" && (furthest || scan.ats === "workday" && filledKeys.size) && !status.confirmed) {
        throw new Error("The site went back to the job posting after Unnepo had filled the application, so Unnepo stopped instead of starting over. What happened is on your issues list (Profile).");
      }
      if (!action) {
        await step(status.confirmed ? "Looks submitted. Press Stop, then add it to your tracker with I already applied under More." : `Filled ${filledAll.length} fields. Watching the page; press Stop when you're done.`);
        await wait(1e3);
        continue;
      }
      if ((action.kind === "next" || action.kind === "submit") && status.reviewLeft) {
        await step(`Check ${status.reviewLeft} ${status.reviewLeft === 1 ? "answer" : "answers"} outlined in blue (the checklist is in the corner). Unnepo goes on when you're done.`);
        await wait(1e3);
        continue;
      }
      if (action.kind === "submit" && !(await settings()).autoSubmit) {
        await step(`Everything's filled. Check the form, then press "${action.label}" on the page.`);
        await wait(1e3);
        continue;
      }
      if (action.kind === "sign_in" && signInFailedAt.has(site)) {
        await wait(1500);
        continue;
      }
      const pressKey = `${key}|${action.kind}|${action.label}`;
      if (pressKey === pressedKey && (action.kind === "sign_in" || action.kind === "create_account")) {
        await step(`Pressed "${action.label}", but the page didn't move. Check the page; Unnepo carries on when it changes.`);
        await wait(1500);
        continue;
      }
      if (pressKey === pressedKey && presses >= 2 && Date.now() - pressedAt2 < 8e3) {
        await step(`Pressed "${action.label}", but the page didn't move. Something on the page may need you; Unnepo carries on when it changes.`);
        await wait(1200);
        continue;
      }
      errorValues = null;
      presses = pressKey === pressedKey ? presses + 1 : 1;
      pressedKey = pressKey;
      pressedAt2 = Date.now();
      await step(ACTION_STEP[action.kind]);
      const reply = await send(tabId, { type: "press", kind: action.kind, knownAccount: known }).catch(() => ({ pressed: false, what: void 0 }));
      if (!reply.pressed) {
        await wait(300);
        continue;
      }
      pressed(reply.what, action.label);
      await waitForChange(key, `${action.kind}|${action.label}|${status.apply}`, known);
      if (action.kind === "create_account") {
        const notes = await send(tabId, { type: "status", knownAccount: known }).catch(() => null);
        if (notes?.accountExists) await rememberAccount(site);
        else if (!notes?.action || notes.action.kind !== "create_account") await rememberAccount(site, await passwordFor(site));
      }
    }
    if ((await jobs())[tabId]?.submission) return;
    if (furthest) await addIssues(lastUrl, [{ kind: "stopped", what: story(`You pressed Stop on ${stepText(seenStep)}.`) }]).catch(() => void 0);
    await saveJob(tabId, { step: "Stopped. Press Fill to start again." });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Something went wrong.";
    await addIssues((await chrome.tabs.get(tabId).catch(() => null))?.url ?? lastUrl, [{ kind: "stopped", what: story(`Stopped: ${message}`) }]).catch(() => void 0);
    await saveJob(tabId, { error: message, step: "Stopped." });
  } finally {
    if (stillRunning(tabId, runId)) runs.delete(tabId);
    await saveJob(tabId, { running: false }).catch(() => void 0);
    void send(tabId, { type: "spiders", on: false }, 0).catch(() => void 0);
  }
}
async function readLinkInTab(url) {
  let host = "";
  try {
    host = new URL(url).hostname;
  } catch {
    return null;
  }
  if (!/^https:\/\//.test(url) || !host) return null;
  const tab = await chrome.tabs.create({ url, active: false }).catch(() => null);
  if (!tab?.id) return null;
  const tabId = tab.id;
  try {
    await new Promise((done) => {
      const timer = setTimeout(finish, 2e4);
      function finish() {
        clearTimeout(timer);
        chrome.tabs.onUpdated.removeListener(listen);
        done();
      }
      function listen(id, info) {
        if (id === tabId && info.status === "complete") finish();
      }
      chrome.tabs.onUpdated.addListener(listen);
    });
    for (let tries = 0; tries < 6; tries += 1) {
      await new Promise((done) => setTimeout(done, 1500));
      await chrome.scripting.executeScript({ target: { tabId, frameIds: [0] }, files: ["content/fill.js"] }).catch(() => void 0);
      const job = await send(tabId, { type: "opened-job" }, 0).catch(() => null);
      if (job?.title && job.from !== "page") {
        const place = job.description.match(/\b([A-Z][a-zA-Z .'-]+, (?:[A-Z]{2}|[A-Z][a-z]+))\b/)?.[1] ?? "";
        return { title: job.title, company: job.company, location: place, description: job.description, url };
      }
    }
    return null;
  } finally {
    await chrome.tabs.remove(tabId).catch(() => void 0);
  }
}
async function readLink(url) {
  try {
    return await api("POST", "read-link", { url });
  } catch (error) {
    if (!(error instanceof ApiError) || error.code !== "in_browser") return { info: null, error: error instanceof Error ? error.message : "Couldn't read the link." };
  }
  const info = await readLinkInTab(url);
  return info ? { info } : { info: null, error: "Couldn't find the job on that page. Sign in to the job board in Chrome, then try again." };
}
async function record(tabId, confidence, text, how = confidence === "confirmed" ? "site_confirmed" : "page_said") {
  const job = (await jobs())[tabId];
  if (!job?.applicationId || job.submission === "confirmed" || job.submission === "likely" && confidence === "likely") return;
  const caught = how !== "you_marked";
  if (caught && !(confidence === "confirmed" && SURE_HOWS.has(how) && await savesByItself())) {
    await noteDetected({ url: job.url, title: job.title, company: job.company, applicationId: job.applicationId, sure: confidence, state: "ask" });
    return void log(`The page looks applied (${HOW_SAID[how]}). It's under Detected jobs on Home.`);
  }
  await saveJob(tabId, { submission: confidence });
  let screenshot;
  try {
    const tab = await chrome.tabs.get(tabId);
    if (tab.active) screenshot = await chrome.tabs.captureVisibleTab(tab.windowId, { format: "jpeg", quality: 60 });
  } catch {
  }
  const seen = (await seenJobs())[tabId];
  const postingUrl = seen?.url && !sameJobPage(seen.url, job.url) && sameCompany(seen.company, job.company) ? seen.url : void 0;
  try {
    await saveSubmission({ applicationId: job.applicationId, url: job.url, postingUrl, confidence, text, screenshot, how });
    void log(`Saved: ${job.title} at ${job.company} (${HOW_SAID[how]}).`);
    if (caught) await noteDetected({ url: job.url, title: job.title, company: job.company, applicationId: job.applicationId, sure: confidence, state: "saved" });
    celebrate(tabId);
    await saveJob(tabId, { step: confidence === "confirmed" ? "Submitted. The site accepted your application, and it's in your Unnepo tracker." : "Looks submitted. It's in your Unnepo tracker; check your email for the site's confirmation." });
  } catch (error) {
    await saveJob(tabId, { submission: null, error: error instanceof Error ? `Couldn't save the submission: ${error.message}` : "Couldn't save the submission." });
    await addMaybe({ url: job.url, title: job.title, company: job.company, applicationId: job.applicationId });
    void log(`Couldn't save ${job.title} at ${job.company}: ${error instanceof Error ? error.message : "no answer from Unnepo"}.`);
  }
}
function celebrate(tabId) {
  void chrome.scripting.executeScript({ target: { tabId, frameIds: [0] }, files: ["content/fill.js"] }).catch(() => void 0).then(() => send(tabId, { type: "spiders", celebrate: true }, 0)).catch(() => void 0);
}
async function saveSubmission(body) {
  try {
    return await api("POST", "submissions", body);
  } catch (error) {
    if (error instanceof Error && /couldn't tell which job/i.test(error.message)) throw error;
    await new Promise((done) => setTimeout(done, 2e3));
    return api("POST", "submissions", body);
  }
}
var SUBMIT_REQUEST = /(application|apply|submit|candidate|jobs\/\d+)/i;
var NOT_SUBMIT = /(analytics|collect|track|log|metrics|beacon|sentry|segment|recaptcha|hcaptcha|captcha)/i;
var LINKEDIN_APPLY = /\/voyager\/api\/[^?]*(onsiteapply|easyapply|jobapplication|applyapplication)|[?&]action=(submit|apply)[a-z]*application|\/jobs-apply\/|\/apply\/submit/i;
async function recordLinkedIn(tabId) {
  if (tabId < 0) return void log("Saw an Easy Apply on LinkedIn, but not which tab it was in.");
  const scan = await look(tabId).catch(() => null);
  if (scan?.description) await rememberSeen(tabId, scan);
  await recordSeen(tabId, "LinkedIn Easy Apply sent your application.", "linkedin_easy_apply");
}
var applyClicks = /* @__PURE__ */ new Map();
var BOARD_APPLY = /\/(apply|applications?|quick[-_]?apply|one[-_]?click)(\/|\?|$)|[?&](action|op)=apply\b/i;
var BOARD_NOT_APPLY = /(view|impression|track|analytics|log|metric|beacon|event|recommend|save[-_]?job|bookmark)/i;
var pressedAt = /* @__PURE__ */ new Map();
var pressTrace = /* @__PURE__ */ new Map();
var graphApplies = /* @__PURE__ */ new Set();
var GRAPH_APPLY = /(apply|application|submit)/i;
var GRAPH_NOT_APPLY = /^(get|fetch|list|search|load|query)|search|view|count|recommend|saved|bookmark|draft|track|log|event|impression|preview|eligib/i;
function graphOps(body) {
  const bytes = body?.raw?.[0]?.bytes;
  if (!bytes) return [];
  try {
    const data = JSON.parse(new TextDecoder().decode(bytes).slice(0, 3e5));
    return (Array.isArray(data) ? data : [data]).map((op) => {
      const query = typeof op?.query === "string" ? String(op.query) : "";
      const name = String(op?.operationName ?? "") || query.match(/^\s*(?:mutation|query)\s+(\w+)/)?.[1] || "";
      return { name, mutation: query ? /^\s*mutation\b/.test(query) : null };
    }).filter((op) => op.name);
  } catch {
    return [];
  }
}
chrome.webRequest.onBeforeRequest.addListener((details) => {
  if (details.method !== "POST" || details.tabId < 0) return;
  const at = pressedAt.get(details.tabId);
  if (!at || Date.now() - at > 12e4) return;
  let url;
  try {
    url = new URL(details.url);
  } catch {
    return;
  }
  if (NOT_SUBMIT.test(url.hostname + url.pathname)) return;
  const ops = /graphql/i.test(url.pathname) ? graphOps(details.requestBody) : [];
  const trace = pressTrace.get(details.tabId) ?? [];
  trace.push(`${url.hostname}${url.pathname.slice(0, 60)}${ops.length ? ` (${ops.map((op) => op.name).join(", ").slice(0, 80)})` : ""}`);
  pressTrace.set(details.tabId, trace.slice(-12));
  if (ops.some((op) => op.mutation !== false && GRAPH_APPLY.test(op.name) && !GRAPH_NOT_APPLY.test(op.name))) graphApplies.add(details.requestId);
}, { urls: ["https://*/*"] }, ["requestBody"]);
chrome.webRequest.onErrorOccurred.addListener((details) => {
  graphApplies.delete(details.requestId);
}, { urls: ["https://*/*"] });
chrome.webRequest.onCompleted.addListener((details) => {
  const graphApply = graphApplies.delete(details.requestId);
  if (details.method !== "POST" || details.tabId < 0 || details.statusCode < 200 || details.statusCode >= 300) return;
  if (graphApply) {
    applyClicks.delete(details.tabId);
    void log("The job site's own request to send the application went through.");
    void recordSeen(details.tabId, "The job site saved your application.", "board_saved").catch(() => void 0);
    return;
  }
  try {
    if (LINKEDIN.test(new URL(details.url).hostname) && LINKEDIN_APPLY.test(details.url)) {
      void recordLinkedIn(details.tabId).catch(() => void 0);
      return;
    }
  } catch {
    return;
  }
  const clicked = applyClicks.get(details.tabId);
  if (clicked && Date.now() - clicked < 6e4 && BOARD_APPLY.test(details.url) && !BOARD_NOT_APPLY.test(details.url)) {
    applyClicks.delete(details.tabId);
    void recordSeen(details.tabId, "The job site saved your application.", "board_saved").catch(() => void 0);
  }
  void jobs().then((all) => {
    const job = all[details.tabId];
    if (!job?.clickedAt || Date.now() - job.clickedAt > 6e4) return;
    const host = new URL(details.url).hostname;
    const sameSite = host === job.host || host.split(".").slice(-2).join(".") === job.host.split(".").slice(-2).join(".");
    if (sameSite && SUBMIT_REQUEST.test(details.url) && !NOT_SUBMIT.test(details.url)) void record(details.tabId, "confirmed", "The site accepted the submission.");
  });
}, { urls: ["https://*/*"] });
var CONFIRM_URL = /\/(confirmation|confirmed|thank-?you|thanks|application-?(submitted|complete|received)|submitted|success)(\/|\?|#|$)|[?&](submitted|success|applied|application_submitted)=(true|1)\b/i;
async function confirmationPage(details) {
  if (details.frameId !== 0 || details.tabId < 0 || !CONFIRM_URL.test(details.url)) return;
  const [job, seen] = [(await jobs())[details.tabId], (await seenJobs())[details.tabId]];
  if (job?.applicationId && !job.submission && (job.clickedAt || job.report?.filled.length)) return void record(details.tabId, "confirmed", "The site's confirmation page opened.", "site_confirmed");
  if (!job?.submission && (seen?.form || seen?.sent)) {
    void log("The site moved to its confirmation page.");
    await recordSeen(details.tabId, "The site's confirmation page opened.", "site_confirmed");
  }
}
chrome.webNavigation.onCompleted.addListener((details) => void confirmationPage(details).catch(() => void 0));
chrome.webNavigation.onHistoryStateUpdated.addListener((details) => void confirmationPage(details).catch(() => void 0));
var localDay = (date = /* @__PURE__ */ new Date()) => `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
async function boardHandled() {
  return (await chrome.storage.local.get("boardHandled")).boardHandled ?? [];
}
async function markBoardHandled(keys) {
  const list = await boardHandled();
  await chrome.storage.local.set({ boardHandled: [...keys, ...list.filter((key) => !keys.includes(key))].slice(0, 500) });
}
var boardKey = (job) => `${job.url.split("#")[0]}|${job.title.trim().toLowerCase()}|${job.company.trim().toLowerCase()}`;
var appliedInTracker = (tracked, job) => Boolean(tracked?.jobs.some((item) => (item.status === "submitted" || item.status === "applied_manual") && !item.titleMissing && sameJobTitle(item, job)));
var boardBusy = /* @__PURE__ */ new Set();
async function boardApplied(tabId, text, day) {
  if (boardBusy.has(tabId)) return;
  boardBusy.add(tabId);
  try {
    await saveBoardApplied(tabId, text, day);
  } finally {
    boardBusy.delete(tabId);
  }
}
async function saveBoardApplied(tabId, text, day) {
  const scan = await look(tabId).catch(() => null);
  if (!scan || /^job title missing$/i.test(scan.title) || notJobTitle(scan.title) || !scan.company.trim()) return void log(`The page says "${text.slice(0, 50)}", but the job's name couldn't be read.`);
  const job = { url: scan.jobUrl || scan.url, title: scan.title, company: scan.company };
  const key = boardKey(job);
  if ((await boardHandled()).includes(key)) return;
  const tracked = (await jobs())[tabId];
  if (tracked?.submission && sameJobTitle(tracked, job)) return void markBoardHandled([key]);
  if (appliedInTracker((await trackerCopy())?.data, job)) return void markBoardHandled([key]);
  if ((await detectedList()).some((item) => sameJobTitle(item, job) && (item.state === "no" || item.state === "undone"))) return void markBoardHandled([key]);
  await rememberSeen(tabId, scan);
  await markBoardHandled([key]);
  const fresh = !day || day === localDay();
  void log(`The board says "${text.slice(0, 50)}" for ${job.title} at ${job.company}.`);
  if (!await savesByItself()) {
    await noteDetected({ ...job, description: scan.description, poster: scan.poster, sure: "confirmed", state: "ask" });
    return void log("It's under Detected jobs on Home.");
  }
  try {
    const saved = await saveSubmission({ ...job, description: scan.description, poster: scan.poster, confidence: "confirmed", text, how: "board_saved", ...day ? { appliedOn: day } : {}, ...fresh ? {} : { noPeople: true } });
    if (fresh) celebrate(tabId);
    await noteDetected({ ...job, title: saved.application.title, company: saved.application.company, applicationId: saved.application.id, sure: "confirmed", state: "saved" });
    void log(`Saved: ${saved.application.title} at ${saved.application.company} (the job board says you applied${day && !fresh ? ` on ${day}` : ""}).`);
    void readTracker().then(() => chrome.runtime.sendMessage({ type: "tracker-changed" }).catch(() => void 0), () => void 0);
  } catch (error) {
    await noteDetected({ ...job, description: scan.description, sure: "likely", state: "ask" });
    void log(error instanceof Error ? `Couldn't save it: ${error.message}` : "Couldn't save it.");
  }
}
var pageKey = (url) => url.split("#")[0];
async function boardLists() {
  return (await chrome.storage.session.get("boardLists")).boardLists ?? {};
}
async function missingFromBoard(list) {
  const tracked = (await trackerCopy())?.data;
  return list.items.filter((item) => !appliedInTracker(tracked, item));
}
var TRACKER_FRESH_MS = 15e3;
var trackerReading = null;
async function trackerCopy() {
  return (await chrome.storage.local.get("trackerCopy")).trackerCopy ?? null;
}
function readTracker() {
  trackerReading ??= api("GET", "tracker").then(async (data) => {
    await chrome.storage.local.set({ trackerCopy: { at: Date.now(), data } });
    void updateBadge();
    return data;
  }).finally(() => {
    trackerReading = null;
  });
  return trackerReading;
}
async function tracker(fresh = false) {
  const copy = await trackerCopy();
  if (!copy || fresh) return readTracker();
  if (Date.now() - copy.at > TRACKER_FRESH_MS) void readTracker().then(() => chrome.runtime.sendMessage({ type: "tracker-changed" }).catch(() => void 0), () => void 0);
  return copy.data;
}
async function dueReminders() {
  const [copy, stored] = await Promise.all([trackerCopy(), chrome.storage.local.get(["reminderMarks", "openedEmails", "followUps"])]);
  if (!copy) return [];
  return reminders(copy.data, stored.reminderMarks ?? {}, stored.openedEmails ?? {}, stored.followUps ?? {}).items;
}
async function updateBadge() {
  const { token } = await settings();
  const asking = token ? (await detectedList()).filter((item) => item.state === "ask").length : 0;
  const due = token ? dueCount(await dueReminders()) : 0;
  const count = asking + due;
  await chrome.action.setBadgeBackgroundColor({ color: asking ? "#F5A524" : "#3D8BFF" }).catch(() => void 0);
  await chrome.action.setBadgeText({ text: count ? String(Math.min(count, 99)) : "" }).catch(() => void 0);
}
var REMINDER_ALARM = "reminders";
async function checkReminders() {
  const { token } = await settings();
  if (!token) return;
  await readTracker().catch(() => void 0);
  const items = await dueReminders();
  const count = dueCount(items);
  const stored = await chrome.storage.local.get(["notify", "notifiedOn"]);
  const today = (/* @__PURE__ */ new Date()).toDateString();
  if (!count || stored.notify === false || stored.notifiedOn === today) return;
  await chrome.storage.local.set({ notifiedOn: today });
  const first = items.find((item) => item.kind !== "finish");
  chrome.notifications.create(REMINDER_ALARM, {
    type: "basic",
    iconUrl: chrome.runtime.getURL("icons/128.png"),
    title: count === 1 ? "1 thing to do on Unnepo" : `${count} things to do on Unnepo`,
    message: first ? `${first.title}${count > 1 ? `, and ${count - 1} more` : ""}.` : "Open Unnepo to see them.",
    priority: 1
  });
}
void chrome.alarms.get(REMINDER_ALARM).then((alarm) => {
  if (!alarm) void chrome.alarms.create(REMINDER_ALARM, { delayInMinutes: 1, periodInMinutes: 180 });
});
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === REMINDER_ALARM) void checkReminders();
});
chrome.notifications.onClicked.addListener((id) => {
  if (id !== REMINDER_ALARM) return;
  chrome.notifications.clear(id);
  void chrome.tabs.create({ url: chrome.runtime.getURL("dashboard/dashboard.html") });
});
var fromExtension = (sender) => sender.id === chrome.runtime.id && (!sender.tab || (sender.url ?? "").startsWith(chrome.runtime.getURL("")));
var failed = (error, fallback) => ({ ok: false, error: error instanceof Error ? error.message : fallback });
chrome.runtime.onMessage.addListener((message, sender, reply) => {
  const tabId = sender.tab?.id;
  void (async () => {
    switch (message?.type) {
      case "state":
        return reply(await state());
      case "list-issues":
        return reply({ issues: await issues() });
      case "add-issue": {
        const note = String(message.note ?? "").trim();
        if (!note) return reply({ ok: false });
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        await addIssues(tab?.url && /^https?:/.test(tab.url) ? tab.url : "", [{ kind: "note", what: note }]);
        return reply({ ok: true });
      }
      case "clear-issues":
        await chrome.storage.local.remove("issues");
        void chrome.runtime.sendMessage({ type: "state-changed" }).catch(() => void 0);
        return reply({ ok: true });
      case "connect": {
        const origin = sender.tab ? String(message.origin ?? "") : (await settings()).apiBase;
        if (sender.tab && !ALLOWED_API.test(origin)) return reply({ ok: false });
        await chrome.storage.local.set({ token: String(message.token), apiBase: ALLOWED_API.test(origin) ? origin : DEFAULT_API });
        await chrome.storage.local.remove(["trackerCopy", "detected"]);
        void checkReminders();
        void chrome.runtime.sendMessage({ type: "state-changed" }).catch(() => void 0);
        return reply({ ok: true });
      }
      case "disconnect":
        await api("DELETE", "token").catch(() => void 0);
        await chrome.storage.local.remove(["token", "trackerCopy", "detected", "openedEmails", "reminderMarks", "followUps", "notifiedOn"]);
        void updateBadge();
        return reply({ ok: true });
      // Only the side panel (no tab) may read or change the password; web pages never can.
      case "get-password":
        if (sender.tab) return reply({ ok: false });
        return reply({ ok: true, password: await jobSitePassword() });
      case "set-password": {
        if (sender.tab) return reply({ ok: false });
        const value = String(message.value ?? "");
        const unmet = unmetRules(value);
        if (unmet.length) return reply({ ok: false, unmet });
        await chrome.storage.local.set({ jobSitePassword: value });
        return reply({ ok: true, password: value });
      }
      case "new-password": {
        if (sender.tab) return reply({ ok: false });
        const password = generatePassword();
        await chrome.storage.local.set({ jobSitePassword: password });
        return reply({ ok: true, password });
      }
      // The panel's resume row: see it, or upload a new one.
      case "get-resume": {
        if (sender.tab) return reply({ ok: false });
        const got = await resumeFile();
        return reply({ ok: Boolean(got.file), file: got.file, error: got.error });
      }
      case "upload-resume":
        if (sender.tab) return reply({ ok: false });
        try {
          await uploadResume(String(message.name), String(message.mime), String(message.base64));
          resumeReady = null;
          void chrome.runtime.sendMessage({ type: "state-changed" }).catch(() => void 0);
          return reply({ ok: true });
        } catch (error) {
          return reply({ ok: false, error: error instanceof Error ? error.message : "Upload failed." });
        }
      // The panel's cover letter: for the job on this tab. The job is opened in Unnepo first if it isn't yet.
      case "generate-letter": {
        if (sender.tab) return reply({ ok: false });
        const tabId2 = Number(message.tabId);
        try {
          if (typeof message.description === "string") {
            const letter2 = await api("POST", "cover-letter", { description: message.description, ...message.options ?? {} });
            return reply({ ok: true, doc: letter2 });
          }
          const earlier = (await jobs())[tabId2];
          const scan = earlier?.applicationId ? await look(tabId2) : null;
          const applicationId = earlier?.applicationId && (!scan || earlier.running || sameApplication(earlier.url, scan.url)) ? earlier.applicationId : void 0;
          if (!applicationId) {
            const given = message.job;
            const job = given?.title ? given : await readJobDetails(tabId2);
            if (!job?.title) throw new Error("Open the job posting or its application in this tab first.");
            const letter2 = await api("POST", "cover-letter", { job: { title: job.title, company: job.company || job.site || "", description: job.description ?? "" }, ...message.options ?? {} });
            return reply({ ok: true, doc: letter2 });
          }
          const letter = await api("POST", "cover-letter", { applicationId, ...message.options ?? {} });
          return reply({ ok: true, doc: letter });
        } catch (error) {
          return reply({ ok: false, error: error instanceof Error ? error.message : "Couldn't write the cover letter." });
        }
      }
      // The panel's "My jobs".
      case "list-jobs":
        if (sender.tab) return reply({ ok: false });
        try {
          return reply({ ok: true, ...await api("GET", "jobs") });
        } catch (error) {
          return reply({ ok: false, error: error instanceof Error ? error.message : "Couldn't load your jobs." });
        }
      // The panel's CV generator: a CV for the job on this tab (or a general one), paid for with credits.
      case "generate-cv": {
        if (sender.tab) return reply({ ok: false });
        const job = (await jobs())[Number(message.tabId)];
        try {
          const cv = await api("POST", "cv", { applicationId: job?.applicationId || void 0 });
          void chrome.runtime.sendMessage({ type: "state-changed" }).catch(() => void 0);
          return reply({ ok: true, cv });
        } catch (error) {
          return reply({ ok: false, error: error instanceof Error ? error.message : "Couldn't write the CV." });
        }
      }
      // "Still needs you" in the panel: show that question on the page.
      case "focus-field":
        if (sender.tab) return reply({ ok: false });
        return reply(await send(Number(message.tabId), { type: "focus-field", label: String(message.label ?? "") }).catch(() => ({ ok: false })));
      // The spider on job pages: open the side panel for that tab. Chrome allows it right after a click.
      case "panel-state":
        return reply({ open: sender.tab ? panelWindows.has(sender.tab.windowId) : false });
      case "open-panel":
        if (tabId === void 0) return reply({ ok: false });
        try {
          await chrome.sidePanel.open({ tabId });
          return reply({ ok: true });
        } catch {
          return reply({ ok: false });
        }
      case "set-auto-submit":
        await chrome.storage.local.set({ autoSubmit: Boolean(message.value) });
        return reply({ ok: true });
      case "fill": {
        if (!AUTOFILL_ENABLED && message.beta !== true) return reply({ ok: false, error: "Autofill is turned off." });
        const tab = await chrome.tabs.get(Number(message.tabId)).catch(() => null);
        if (tab?.url && LINKEDIN.test(new URL(tab.url).hostname)) {
          await saveJob(Number(message.tabId), { error: "Unnepo doesn't fill LinkedIn. Open the job's own application (Apply on the company's site), then press Fill.", step: "Stopped." });
          return reply({ ok: false });
        }
        if (!runs.has(Number(message.tabId))) void run(Number(message.tabId));
        return reply({ ok: true });
      }
      case "stop":
        runs.delete(Number(message.tabId));
        await saveJob(Number(message.tabId), { running: false, step: "Stopped. Press Fill to start again." });
        return reply({ ok: true });
      case "clear-error":
        await saveJob(Number(message.tabId), { error: null, step: "" });
        return reply({ ok: true });
      case "applied":
        await record(Number(message.tabId), "likely", "Marked as applied in the extension.", "you_marked");
        return reply({ ok: true });
      case "not-applied": {
        const job = (await jobs())[Number(message.tabId)];
        if (job?.applicationId) await api("POST", "submissions/undo", { applicationId: job.applicationId }).catch(() => void 0);
        await saveJob(Number(message.tabId), { submission: null, step: "Marked as not applied." });
        return reply({ ok: true });
      }
      case "submit-clicked":
        if (tabId === void 0 || !(await jobs())[tabId]?.applicationId) return reply({ ok: false });
        await saveJob(tabId, { clickedAt: Date.now() });
        if (Array.isArray(message.answers) && message.answers.length) {
          await api("POST", "answers", { answers: message.answers }).catch(() => void 0);
          const page = issuePage(String(message.url ?? sender.tab?.url ?? "")).page;
          const listed = new Set((await issues()).filter((issue) => issue.page === page && issue.kind === "fill").map((issue) => issue.question));
          const questions = message.answers.map((answer) => String(answer.question ?? "").trim()).filter((question) => question && !listed.has(question));
          await addIssues(String(message.url ?? sender.tab?.url ?? ""), questions.map((question) => ({ kind: "fill", question, what: "You filled this in yourself: Unnepo left it empty or got it wrong." }))).catch(() => void 0);
        }
        return reply({ ok: true });
      case "write-answer": {
        const job = tabId === void 0 ? null : (await jobs())[tabId];
        if (!job?.applicationId) return reply({ error: "Press Fill in Unnepo first, so it knows which job this is." });
        try {
          const written = await api("POST", "write", { applicationId: job.applicationId, question: String(message.label ?? "") });
          return reply({ answer: written.answer });
        } catch (error) {
          return reply({ error: error instanceof Error ? error.message : "Couldn't write this one." });
        }
      }
      // The panel's "Answer a question": for the job on the tab when Unnepo knows it, or from the profile alone.
      case "answer-question": {
        if (sender.tab) return reply({ ok: false });
        try {
          const job = (await jobs())[Number(message.tabId)];
          const given = message.job;
          const written = await api("POST", "write", { question: String(message.question ?? ""), length: message.length, ...job?.applicationId ? { applicationId: job.applicationId } : given?.title ? { job: { title: given.title, company: given.company || given.site, description: given.description } } : {} });
          return reply({ ok: true, answer: written.answer });
        } catch (error) {
          return reply({ ok: false, error: error instanceof Error ? error.message : "Couldn't write this one." });
        }
      }
      // The job box: what the page says about the job. The resume starts loading now, for Begin applying.
      case "job-details": {
        if (sender.tab) return reply({ ok: false });
        const details = await readJobDetails(Number(message.tabId)).catch(() => null);
        if (details) void readyResume();
        return reply({ ok: Boolean(details), details });
      }
      // "Begin applying": resume in, spiders beside the complex questions.
      // "Attach" on the cover letter: into the cover letter box on the tab's page or any of its form frames.
      case "attach-letter": {
        if (sender.tab) return reply({ ok: false });
        const file = message.file;
        if (!file?.base64) return reply({ ok: false, error: "Write the cover letter first." });
        const attached = await attachEverywhere(Number(message.tabId), { type: "attach-letter", file });
        if (!attached.length) return reply({ ok: false, error: "No cover letter upload box on this page yet. Open the application, then press Attach." });
        void log(`Attached your cover letter to "${attached[0].slice(0, 40)}".`);
        return reply({ ok: true, attached });
      }
      // "Attach" beside the resume: the resume file into the application's resume box.
      case "attach-resume": {
        if (sender.tab) return reply({ ok: false });
        const resume = await readyResume();
        if (!resume.file) return reply({ ok: false, error: resume.error ?? "Upload your resume first." });
        const attached = await attachEverywhere(Number(message.tabId), { type: "attach-resume", file: resume.file });
        if (!attached.length) return reply({ ok: false, error: "No empty resume upload box on this page. Open the application, then press Attach." });
        void log(`Attached your resume to "${attached[0].slice(0, 40)}".`);
        return reply({ ok: true, attached });
      }
      case "begin-applying": {
        if (sender.tab) return reply({ ok: false });
        try {
          return reply({ ok: true, applying: await beginApplying(Number(message.tabId), message.questionsOnly === true ? true : void 0) });
        } catch {
          return reply({ ok: false, error: "Couldn't reach the page. Reload it and press Begin applying again." });
        }
      }
      // The form moved on to its next step (or an upload box showed up): the page did it again by itself.
      case "applying-changed": {
        if (tabId === void 0) return reply({ ok: false });
        const before = (await applyingAll())[tabId];
        if (!before) return reply({ ok: false });
        const result = message.result;
        await saveApplying(tabId, { ...before, ...result, uploaded: [.../* @__PURE__ */ new Set([...before.uploaded, ...result.uploaded])], url: sender.tab?.url ?? before.url });
        return reply({ ok: true });
      }
      case "stop-applying": {
        if (sender.tab) return reply({ ok: false });
        const id = Number(message.tabId);
        await send(id, { type: "stop-applying" }).catch(() => void 0);
        await saveApplying(id, null);
        return reply({ ok: true });
      }
      // "Answer complex questions": writes an answer for each one still empty, and types it into its box.
      case "answer-complex": {
        if (sender.tab) return reply({ ok: false });
        const id = Number(message.tabId);
        const applying = (await applyingAll())[id];
        if (!applying) return reply({ ok: false, error: "Press Begin applying first." });
        const given = message.job;
        const tracked = (await jobs())[id];
        const context = tracked?.applicationId ? { applicationId: tracked.applicationId } : given?.title ? { job: { title: given.title, company: given.company || given.site, description: given.description } } : {};
        const answers = { ...applying.answers ?? {} };
        const todo = applying.questions.filter((question) => !question.answered && !answers[question.id]?.put && !(message.put === false && answers[question.id]?.text));
        let next = 0;
        let stopped = "";
        const worker = async () => {
          while (next < todo.length && !stopped) {
            const question = todo[next++];
            try {
              const long = question.label.length > 60 || /describe|tell us|explain|why/i.test(question.label);
              const written = await api("POST", "write", { question: question.label, batch: true, ...long ? { length: "paragraph" } : {}, ...context });
              const put = message.put === false ? { ok: false, reason: "" } : await send(id, { type: "put-answer", id: question.id, text: written.answer }).catch(() => ({ ok: false, reason: "Couldn't reach the page." }));
              answers[question.id] = { text: written.answer, put: put.ok, ...put.ok || !put.reason ? {} : { error: put.reason } };
            } catch (error) {
              const why = error instanceof Error ? error.message : "Couldn't write this one.";
              answers[question.id] = { text: "", put: false, error: why };
              if (error instanceof ApiError && (error.status === 402 || error.status === 429 || /limit|credits|upgrade/i.test(why))) stopped = why;
            }
          }
        };
        await Promise.all([worker(), worker(), worker()]);
        await saveApplying(id, { ...applying, answers });
        return reply({ ok: true, written: todo.filter((question) => answers[question.id]?.text).length, stopped });
      }
      // An answer edited in the panel, put in its box again; or the page scrolled to a question.
      case "put-answer": {
        if (sender.tab) return reply({ ok: false });
        const id = Number(message.tabId);
        const result = await send(id, { type: "put-answer", id: String(message.id), text: String(message.text ?? ""), replace: true }).catch(() => ({ ok: false, reason: "Couldn't reach the page." }));
        const applying = (await applyingAll())[id];
        if (applying?.answers?.[String(message.id)]) {
          applying.answers[String(message.id)] = { text: String(message.text ?? ""), put: result.ok, ...result.ok ? {} : { error: result.reason } };
          await saveApplying(id, applying);
        }
        return reply(result);
      }
      case "show-question":
        if (sender.tab) return reply({ ok: false });
        return reply(await send(Number(message.tabId), { type: "show-question", id: String(message.id) }).catch(() => ({ ok: false })));
      // An applying session, started or ended from the panel.
      case "session":
        if (sender.tab) return reply({ ok: false });
        try {
          return reply({ ok: true, ...await api("POST", "session", { start: Boolean(message.start) }) });
        } catch (error) {
          return reply({ ok: false, error: error instanceof Error ? error.message : "Couldn't do that." });
        }
      case "activity-log":
        if (sender.tab) return reply({ ok: false });
        return reply({ log: (await chrome.storage.local.get("activityLog")).activityLog ?? [] });
      // "It missed one": a report of this page for the issues list, so detection can be fixed for this site.
      case "missed-one": {
        if (sender.tab) return reply({ ok: false });
        const tab = Number(message.tabId);
        await look(tab).catch(() => null);
        const page = await send(tab, { type: "page-report" }, 0).catch(() => null);
        const url = (await chrome.tabs.get(tab).catch(() => null))?.url ?? "";
        if (!page) return reply({ ok: false, error: "Couldn't read this page. Reload it and try again." });
        const recent = ((await chrome.storage.local.get("activityLog")).activityLog ?? []).filter((item) => Date.now() - item.at < 30 * 60 * 1e3).slice(0, 5).map((item) => item.text);
        await addIssues(url, [{ kind: "note", what: `Missed an application. Page "${page.title}" (${page.path}). Job read as "${page.job.title}" at "${page.job.company}"${page.postingData ? ", with posting data" : ", no posting data"}. Buttons: ${page.buttons.join(" | ") || "none"}. Headings: ${page.headings.join(" | ") || "none"}. Status line: ${page.status || "none"}${page.dialog ? " (a pop-up is open)" : ""}. Sent after Apply: ${(pressTrace.get(tab) ?? []).join(" | ") || "nothing traced"}. Recent: ${recent.join(" / ") || "nothing seen"}.` }]);
        void log("Saved a report of this page to your issues list (Profile).");
        return reply({ ok: true });
      }
      // Admins: work as Free or Pro (or the real plan) to see what students on it see.
      case "plan-preview": {
        if (sender.tab) return reply({ ok: false });
        try {
          await api("POST", "plan-preview", { plan: message.plan === "free" || message.plan === "pro" ? message.plan : null });
          const { token } = await settings();
          if (token) await readMe(token).catch(() => void 0);
          return reply({ ok: true });
        } catch (error) {
          return reply({ ok: false, error: error instanceof Error ? error.message : "Couldn't switch plans." });
        }
      }
      // "Did you apply to these?": ✓ saves it as applied, ✕ drops it.
      case "maybe-answer": {
        if (sender.tab) return reply({ ok: false });
        try {
          await api("POST", "maybe", { action: "answer", id: message.id, applied: Boolean(message.applied) });
          return reply({ ok: true });
        } catch (error) {
          return reply({ ok: false, error: error instanceof Error ? error.message : "Couldn't save it." });
        }
      }
      // The setup card's answers, saved to the profile.
      case "save-setup":
        if (sender.tab) return reply({ ok: false });
        try {
          return reply({ ok: true, ...await api("POST", "setup", message.answers ?? {}) });
        } catch (error) {
          return reply({ ok: false, error: error instanceof Error ? error.message : "Couldn't save." });
        }
      // "+ Add job" in My jobs.
      case "add-job": {
        if (sender.tab) return reply({ ok: false });
        try {
          const job = message.job ?? {};
          let url = String(job.url ?? "").trim();
          try {
            const address = new URL(url);
            const jobId = LINKEDIN.test(address.hostname) ? address.pathname.match(/\/jobs\/view\/(\d+)/)?.[1] ?? address.searchParams.get("currentJobId") : null;
            if (jobId) url = `https://www.linkedin.com/jobs/view/${jobId}/`;
          } catch {
            url = "";
          }
          await api("POST", "add-job", { title: job.title, company: job.company, url, stage: job.stage, description: typeof job.description === "string" ? job.description : void 0 });
          await dropDetected({ url, title: String(job.title ?? ""), company: String(job.company ?? "") }).catch(() => void 0);
          await readTracker().catch(() => void 0);
          return reply({ ok: true });
        } catch (error) {
          return reply({ ok: false, error: error instanceof Error ? error.message : "Couldn't add it." });
        }
      }
      // The add-a-job form's link: the job's details to fill in the rest.
      case "read-link": {
        if (sender.tab) return reply({ ok: false });
        return reply(await readLink(String(message.url ?? "").trim()));
      }
      // From Unnepo's Applied page (through the page bridge): saved jobs to fill in from their links. Each
      // job board link is read in a background tab, one at a time, and what it showed is sent to Unnepo.
      case "read-links": {
        const { apiBase } = await settings();
        if (!sender.tab?.url || new URL(sender.tab.url).origin !== new URL(apiBase).origin) return reply({ ok: false });
        const list = (Array.isArray(message.jobs) ? message.jobs : []).slice(0, 25);
        const results = [];
        for (const item of list) {
          const id = String(item.id ?? "");
          const info = await readLinkInTab(String(item.url ?? "")).catch(() => null);
          if (!info) {
            results.push({ id, ok: false, error: "Couldn't read the job on that page." });
            continue;
          }
          if (!id) {
            results.push({ id, ok: true, info });
            continue;
          }
          try {
            const saved = await api("POST", "job-info", { applicationId: id, info });
            results.push({ id, ok: true, changed: saved.changed });
          } catch (error) {
            results.push({ id, ok: false, error: error instanceof Error ? error.message : "Couldn't save it." });
          }
        }
        void log(`Read ${results.length} job ${results.length === 1 ? "link" : "links"} for your tracker: ${results.filter((item) => item.changed?.length).length} filled in.`);
        return reply({ ok: true, results });
      }
      // "I applied" in the panel: the job open on this tab (not the results beside it), for the student to check.
      case "read-opened-job": {
        if (sender.tab) return reply({ ok: false });
        const tab = await chrome.tabs.get(Number(message.tabId)).catch(() => null);
        if (!tab?.id || !tab.url || !/^https:/.test(tab.url)) return reply({ ok: false, error: "Open the job's page first." });
        await chrome.scripting.executeScript({ target: { tabId: tab.id, frameIds: [0] }, files: ["content/fill.js"] }).catch(() => void 0);
        const job = await send(tab.id, { type: "opened-job" }, 0).catch(() => null);
        if (!job) return reply({ ok: false, error: "Couldn't read this page. Reload it and try again." });
        const seen = (await seenJobs())[tab.id];
        const posting = seen && sameCompany(seen.company, job.company) && !sameJobPage(seen.url, job.url) ? seen.url : "";
        return reply({ ok: true, job: { ...job, link: posting || job.url } });
      }
      // The student checked the job and saves it: as applied, or for later.
      case "save-opened-job": {
        if (sender.tab) return reply({ ok: false });
        const tabId2 = Number(message.tabId);
        const job = message.job ?? {};
        let title = String(job.title ?? "").trim();
        let company = String(job.company ?? "").trim();
        const link = String(job.link ?? "").trim();
        const url = String(job.url ?? "").trim() || link;
        let description = String(job.description ?? "").trim();
        if (!/^https:\/\/\S+\.\S+/.test(link || url)) return reply({ ok: false, error: "Open the job's page first." });
        const unsure = (name) => name.length < 2 || BOARD_WORD.test(name);
        if ((unsure(company) || title.length < 2 || description.length < 200) && link) {
          let info = null;
          try {
            info = (await api("POST", "read-link", { url: link })).info;
          } catch (error) {
            if (error instanceof ApiError && error.code === "in_browser" && !sameJobPage(link, url)) info = await readLinkInTab(link).catch(() => null);
          }
          if (info) {
            if (unsure(company) && !unsure(info.company)) company = info.company;
            if (title.length < 2) title = info.title;
            if (info.description.length > description.length) description = info.description;
          }
        }
        if (title.length < 2) title = "Job title missing";
        if (unsure(company)) company = new URL(link || url).hostname.replace(/^www\./, "").split(".").slice(-2)[0];
        try {
          if (message.applied) {
            const saved = await saveSubmission({ url, postingUrl: link && link !== url ? link : void 0, title, company, description: description || void 0, confidence: "likely", text: "Marked applied in the Unnepo panel.", how: "you_marked" });
            await saveJob(tabId2, { applicationId: saved.application.id, title: saved.application.title, company: saved.application.company, url, host: new URL(url).hostname, submission: "likely", clickedAt: Date.now(), step: `Added to your Applied jobs: ${saved.application.title}${saved.application.companyMissing ? "" : ` at ${saved.application.company}`}.` });
            void log(`Saved: ${saved.application.title} at ${saved.application.company} (you marked it).`);
            celebrate(tabId2);
            return reply({ ok: true, id: saved.application.id, title: saved.application.title, company: saved.application.company, companyMissing: Boolean(saved.application.companyMissing) });
          }
          const added = await api("POST", "add-job", { title, company, url: link || url, stage: "in_progress", description: description || void 0 });
          void log(`Saved for later: ${title} at ${company}.`);
          return reply({ ok: true, id: added.application.id, title, company, companyMissing: Boolean(added.application.companyMissing) });
        } catch (error) {
          return reply({ ok: false, error: error instanceof Error ? error.message : "Couldn't save it." });
        }
      }
      // A job board's Apply button was pressed (Handshake, ZipRecruiter): the job on the page is the one being
      // applied to. `final`: a button that sends the application itself (1-Click Apply, Submit application).
      case "apply-clicked": {
        if (tabId === void 0) return reply({ ok: false });
        if (!pressedAt.has(tabId) || Date.now() - pressedAt.get(tabId) > 12e4) pressTrace.set(tabId, []);
        pressedAt.set(tabId, Date.now());
        const scan = await look(tabId).catch(() => null);
        if (scan?.title.trim() && scan.company.trim()) {
          const all = await seenJobs();
          const before = all[tabId];
          if (before && !sameJobPage(before.url, scan.url) && !sameCompany(before.company, scan.company)) {
            delete all[tabId];
            await chrome.storage.session.set({ seen: all });
          }
          await rememberSeen(tabId, scan);
          const tracked = (await jobs())[tabId];
          if (tracked?.submission && !sameJobTitle(tracked, scan)) await saveJob(tabId, null);
          const seen = await seenJobs();
          const sends = Boolean(message.final) && sendsApplication(String(message.label ?? ""));
          if (seen[tabId]) {
            seen[tabId].pressed = true;
            if (sends) seen[tabId].sent = true;
            for (const opened of await chrome.tabs.query({}).catch(() => [])) {
              if (opened.id !== void 0 && opened.openerTabId === tabId && !seen[opened.id]) seen[opened.id] = { ...seen[tabId], at: Date.now(), pressed: true };
            }
            await chrome.storage.session.set({ seen });
          }
          const latest = seen[tabId];
          if (latest && sends && !message.elsewhere) await addMaybe({ url: latest.url, title: latest.title, company: latest.company, description: latest.description });
        }
        if (message.final) applyClicks.set(tabId, Date.now());
        void log(`Saw "${String(message.label ?? "Apply").slice(0, 40)}" pressed${scan?.title ? ` on ${scan.title}${scan.company ? ` at ${scan.company}` : ""}` : ""}. Watching for the confirmation.`);
        return reply({ ok: true });
      }
      // The open job's pane shows the board's own "Applied on …" line.
      case "board-applied":
        if (tabId === void 0) return reply({ ok: false });
        void boardApplied(tabId, String(message.text ?? "Applied").slice(0, 120), /^\d{4}-\d{2}-\d{2}$/.test(String(message.day ?? "")) ? String(message.day) : "").catch(() => void 0);
        return reply({ ok: true });
      // A board's applications page and what it lists.
      case "board-list": {
        if (tabId === void 0) return reply({ ok: false });
        const items = (Array.isArray(message.items) ? message.items : []).slice(0, 100).map((item) => ({ title: String(item?.title ?? "").slice(0, 200), company: String(item?.company ?? "").slice(0, 200), url: String(item?.url ?? "").slice(0, 2e3), day: /^\d{4}-\d{2}-\d{2}$/.test(String(item?.day ?? "")) ? String(item.day) : "" })).filter((item) => item.title && item.company && /^https:\/\//.test(item.url));
        const all = await boardLists();
        all[tabId] = { url: String(message.url ?? sender.tab?.url ?? ""), at: Date.now(), items };
        await chrome.storage.session.set({ boardLists: all });
        void chrome.runtime.sendMessage({ type: "state-changed" }).catch(() => void 0);
        return reply({ ok: true });
      }
      // "Bring in": every listed application the tracker doesn't have, as applied on the day the board says.
      case "board-import": {
        if (sender.tab) return reply({ ok: false });
        const list = (await boardLists())[Number(message.tabId)];
        if (!list) return reply({ ok: false, error: "Open the board's applications page again." });
        let added = 0;
        const failed2 = [];
        for (const item of await missingFromBoard(list)) {
          try {
            await saveSubmission({ url: item.url, title: item.title, company: item.company, confidence: "confirmed", text: "On the job board's list of your applications.", how: "board_saved", ...item.day ? { appliedOn: item.day } : {}, noPeople: true });
            added += 1;
          } catch {
            failed2.push(item.title);
          }
        }
        await markBoardHandled(list.items.map((item) => boardKey(item)));
        await readTracker().catch(() => void 0);
        void log(`Brought in ${added} ${added === 1 ? "application" : "applications"} from ${siteName(list.url)}${failed2.length ? `; ${failed2.length} couldn't be saved` : ""}.`);
        void chrome.runtime.sendMessage({ type: "tracker-changed" }).catch(() => void 0);
        return reply({ ok: true, added, failed: failed2.length });
      }
      // The page changed to say so right after an Apply press ("Applied", "Application sent").
      case "applied-detected":
        if (tabId === void 0) return reply({ ok: false });
        void log(`The page changed to "${String(message.text ?? "Applied").slice(0, 60)}" after Apply.`);
        if (sender.tab?.url && QUICK_BOARDS.test(new URL(sender.tab.url).hostname) && APPLIED_LINE.test(String(message.text ?? ""))) {
          void boardApplied(tabId, String(message.text).slice(0, 120), appliedDay(String(message.text))).catch(() => void 0);
          return reply({ ok: true });
        }
        void recordSeen(tabId, String(message.text ?? "The job site shows you applied."), "button_changed").catch(() => void 0);
        return reply({ ok: true });
      case "received-page": {
        if (tabId === void 0) return reply({ ok: false });
        void log(`The page says "${String(message.text ?? "").replace(/\s+/g, " ").trim().slice(0, 60)}".`);
        const job = (await jobs())[tabId];
        const site = (host) => host.split(".").slice(-2).join(".");
        let here = "";
        try {
          here = new URL(String(message.url ?? sender.tab?.url ?? "")).hostname;
        } catch {
        }
        if (job?.submission) celebrate(tabId);
        else if (job?.applicationId && job.host && here && site(here) === site(job.host)) setTimeout(() => void record(tabId, "likely", String(message.text ?? "")), 6e3);
        else setTimeout(() => void recordSeen(tabId, String(message.text ?? "")), 1500);
        return reply({ ok: true });
      }
      case "submitted-page":
        if (tabId === void 0) return reply({ ok: false });
        setTimeout(() => void jobs().then((all) => all[tabId]?.applicationId ? record(tabId, "likely", String(message.text ?? "")) : recordSeen(tabId, String(message.text ?? ""))), 6e3);
        return reply({ ok: true });
      // The tracker, for Home, a job's page and the dashboard. `fresh`: read it again now.
      case "tracker":
        if (!fromExtension(sender)) return reply({ ok: false });
        try {
          return reply({ ok: true, tracker: await tracker(Boolean(message.fresh)) });
        } catch (error) {
          return reply(failed(error, "Couldn't load your jobs."));
        }
      // Friends, and how many each applied to since the start of the student's week.
      case "friends":
        if (!fromExtension(sender)) return reply({ ok: false });
        try {
          return reply({ ok: true, ...await api("GET", `friends?since=${encodeURIComponent(String(message.since ?? ""))}`) });
        } catch (error) {
          return reply(failed(error, "Couldn't load your friends."));
        }
      // Add a friend by email, accept or decline a request, remove a friend.
      case "friend-action":
        if (!fromExtension(sender)) return reply({ ok: false });
        try {
          return reply({ ok: true, ...await api("POST", "friends", message.body ?? {}) });
        } catch (error) {
          return reply(failed(error, "Couldn't do that."));
        }
      // The People card: find, show one more, write an email or follow-up, mark emailed or replied, bounced.
      case "people":
        if (!fromExtension(sender)) return reply({ ok: false });
        try {
          const result = await api("POST", "people", message.body ?? {});
          const body = message.body ?? {};
          if (body.action === "status" && body.contactId) {
            const stored = await chrome.storage.local.get(["followUps", "openedEmails"]);
            const counts = stored.followUps ?? {};
            if (body.status === "emailed" && body.followedUp) counts[body.contactId] = (counts[body.contactId] ?? 0) + 1;
            const opened = stored.openedEmails ?? {};
            delete opened[body.contactId];
            await chrome.storage.local.set({ followUps: counts, openedEmails: opened });
          }
          await readTracker().catch(() => void 0);
          return reply({ ok: true, ...result });
        } catch (error) {
          return reply(failed(error, "Couldn't do that."));
        }
      // A job's status: applied, or what happened after (interviewing, rejected…).
      case "job-status":
        if (!fromExtension(sender)) return reply({ ok: false });
        try {
          await api("POST", "status", typeof message.hidden === "boolean" ? { applicationId: message.applicationId, hidden: message.hidden } : typeof message.reachedOut === "number" ? { applicationId: message.applicationId, reachedOut: message.reachedOut } : { applicationId: message.applicationId, applied: message.applied === true, outcome: message.outcome ?? null });
          await readTracker().catch(() => void 0);
          return reply({ ok: true });
        } catch (error) {
          return reply(failed(error, "Couldn't change it."));
        }
      // "Edit job info": the job's title, company and posting link.
      case "edit-job":
        if (!fromExtension(sender)) return reply({ ok: false });
        try {
          await api("POST", "edit-job", { applicationId: message.applicationId, title: message.title, company: message.company, url: message.url });
          await readTracker().catch(() => void 0);
          return reply({ ok: true });
        } catch (error) {
          return reply(failed(error, "Couldn't save it."));
        }
      case "delete-job":
        if (!fromExtension(sender)) return reply({ ok: false });
        try {
          await api("DELETE", "applications", { applicationId: message.applicationId });
          await readTracker().catch(() => void 0);
          return reply({ ok: true });
        } catch (error) {
          return reply(failed(error, "Couldn't delete it."));
        }
      // An email link was opened: Home asks an hour later whether it was sent.
      case "email-opened": {
        if (!fromExtension(sender)) return reply({ ok: false });
        const opened = (await chrome.storage.local.get("openedEmails")).openedEmails ?? {};
        opened[String(message.contactId)] = { at: Date.now(), applicationId: String(message.applicationId), name: String(message.name ?? ""), company: String(message.company ?? ""), followUp: message.followUp === true };
        await chrome.storage.local.set({ openedEmails: opened });
        return reply({ ok: true });
      }
      // Snooze (until a time) or done, for one reminder; "Not yet" on "Did you send it?" forgets the opened link.
      case "reminder-mark": {
        if (!fromExtension(sender)) return reply({ ok: false });
        const stored = await chrome.storage.local.get(["reminderMarks", "openedEmails"]);
        const marks = stored.reminderMarks ?? {};
        const key = String(message.key ?? "");
        if (key.startsWith("sent:")) {
          const opened = stored.openedEmails ?? {};
          delete opened[key.split(":")[1]];
          await chrome.storage.local.set({ openedEmails: opened });
        } else if (key) {
          marks[key] = message.until ? { until: Number(message.until) } : { done: true };
          await chrome.storage.local.set({ reminderMarks: Object.fromEntries(Object.entries(marks).slice(-300)) });
        }
        void updateBadge();
        return reply({ ok: true });
      }
      case "detected-list":
        if (!fromExtension(sender)) return reply({ ok: false });
        return reply({ ok: true, list: await detectedList() });
      // ✓ or ✗ on a detected job. ✓ saves it as applied; one with no company asks the student to add it by hand.
      case "detected-answer": {
        if (!fromExtension(sender)) return reply({ ok: false });
        const list = await detectedList();
        const item = list.find((entry) => entry.id === message.id);
        if (!item) return reply({ ok: false, error: "That job isn't on the list any more." });
        if (!message.applied) {
          item.state = "no";
          await saveDetectedList(list);
          return reply({ ok: true });
        }
        try {
          if (item.applicationId) await api("POST", "status", { applicationId: item.applicationId, applied: true });
          else if (item.title.trim() && item.company.trim()) {
            const saved = await saveSubmission({ url: item.url, title: item.title, company: item.company, description: item.description, poster: item.poster, confidence: "likely", text: "You said you applied.", how: "you_marked" });
            item.applicationId = saved.application.id;
          } else return reply({ ok: false, needsForm: true, error: "Unnepo didn't catch the company. Add it with + Add a job." });
          await saveDetectedList(list.filter((entry) => entry.id !== item.id));
          await readTracker().catch(() => void 0);
          return reply({ ok: true });
        } catch (error) {
          item.error = error instanceof Error ? error.message : "Couldn't save it.";
          await saveDetectedList(list);
          return reply(failed(error, "Couldn't save it."));
        }
      }
      // Undo on a job saved by itself (or a ✓): back to not applied, and it asks again.
      // "Clear list": empties the Detected jobs menu. Saved jobs stay in the tracker.
      case "detected-clear":
        if (!fromExtension(sender)) return reply({ ok: false });
        await saveDetectedList([]);
        return reply({ ok: true });
      case "detected-undo": {
        if (!fromExtension(sender)) return reply({ ok: false });
        const list = await detectedList();
        const item = list.find((entry) => entry.id === message.id);
        if (!item) return reply({ ok: false, error: "That job isn't on the list any more." });
        try {
          if (item.applicationId) await api("POST", "submissions/undo", { applicationId: item.applicationId });
          item.state = "undone";
          await saveDetectedList(list);
          await readTracker().catch(() => void 0);
          return reply({ ok: true });
        } catch (error) {
          return reply(failed(error, "Couldn't undo it."));
        }
      }
      case "refresh-badge":
        void updateBadge();
        return reply({ ok: true });
      default:
        return reply({ ok: false });
    }
  })();
  return true;
});
chrome.runtime.onInstalled.addListener(() => void jobSitePassword());
chrome.tabs.onRemoved.addListener((tabId) => {
  runs.delete(tabId);
  applyClicks.delete(tabId);
  formFrame.delete(tabId);
  void saveApplying(tabId, null);
  void tabGone(tabId);
});
void jobs().then(async (all) => {
  for (const [tabId, job] of Object.entries(all)) if (job.running) await saveJob(Number(tabId), { running: false });
});
chrome.tabs.onUpdated.addListener((tabId, info, tab) => {
  if (info.status !== "complete" || !tab.url) return;
  void applyingAll().then((all) => {
    const before = all[tabId];
    if (!before) return;
    const site = (url) => {
      try {
        return new URL(url).hostname.split(".").slice(-2).join(".");
      } catch {
        return "";
      }
    };
    if (site(before.url) !== site(tab.url)) return void saveApplying(tabId, null);
    void beginApplying(tabId).catch(() => void 0);
  });
});
chrome.tabs.onActivated.addListener(() => void chrome.runtime.sendMessage({ type: "state-changed" }).catch(() => void 0));
var panelWindows = /* @__PURE__ */ new Set();
async function tellLaunchers(windowId) {
  const tabs = await chrome.tabs.query({ windowId }).catch(() => []);
  for (const tab of tabs) if (tab.id !== void 0) void chrome.tabs.sendMessage(tab.id, { type: "panel", open: panelWindows.has(windowId) }).catch(() => void 0);
}
chrome.runtime.onConnect.addListener((port) => {
  const windowId = Number(port.name.match(/^panel:(\d+)$/)?.[1]);
  if (!Number.isInteger(windowId)) return;
  panelWindows.add(windowId);
  void tellLaunchers(windowId);
  port.onDisconnect.addListener(() => {
    panelWindows.delete(windowId);
    void tellLaunchers(windowId);
  });
});
void chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => void 0);
