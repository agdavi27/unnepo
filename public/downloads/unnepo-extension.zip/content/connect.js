"use strict";
(() => {
  // extension/src/content/connect.ts
  window.addEventListener("message", (event) => {
    if (event.source !== window || event.origin !== window.location.origin) return;
    const data = event.data;
    try {
      if (data?.type === "unnepo:extension-token" && typeof data.token === "string" && data.token.startsWith("unx_")) {
        void chrome.runtime.sendMessage({ type: "connect", token: data.token, origin: window.location.origin }).catch(() => void 0);
      } else if (data?.type === "unnepo:ping") {
        window.postMessage({ type: "unnepo:pong" }, window.location.origin);
      } else if (data?.type === "unnepo:read-links" && Array.isArray(data.jobs)) {
        const requestId = String(data.requestId ?? "");
        void chrome.runtime.sendMessage({ type: "read-links", jobs: data.jobs }).then(
          (answer) => window.postMessage({ type: "unnepo:read-links-done", requestId, results: answer?.results ?? [] }, window.location.origin),
          () => window.postMessage({ type: "unnepo:read-links-done", requestId, results: [], error: "The extension didn't answer." }, window.location.origin)
        );
      }
    } catch {
    }
  });
})();
