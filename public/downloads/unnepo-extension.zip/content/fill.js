"use strict";
(() => {
  // extension/src/shared/types.ts
  var CONFIRM_TEXT = /(thank(s| you) for (applying|your application|your interest|submitting)|application (has been |was )?(successfully )?(submitted|received|sent)|we(?:'|’)?ve received your application|successfully (submitted|applied)|your application is (in|complete))/i;

  // lib/apply/options.ts
  var OPTION_ALIASES = {
    "united states": ["united states of america", "usa", "us", "u.s", "u.s.a"],
    "united states of america": ["united states", "usa", "us"],
    "usa": ["united states of america", "united states"],
    "us": ["united states of america", "united states"],
    "united kingdom": ["uk", "great britain", "united kingdom of great britain and northern ireland"],
    "uk": ["united kingdom", "great britain"]
  };
  var normal = (text2) => text2.replace(/\u00a0/g, " ").replace(/[‘’`]/g, "'").replace(/[*✱]/g, "").replace(/\s+/g, " ").trim().replace(/[.:;!,]+$/, "").trim().toLowerCase();
  var bare = (text2) => normal(text2.replace(/\s*[([][^)\]]*[)\]]/g, " ").replace(/\s*\+\d{1,4}\s*$/, "").replace(/^\+\d{1,4}\s+/, ""));
  var words = (text2) => normal(text2).split(/[^a-z0-9']+/).filter(Boolean);
  function only(options2, lower, test) {
    const hits = lower.flatMap((option, index) => test(option) ? [index] : []);
    return hits.length === 1 ? options2[hits[0]] : null;
  }
  function bestOption(answer, options2) {
    const want = normal(answer);
    if (!want) return null;
    const lower = options2.map(normal);
    const exact = lower.indexOf(want);
    if (exact >= 0) return options2[exact];
    const bareOptions = options2.map(bare);
    const bareWant = bare(answer) || want;
    const sameBare = only(options2, bareOptions, (option) => option === bareWant);
    if (sameBare) return sameBare;
    for (const alias of OPTION_ALIASES[bareWant] ?? []) {
      const index = bareOptions.findIndex((option) => option === alias);
      if (index >= 0) return options2[index];
      const starts2 = alias.length < 5 ? -1 : lower.findIndex((option) => option.startsWith(`${alias} `) || option.startsWith(`${alias}(`));
      if (starts2 >= 0) return options2[starts2];
    }
    const asWord = new RegExp(`^${want.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}(?![a-z0-9])`);
    const wordStarts = lower.filter((option) => asWord.test(option));
    if (wordStarts.length === 1) return options2[lower.indexOf(wordStarts[0])];
    if (wordStarts.length > 1 || want.length < 4) return null;
    const starts = lower.filter((option) => option.startsWith(want));
    if (starts.length === 1) return options2[lower.indexOf(starts[0])];
    if (starts.length > 1) return null;
    const contains = lower.filter((option) => option.includes(want));
    if (contains.length === 1) return options2[lower.indexOf(contains[0])];
    if (contains.length > 1) return null;
    const wanted = words(answer);
    if (wanted.length < 2) return null;
    return only(options2, options2, (option) => {
      const have = new Set(words(option));
      return wanted.every((word) => have.has(word));
    });
  }
  var DEGREE_NAMES = [
    // Graduate degrees first: "M.B.A." also contains "B.A.".
    [/\b(m\.?\s?b\.?\s?a\b|mba\b)/i, ["Master of Business Administration (M.B.A.)", "MBA", "Master of Business Administration", "Master's Degree", "Masters"]],
    [/\b(ph\.?\s?d|doctor)/i, ["Doctor of Philosophy (Ph.D.)", "Doctorate", "PhD", "Doctoral Degree"]],
    [/\b(m\.?\s?a\b\.?|m\.?\s?s\b\.?|m\.?\s?sc|master)/i, ["Master's Degree", "Master's", "Masters", "Master"]],
    [/\b(b\.?\s?a\b\.?|b\.?\s?s\b\.?|b\.?\s?sc|bachelor)/i, ["Bachelor's Degree", "Bachelor's", "Bachelors", "Bachelor", "Bachelor of Arts", "Bachelor of Science", "BA", "BS", "Undergraduate"]],
    [/\bassociate/i, ["Associate's Degree", "Associate Degree", "Associates"]],
    [/high school|diploma|ged/i, ["High School Diploma", "High School", "GED"]]
  ];
  function degreeAnswer(degree, options2) {
    if (!options2.length) return degree || null;
    const exact = options2.find((option) => option.trim().toLowerCase() === degree.trim().toLowerCase());
    if (exact) return exact;
    const names = DEGREE_NAMES.find(([pattern]) => pattern.test(degree))?.[1] ?? [];
    for (const name of names) {
      const match = bestOption(name, options2);
      if (match) return match;
    }
    return null;
  }

  // lib/apply/questions.ts
  var SENSITIVE = /\b(gender|sex|pronouns?|race|racial|ethnic|ethnicity|hispanic|latin[oax]|veteran|military|disabilit|sexual orientation|transgender|lgbt|age|date of birth|birth ?date|criminal|convict|felony|arrest|salary|compensation|pay expectations?|desired pay|visa|sponsor|sponsorship|authori[sz]ed to work|work authori[sz]ation|right to work|citizen|citizenship|social security|ssn|religio|marital|national origin|background check|drug test|entitled to work|eligible to work|legally|attest|attestation|acknowledge?|acknowledgement|privacy (?:policy|notice)|consent|certify|non-compete|non-solicitation|agree)\b/i;
  var STANDARD = [
    [/^(legal )?first name\b|^given name/i, "firstName"],
    [/^(legal )?last name\b|^surname|^family name/i, "lastName"],
    [/^preferred (first )?name\b|^nickname/i, "firstName"],
    [/^(full |legal )?name\b(?!.*(company|school|employer|reference|university))/i, "fullName"],
    [/currently (a )?(student|enrolled)|are you (a )?(current|currently enrolled) (student|undergraduate)|currently attending/i, "currentStudent"],
    [/\be-?mail\b/i, "email"],
    [/^(address line 1|street address|address 1|address|street)$/i, "addressLine1"],
    [/^(state|province|state\/province|state or province|region)$/i, "state"],
    [/^(postal code|zip|zip code|zip\/postal code|postcode)$/i, "postalCode"],
    // "Phone Country Code" is a dropdown of countries with dialing codes ("United States of America (+1)").
    [/^(phone )?country (phone )?(dialing )?code$|^phone country( code)?$|^country code$|^(phone|dialing) code$/i, "phoneCountry"],
    [/^(country|country\/territory|country\/region)$/i, "country"],
    // "Which country do you currently reside in?", "Country of residence". Never citizenship, which stays the student's.
    [/^(?!.*citizen)((which|what) country\b.*\b(reside|live|located|based|residence|currently in)\b|country (of|where you) (residence|reside|live|currently reside)|(current )?country of residence|residence country|home country)/i, "country"],
    // Workday asks what kind of phone the number is before the number itself.
    [/\b(phone|device) (device )?type\b|type of (phone|device)|phone number type/i, "phoneType"],
    [/\b(phone )?extension\b|^ext\.?$/i, "phoneExtension"],
    [/\b(phone|mobile|cell)\b/i, "phone"],
    [/how did you (hear|find out|learn) (about|of)|where did you (hear|find|see)|(referral|application|candidate|lead) source|^source$/i, "hearAbout"],
    [/linkedin/i, "linkedin"],
    [/github/i, "github"],
    [/\b(website|portfolio|personal site|blog)\b/i, "website"],
    [/^(current )?(city|location)\b|where are you (currently )?(based|located)/i, "city"],
    // "What year are you in school?", "Class standing", "Current year of study". Before school, which these mention.
    [/\b(class (year|standing|level|status)|academic (year|standing|level|class)|year (in|of) (school|college|university|study|studies)|current (academic |school )?year|what year are you|grade level|(student|enrollment) (level|year|standing))\b/i, "classYear"],
    [/\b(school|university|college|institution)\b(?!.*(year|date|gpa))/i, "school"],
    [/\b(major|discipline|field of study|area of study|concentration)\b/i, "major"],
    [/\b(graduation|grad) (year|date)\b|expected graduation|when do you graduate/i, "graduationYear"],
    [/\b(resume|cv)\b/i, "resume"],
    [/cover letter/i, "coverLetter"]
  ];
  function classifyQuestion(label) {
    const text2 = label.trim().replace(/[\s*:]+$/, "").trim();
    const field = STANDARD.find(([pattern]) => pattern.test(text2))?.[1] ?? null;
    const sensitive = field && field !== "city" ? false : SENSITIVE.test(text2);
    return { sensitive, field: sensitive ? null : field };
  }
  var SAME_WORDS = [
    ["salary", "compensation", "pay", "wage", "wages", "rate"],
    ["expect", "expectation", "expectations", "expected", "desired", "desire", "target", "requirement", "requirements", "range"],
    ["start", "begin", "beginning", "available", "availability", "earliest"],
    ["relocate", "relocation", "relocating", "move", "moving"],
    ["office", "onsite", "on-site", "in-person", "person", "hybrid"],
    ["sponsorship", "sponsor", "visa"],
    ["authorized", "authorization", "eligible", "eligibility", "legally", "permitted"],
    ["hear", "heard", "learn", "find", "found", "source", "referred"],
    ["portfolio", "website", "site"],
    ["graduate", "graduation", "grad"],
    ["school", "university", "college"]
  ];
  var SAME_WORD = new Map(SAME_WORDS.flatMap((group) => group.map((word) => [word, group[0]])));
  var DECLINE = /(decline|prefer not|don['’]?t wish|do not wish|not to (say|answer|disclose|self-identify)|choose not|rather not|i don['’]?t want to answer)/i;
  var SAME_ANSWER = {
    mobile: ["Cell", "Cell Phone", "Mobile Phone", "Cellular", "Personal Mobile"],
    freshman: ["First year", "1st year", "Year 1", "First-year"],
    sophomore: ["Second year", "2nd year", "Year 2"],
    junior: ["Third year", "3rd year", "Year 3"],
    senior: ["Fourth year", "4th year", "Year 4"],
    "graduate student": ["Graduate", "Masters", "Master's student", "Graduate Student"],
    "company website": ["Company Careers Site", "Company Career Site", "Careers Site", "Career Site", "Careers Page", "Career Website", "Corporate Website", "Website", "Company Web Site", "Job Board", "Online Job Board", "Internet", "Online", "Other"]
  };
  function answerChoices(answer) {
    return [answer, ...SAME_ANSWER[answer.toLowerCase()] ?? []];
  }
  var WRITING_STYLE = `How written answers sound:
- Like the student typed it themselves: first person, plain everyday words, specific. A sharp college student, not a cover letter template or a press release.
- Start with something concrete they did (a job, a class project, a club, a result), then tie it to one specific thing about this company or role from the posting. Name real things; skip general praise.
- Mix short and longer sentences. Contractions are fine. One idea per sentence.
- Never use em dashes or en dashes. Use commas or periods.
- Never use these words or phrases: excited, thrilled, eager, passionate, passion, leverage, align, aligns, dynamic, fast-paced, furthermore, moreover, additionally, in today's, unique opportunity, meaningful impact, honed, foster, delve, testament, invaluable, synergy, cutting-edge, journey, landscape, I believe, I am confident, resonate, deeply, truly, seamless, robust, showcase, spearhead, utilize.
- Don't restate the question, don't open with "As a ...", and don't end with a summary or a thank-you line. No lists or headings.
- Length: if the question states one (words or characters), meet it: a bit over a minimum, under a maximum. Otherwise at most 2 sentences, about 20 to 45 words.`;
  var AI_ANSWER_PROMPT = `You help a college student fill out a job application. You get the open form questions and the student's own profile and resume.
For each question, answer only if the profile or resume directly supports the answer. Quote the exact supporting words from the profile or resume in "evidence", copied character for character.
Rules:
- Never invent experience, dates, numbers, skills, schools, or employers.
- Never answer questions about gender, race, ethnicity, veteran or disability status, age, citizenship, visa sponsorship, work authorization, salary, or criminal history. Skip them.
- For questions with options, the answer must be exactly one of the options.
- For essay questions, use only facts from the profile or resume plus what the job posting says, and quote the main resume fact you used as evidence.
- If you can't support an answer, leave that question out.
${WRITING_STYLE}
Return only JSON: {"answers":[{"key":"...","answer":"...","evidence":"..."}]}`;

  // lib/apply/job-title.ts
  var MONTH = "(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\\.?";
  var WHEN = `( on .+| \\d+ ?(m|min|minutes?|h|hours?|d|days?|w|weeks?|months?) ago| today| yesterday| just now| ${MONTH} \\d{1,2}.*| \\d{1,2}/\\d{1,2}.*)`;
  var STATUS = new RegExp(
    `^([\u2713\u2714\u2611]\\s*)?(applied${WHEN}?[.!]?|you(?:'|\u2019| ha)ve applied.*|you applied.*|already applied.*|application (sent|submitted|received|complete|completed|viewed|in progress)\\b.*|your application (was |has been )?(sent|submitted|received).*|(saved|viewed|submitted|withdrawn|archived|not interested)${WHEN}?|(posted|updated|reposted|closes|closing|deadline)\\b.*|no longer accepting.*|this job (has )?(expired|closed).*|(apply|applying) (to|for|at) .+|(details|questions|documents|attachments|information|info) (from|for) .+)$`,
    "i"
  );
  var DATE_ONLY = new RegExp(`^${MONTH} \\d{1,2}(, \\d{4})?$`, "i");
  var PAGE_NAME = /^(jobs?|job search|search( jobs| results)?|find (a )?jobs?|browse jobs|all jobs|saved jobs|recommended( jobs)?|jobs for you|job (postings?|board|listings?)|postings?|listings?|careers?|career (center|centre|services)|home|explore|discover|internships?( and jobs)?|opportunities|open (roles|positions)|positions|(my )?applications|messages|inbox|events|employers|companies|dashboard|feed|notifications|profile)$/i;
  var SITE_MENU = /^(\d+\+? (new |unread )?(notifications?|messages?|alerts?)|(new |unread )?(notifications?|messages?) \(\d+\)|my network|messaging|me|for business|try premium.*|skip to (main )?content|home|jobs home)$/i;
  var SITE_TALK = /\b(your feedback|feedback helps|give feedback|share (your )?feedback|are these (results|jobs) (helpful|relevant)|(was|is) this (page |job |result )?(helpful|relevant)|rate (this|your)|take (our|a|the) survey|how (are|did) we do|sign in to|log in to|join (now )?to (see|view|apply)|create (an|your) account|something went wrong|page (not found|unavailable)|access denied|verify (you are|you're) (a )?human|no longer available|we use cookies|accept (all )?cookies|showing \d+|\d+[,\d]* (results|jobs|openings)|results? for\b|jobs? (you may|you might|based on|recommended)|similar jobs|people also viewed|try premium|premium members)\b/i;
  var SITE_PROMO = /(\bstay (on top of|up to date|in the loop)\b|\bjob alerts?\b|\b(set|create|turn on|get|manage) (an? |your |job )?alerts?\b|\bget notified\b|\bnotify me\b|\bnew (job )?openings\b|\bnever miss\b|©|\(c\) \d{4}|\bcopyright\b|\ball rights reserved\b|\bcorporation\b.*\d{3}|\b(user agreement|privacy policy|cookie policy|copyright policy|community guidelines|about accessibility|brand policy|guest controls)\b|\bopen to work\b|\bupdate your (profile|preferences)\b)/i;
  var SENTENCE_START = /^(are|is|was|were|do|does|did|can|could|would|should|will|have|has|how|what|why|when|where|who|which|we|we're|we've|you|you're|your|our|this|these|that|please|thanks|thank you|sorry|oops|welcome|hi|hello|looking for|want to|ready to|don't|didn't)\b/i;
  function siteSentence(line) {
    const words2 = line.split(" ").length;
    if (SITE_TALK.test(line) || SITE_PROMO.test(line)) return true;
    if (/\?/.test(line)) return true;
    if (/[.!…]\s+\S/.test(line) || /\.\.\.$|…$/.test(line) && words2 > 4) return true;
    if (SENTENCE_START.test(line) && words2 >= 3) return true;
    return words2 > 16;
  }
  function notJobTitle(text2) {
    const line = text2.replace(/\s+/g, " ").trim();
    return line.length < 2 || line.length > 150 || STATUS.test(line) || DATE_ONLY.test(line) || PAGE_NAME.test(line) || SITE_MENU.test(line) || siteSentence(line);
  }
  var COMPANY_BEFORE = [
    /^(see|view|browse|explore|find|show|discover|check out)( all| more| other| open)? (jobs|openings|roles|positions|careers|opportunities|internships)( at| from| with| by)\s+/i,
    /^(more|other|all|open|similar)? ?(jobs|openings|roles|positions|careers|opportunities|internships) (at|from|with|by)\s+/i,
    /^(learn more about|more about|about|visit|follow|following|followed|work at|working at|life at|careers at|go to|company:|employer:|posted by|hiring company:?)\s+/i,
    /^(company |employer )?(logo|image|avatar|picture)( of| for)?\s+/i,
    // An apply pop-up's headings: "Details from Runway Services", "Apply to Runway Services".
    /^(details|questions|documents|attachments|information|info) from\s+/i,
    /^(apply|applying) (to|at)\s+/i
  ];
  var COMPANY_AFTER = [
    /\s*[·|•–—-]\s*(follow|following|view profile|\d[\d.,]*\s*(reviews?|followers?|employees|ratings?|jobs?)).*$/i,
    /\s*\d(\.\d)?\s*(★|☆|stars?|out of 5).*$/i,
    /\s*\(opens in a new (tab|window)\)$/i,
    /['’]s\s+(logo|jobs|careers|profile|page)$/i,
    /\s+(jobs|careers|careers page|job openings|openings|company profile|profile|reviews|logo|page)$/i,
    /\s+(is hiring|hiring now|is now hiring|now hiring)$/i,
    /\s*[→›»>]+$/
  ];
  function cleanCompanyName(raw) {
    let name = raw.replace(/\s+/g, " ").trim();
    for (let round = 0; round < 4; round += 1) {
      const before = name;
      for (const pattern of [...COMPANY_BEFORE, ...COMPANY_AFTER]) name = name.replace(pattern, "").trim();
      name = name.replace(/^[\s:,.–—-]+|[\s:,–—-]+$/g, "").trim();
      if (name === before) break;
    }
    return name;
  }
  function companyFromApplyHeading(text2) {
    return text2.replace(/\s+/g, " ").trim().match(/^(?:apply|applying) (?:to|at) (.{2,80})$/i)?.[1].trim() ?? "";
  }

  // extension/src/content/quick-apply.ts
  var QUICK_BOARDS = /(^|\.)((joinhandshake|linkedin|ziprecruiter|indeed|simplyhired|wellfound|glassdoor|dice|builtin|monster|careerbuilder|wayup)\.com|simplify\.jobs|idealist\.org|usajobs\.gov)$/;

  // extension/src/content/scan.ts
  var clean = (text2) => (text2 ?? "").replace(/\s+/g, " ").replace(/\b(select one|required)\b/gi, "").replace(/[*✱]/g, "").trim();
  var machine = (text2) => !/\s/.test(text2) && /[[\]_]/.test(text2);
  var FORMAT_ONLY = /^(mm\/yyyy|mm\/dd\/yyyy|dd\/mm\/yyyy|yyyy|mm|month|year|select|search|choose|type to search|start typing)$/i;
  var PAGE_AREA = "nav, header, footer, [role=navigation], [role=banner], [role=contentinfo], [data-automation-id*='utility' i], [data-automation-id*='languagePicker' i], [data-automation-id*='locale' i]";
  var LANGUAGE_SWITCH = /^(english|español|espanol|français|francais|deutsch|italiano|português|portugues|nederlands|polski|svenska|dansk|norsk|suomi|čeština|magyar|română|türkçe|ελληνικά|русский|українська|日本語|中文|简体中文|繁體中文|한국어|العربية|עברית|हिन्दी|ไทย|tiếng việt|bahasa indonesia)(\s*[(-].*)?$/i;
  function pageControl(el, label, dropdown) {
    const area = el.closest(PAGE_AREA);
    return Boolean(area && !area.closest("form")) || dropdown && LANGUAGE_SWITCH.test(label.trim());
  }
  var CONTROLS = "input:not([type=hidden]), select, textarea, button[aria-haspopup='listbox'], [role=combobox]:not(input), [aria-haspopup=listbox]:not(input):not(button)";
  function boxDropdown(el) {
    if (el.matches("input, select, textarea")) return false;
    if (el.matches("button")) return el.getAttribute("role") === "combobox";
    if (!el.matches("[role=combobox], [aria-haspopup=listbox]")) return false;
    return !el.querySelector("input:not([type=hidden]), select, textarea, button[aria-haspopup='listbox'], [role=combobox]");
  }
  function deepAll(selector, root = document) {
    const found = Array.from(root.querySelectorAll(selector));
    for (const el of Array.from(root.querySelectorAll("*"))) if (el.shadowRoot) found.push(...deepAll(selector, el.shadowRoot));
    return found;
  }
  var rootOf = (el) => el.getRootNode();
  var parentOf = (el) => el.parentElement ?? (el.getRootNode().host ?? null);
  var findMarked = (id) => deepAll(`[data-unnepo-id="${id}"]`)[0] ?? null;
  function byIds(ids, root = document) {
    return ids.split(/\s+/).map((id) => root.getElementById(id)?.textContent ?? "").join(" ");
  }
  function optionTexts(node) {
    const parts = [];
    node.querySelectorAll("option, [role=option]").forEach((option) => parts.push(option.textContent ?? ""));
    node.querySelectorAll("input[type=radio], input[type=checkbox]").forEach((input) => parts.push(labelOf(input)));
    return parts.map(clean).filter(Boolean);
  }
  function ownText(node) {
    let text2 = clean(node.innerText);
    for (const part of optionTexts(node)) if (part) text2 = text2.split(part).join(" ");
    return clean(text2);
  }
  function labelOf(input) {
    const byFor = input.id ? rootOf(input).querySelector(`label[for="${CSS.escape(input.id)}"]`) : null;
    return clean(byFor?.textContent || input.closest("label")?.textContent || input.getAttribute("aria-label") || input.value);
  }
  function groupQuestion(el) {
    let group = el.closest("[role=radiogroup], fieldset, [role=group]");
    if (group?.querySelector("input:not([type=radio]):not([type=checkbox]):not([type=hidden]), textarea, select")) group = null;
    const named = group && (clean(group.querySelector("legend")?.textContent) || (group.getAttribute("aria-labelledby") ? clean(byIds(group.getAttribute("aria-labelledby"), rootOf(el))) : "") || clean(group.getAttribute("aria-label")));
    if (named) return named.slice(0, 300);
    const members = el.name ? Array.from(rootOf(el).querySelectorAll(`input[name="${CSS.escape(el.name)}"]`)) : [el];
    let node = el.parentElement;
    for (let depth = 0; node && node !== document.body && depth < 8; depth += 1, node = node.parentElement) {
      if (!members.every((member) => node.contains(member))) continue;
      if (node.querySelectorAll(CONTROLS).length > members.length + 3) break;
      const text2 = ownText(node);
      if (text2.length >= 3) return text2.slice(0, 300);
    }
    return "";
  }
  function questionText(el) {
    const type = (el.getAttribute("type") ?? "").toLowerCase();
    if (type === "radio" || type === "checkbox") {
      const asked = groupQuestion(el);
      if (asked && (type === "radio" || el.closest("fieldset, [role=group]"))) return asked;
    }
    const labelledBy = el.getAttribute("aria-labelledby");
    const direct = [
      el.id ? rootOf(el).querySelector(`label[for="${CSS.escape(el.id)}"]`)?.textContent : "",
      labelledBy ? byIds(labelledBy, rootOf(el)) : "",
      el.closest("[data-automation-id^='formField']")?.querySelector("label")?.textContent,
      type === "checkbox" ? "" : el.closest("label")?.textContent,
      el.getAttribute("aria-label"),
      el.closest("fieldset")?.querySelector("legend")?.textContent
    ].map(clean).find((text2) => text2 && text2.length > 1 && !machine(text2));
    if (direct && !FORMAT_ONLY.test(direct)) return direct.slice(0, 300);
    let node = parentOf(el);
    for (let depth = 0; node && node !== document.body && depth < 6; depth += 1, node = parentOf(node)) {
      if (node.querySelectorAll(CONTROLS).length > 6) break;
      const text2 = ownText(node);
      if (text2.length >= 3 && !FORMAT_ONLY.test(text2)) return (direct ? `${text2} (${direct})` : text2).slice(0, 300);
    }
    if (type === "checkbox") {
      const own = labelOf(el);
      if (own) return own;
    }
    return direct || clean(el.getAttribute("placeholder")) || clean((el.getAttribute("name") ?? "").replace(/[[\]_.]+/g, " "));
  }
  var HEADING = "h1, h2, h3, h4, h5, [role=heading], [data-automation-id*='Header' i]";
  function sectionOf(el) {
    let node = el;
    for (let depth = 0; node && node !== document.body && depth < 12; depth += 1, node = parentOf(node)) {
      let sibling = node.previousElementSibling;
      for (let hops = 0; sibling && hops < 25; hops += 1, sibling = sibling.previousElementSibling) {
        const found = sibling.matches(HEADING) ? sibling : Array.from(sibling.querySelectorAll(HEADING)).pop();
        const text2 = clean(found?.textContent);
        if (text2 && text2.length < 90) return text2;
      }
    }
    return "";
  }
  var BLANK = /^(select( one)?(\.{1,3}|…)?|choose( one)?(\.{1,3}|…)?|please select|--.*|)$/i;
  function isEmpty(el) {
    const type = (el.getAttribute("type") ?? "").toLowerCase();
    if (el.tagName === "BUTTON" || boxDropdown(el)) return BLANK.test(clean(el.innerText));
    if (el instanceof HTMLSelectElement) return !el.value || BLANK.test(clean(el.selectedOptions[0]?.textContent));
    if (el.getAttribute("role") === "combobox") {
      let node = el.parentElement;
      for (let depth = 0; node && depth < 5; depth += 1, node = node.parentElement) {
        if (node.querySelector("[class*='single-value'], [class*='multi-value'], [data-automation-id='selectedItem']")) return false;
        if (node.querySelectorAll("[role=combobox]").length > 1) break;
      }
    }
    if (el instanceof HTMLInputElement || el instanceof HTMLTextAreaElement) {
      if (type === "checkbox") {
        const group = el.closest("fieldset, [role=group]");
        if (group && group.querySelectorAll("input[type=checkbox]").length > 1) return !group.querySelector("input[type=checkbox]:checked");
        return !el.checked;
      }
      if (type === "radio") return !rootOf(el).querySelector(`input[type=radio][name="${CSS.escape(el.name)}"]:checked`);
      if (type === "file") return !el.files?.length && !/[\w)\]-]\.(pdf|docx?|txt|rtf)\b/i.test(el.closest("div")?.parentElement?.textContent ?? "");
      return !el.value.trim();
    }
    return false;
  }
  function visible(el) {
    const style = window.getComputedStyle(el);
    const rect = el.getBoundingClientRect();
    return style.display !== "none" && style.visibility !== "hidden" && (rect.width > 0 || rect.height > 0);
  }
  var counter = 0;
  function mark(el) {
    if (!el.getAttribute("data-unnepo-id")) el.setAttribute("data-unnepo-id", `u${++counter}`);
    return el.getAttribute("data-unnepo-id");
  }
  function openDialog() {
    return deepAll("[role=dialog], [role=alertdialog], [aria-modal='true'], dialog[open]").filter((dialog) => visible(dialog) && dialog.getBoundingClientRect().height > 40).filter((dialog) => Array.from(dialog.querySelectorAll("input:not([type=hidden]), select, textarea")).some((el) => visible(el) && el.getBoundingClientRect().width >= 4)).pop() ?? null;
  }
  function dateSegment(el) {
    const words2 = `${el.getAttribute("data-automation-id") ?? ""} ${el.id}`;
    const named = words2.match(/dateSection(Month|Day|Year)/i)?.[1] ?? (el.getAttribute("role") === "spinbutton" ? el.getAttribute("aria-label")?.match(/^(month|day|year)$/i)?.[1] : null);
    return named ? named[0].toUpperCase() + named.slice(1).toLowerCase() : null;
  }
  var SEGMENT_FORMAT = { Month: "MM", Day: "DD", Year: "YYYY" };
  function scanFields() {
    const out = [];
    const seenGroups = /* @__PURE__ */ new Set();
    const dialog = openDialog();
    const controls = deepAll("input, select, textarea, button[aria-haspopup='listbox'], [role=combobox]:not(input), [aria-haspopup=listbox]:not(input):not(button)", dialog ?? document);
    for (const el of controls) {
      const type = (el.getAttribute("type") ?? (el.tagName === "TEXTAREA" ? "textarea" : el.tagName === "SELECT" ? "select" : "text")).toLowerCase();
      const dropdownButton = (el.tagName === "BUTTON" && el.getAttribute("aria-haspopup") === "listbox" || boxDropdown(el)) && !el.closest("nav, header, footer, [role=navigation], [role=banner], [data-automation-id*='progress' i], [data-automation-id*='utility' i]") && !/\b(progress|menu|language|account|settings|filter|sort by)\b/i.test(el.textContent ?? "");
      if (["hidden", "submit", "button", "password", "image", "reset", "search"].includes(type) && el.getAttribute("data-automation-id") !== "searchBox" && !dropdownButton) continue;
      if (!el.matches("input, select, textarea, button") && !dropdownButton) continue;
      if (el.getAttribute("aria-hidden") === "true" || /honeypot|bee-?catcher/i.test(`${el.getAttribute("name") ?? ""} ${el.getAttribute("data-automation-id") ?? ""}`)) continue;
      if (!dialog && el.closest("[aria-hidden='true']") || el.id.startsWith("g-recaptcha")) continue;
      if (type !== "file" && type !== "radio" && type !== "checkbox" && !visible(el)) continue;
      if (type !== "file" && type !== "radio" && type !== "checkbox" && (el.getBoundingClientRect().width < 4 || el.getBoundingClientRect().height < 4)) continue;
      if (/robots? only|if you(?:'|’)?re (a )?human|leave (this|it) (field )?(blank|empty)|do not (fill|enter)/i.test(questionText(el))) continue;
      const required = el.hasAttribute("required") || el.getAttribute("aria-required") === "true" || Boolean(el.closest("[aria-required='true']")) || /[*✱]/.test(el.closest("label")?.textContent ?? (el.id ? rootOf(el).querySelector(`label[for="${CSS.escape(el.id)}"]`)?.textContent ?? "" : ""));
      let fieldType;
      let options2 = [];
      let target = el;
      if (type === "radio") {
        const name = el.name;
        if (!name || seenGroups.has(`r:${name}`)) continue;
        seenGroups.add(`r:${name}`);
        fieldType = "radio";
        options2 = Array.from(rootOf(el).querySelectorAll(`input[type=radio][name="${CSS.escape(name)}"]`)).map(labelOf).filter(Boolean);
      } else if (type === "checkbox") {
        const group = el.closest("fieldset, [role=group]");
        const boxes = group ? Array.from(group.querySelectorAll("input[type=checkbox]")) : [];
        if (boxes.length > 1) {
          const key2 = `c:${group.id || mark(group)}`;
          if (seenGroups.has(key2)) continue;
          seenGroups.add(key2);
          fieldType = "multiselect";
          options2 = boxes.map(labelOf).filter(Boolean);
          target = group;
        } else {
          fieldType = "checkbox";
          options2 = ["Yes"];
        }
      } else if (el instanceof HTMLSelectElement) {
        fieldType = "select";
        options2 = Array.from(el.options).map((option) => clean(option.text)).filter((text2) => text2 && !BLANK.test(text2));
      } else if (el.tagName === "BUTTON" || boxDropdown(el) || el.getAttribute("role") === "combobox" || el.getAttribute("data-automation-id") === "searchBox") {
        fieldType = "combobox";
      } else if (el.tagName === "TEXTAREA") {
        fieldType = "textarea";
      } else {
        fieldType = ["email", "tel", "file", "date", "url", "number"].includes(type) ? type : "text";
      }
      const source = target === el ? el : target.querySelector("input") ?? el;
      const label = fieldType === "multiselect" ? clean(target.querySelector("legend")?.textContent) || questionText(source) : questionText(el);
      if (!label || pageControl(el, label, fieldType === "combobox" || fieldType === "select")) continue;
      const placeholder = el.getAttribute("placeholder") ?? "";
      const segment = dateSegment(el);
      const dateOf = segment && /^(month|day|year)$/i.test(label) ? clean(el.closest("[data-automation-id^='formField'], fieldset, [role=group]")?.querySelector("label, legend")?.textContent) : "";
      const asked = segment ? `${dateOf || label} (${segment})`.replace(/^(month|day|year) \((month|day|year)\)$/i, "$1") : label;
      out.push({
        id: mark(target),
        label: asked.slice(0, 300),
        type: fieldType,
        options: options2.slice(0, 100),
        required,
        section: sectionOf(target),
        format: segment ? SEGMENT_FORMAT[segment] : /[my]{2}|dd/i.test(placeholder) ? placeholder : type === "date" ? "YYYY-MM-DD" : null
      });
    }
    return out;
  }
  function emptyRequired(fields = scanFields()) {
    return fields.filter((field) => {
      if (!field.required) return false;
      const el = findMarked(field.id);
      if (!el) return false;
      const control = el.matches("input, select, textarea, button") ? el : el.querySelector("input") ?? el;
      return isEmpty(control);
    });
  }
  function detectAts(host3) {
    if (/(^|\.)greenhouse\.io$/.test(host3)) return "greenhouse";
    if (/(^|\.)lever\.co$/.test(host3)) return "lever";
    if (/(^|\.)ashbyhq\.com$/.test(host3)) return "ashby";
    if (/myworkday(jobs|site)\.com$/.test(host3)) return "workday";
    return "other";
  }
  var JOB_LINK = /\/(job-search|jobs|stu\/jobs)\/\d+/;
  var outsideDialog = (el) => !el.closest("[role=dialog], [role=alertdialog], [aria-modal='true'], dialog");
  function handshakeJob(where = window.location) {
    if (!/(^|\.)joinhandshake\.com$/.test(where.hostname) || !JOB_LINK.test(where.pathname)) return null;
    const pane = handshakePane();
    if (!pane) return null;
    const heading = jobHeading(pane);
    const title = clean(heading?.textContent);
    if (!title) return null;
    const description = (pane.innerText || "").replace(/\n{3,}/g, "\n\n").trim().slice(0, 8e3);
    return { title: title.slice(0, 200), company: employerIn(pane, heading, title).slice(0, 200), description };
  }
  function jobHeading(box) {
    for (const tag of ["h1", "h2"]) {
      const found = Array.from(box.querySelectorAll(tag)).find((el) => {
        const text2 = clean(el.textContent);
        return visible(el) && outsideDialog(el) && text2.length >= 3 && text2.length <= 150 && !notJobTitle(text2) && !NOT_JOB_NAME.test(text2);
      });
      if (found) return found;
    }
    return null;
  }
  function handshakePane() {
    const right = Array.from(document.querySelectorAll("[data-hook='right-content']")).find((el) => visible(el) && jobHeading(el));
    if (right) return right;
    const marked2 = document.querySelector("[data-unnepo-pressed]");
    const pressed = marked2 && marked2.isConnected && outsideDialog(marked2) && Date.now() - Number(marked2.dataset.unnepoPressed) < 10 * 6e4 ? marked2 : null;
    const apply = pressed ?? Array.from(document.querySelectorAll("button, a, [role=button]")).find((el) => visible(el) && outsideDialog(el) && !/filter/i.test(el.getAttribute("aria-label") ?? "") && /^(apply|apply now|apply externally|quick apply|easy apply|applied)$/i.test(clean(el.textContent)));
    let box = apply ?? null;
    while (box && box !== document.body && !jobHeading(box)) box = box.parentElement;
    if (box && box !== document.body) return box;
    const heading = jobHeading(document.body);
    if (!heading) return null;
    box = heading;
    for (let i = 0; i < 8 && box.parentElement && box.parentElement !== document.body && !box.querySelector("a[href*='/e/']"); i += 1) box = box.parentElement;
    return box;
  }
  var LINKEDIN_HOST = /(^|\.)linkedin\.com$/;
  function linkedinJobId(href) {
    try {
      const url = new URL(href);
      if (!LINKEDIN_HOST.test(url.hostname)) return "";
      return url.pathname.match(/\/jobs\/view\/(?:[^/]*?-)?(\d{6,})/)?.[1] ?? url.searchParams.get("currentJobId") ?? "";
    } catch {
      return "";
    }
  }
  var linkedInRead = null;
  var linkedInIdSince = { id: "", at: 0 };
  function linkedinJob(where = window.location) {
    const read = readLinkedIn(where);
    const id = read ? linkedinJobId(where.href) : "";
    if (!read || !id) return read;
    if (linkedInIdSince.id !== id) linkedInIdSince = { id, at: Date.now() };
    if (read.fromCard) return read;
    const before = linkedInRead;
    const stale = before && before.id !== id && sameName(before.title, read.title) && (!before.company || !read.company || sameName(before.company, read.company));
    if (stale && Date.now() - linkedInIdSince.at < 6e3) return { title: "", company: "", description: "", waiting: true };
    linkedInRead = { id, title: read.title, company: read.company };
    return read;
  }
  function readLinkedIn(where) {
    if (!LINKEDIN_HOST.test(where.hostname) || !/^\/jobs\//.test(where.pathname) || !linkedinJobId(where.href)) return null;
    const first = (selectors, root = document) => {
      for (const selector of selectors) {
        const found = Array.from(root.querySelectorAll(selector)).find((el) => visible(el) && clean(el.textContent).length >= 2);
        if (found) return found;
      }
      return null;
    };
    const jobId = linkedinJobId(where.href);
    const readable = (el) => {
      const text3 = clean(el.textContent);
      const rect = el.getBoundingClientRect();
      return visible(el) && rect.width >= 20 && rect.height >= 10 && text3.length >= 3 && text3.length <= 150 && !notJobTitle(text3) && !NOT_JOB_NAME.test(text3) && !el.closest("header, nav, footer, aside, [role='navigation'], [role='contentinfo'], [role='complementary'], #global-nav, .global-nav, [class*='global-nav'], [class*='footer'], [class*='alert'], [class*='upsell'], [class*='promo']");
    };
    const known = [
      ".job-details-jobs-unified-top-card__job-title h1",
      ".job-details-jobs-unified-top-card__job-title",
      ".jobs-unified-top-card__job-title",
      ".top-card-layout__title",
      ".jobs-details-top-card__job-title",
      "[data-testid*='job-title' i]"
    ].flatMap((selector) => Array.from(document.querySelectorAll(selector))).find(readable);
    const size = (el) => parseFloat(window.getComputedStyle(el).fontSize) || 0;
    const biggest = (selector) => Array.from(document.querySelectorAll(selector)).filter(readable).sort((a, b) => size(b) - size(a))[0];
    const heading = known ?? (jobId ? biggest(`a[href*='/jobs/view/${jobId}']`) : void 0) ?? biggest("h1");
    const card = linkedinCard(jobId);
    const paneTitle = clean(known?.textContent);
    const paneCompany = cleanCompanyName(clean(first([".job-details-jobs-unified-top-card__company-name", ".jobs-unified-top-card__company-name", ".topcard__org-name-link"])?.textContent));
    const otherCompany = Boolean(card?.company && paneCompany && !sameName(paneCompany, card.company));
    if (card && (!paneTitle || !sameName(paneTitle, card.title) || otherCompany || heading?.closest(".jobs-search-results-list, [class*='results-list'], li"))) {
      return { title: card.title.slice(0, 200), company: card.company.slice(0, 200), description: "", fromCard: true };
    }
    const fromTab = titleParts(document.title);
    const title = clean(heading?.textContent) || fromTab?.title || "";
    if (!title || notJobTitle(title)) return null;
    let pane = heading ?? document.body;
    while (heading && pane.parentElement && pane.parentElement !== document.body && distinctJobLinks(pane.parentElement) <= 1) pane = pane.parentElement;
    const companyEl = first([
      ".job-details-jobs-unified-top-card__company-name a",
      ".job-details-jobs-unified-top-card__company-name",
      ".jobs-unified-top-card__company-name a",
      ".jobs-unified-top-card__company-name",
      ".topcard__org-name-link",
      ".top-card-layout__second-subline a",
      "a[href*='/company/']"
    ], pane);
    const company = [clean(companyEl?.textContent), fromTab && sameName(fromTab.title, title) ? fromTab.company : ""].map((name) => cleanCompanyName(name)).find((name) => goodEmployer(name, title)) || employerIn(pane, heading ?? null, title);
    const about = first(["#job-details", ".jobs-description__content", ".jobs-description-content__text", ".jobs-box__html-content", ".show-more-less-html__markup", ".description__text"], pane) ?? first(["#job-details", ".jobs-description__content", ".show-more-less-html__markup", ".description__text"]);
    let text2 = about?.innerText ?? "";
    if (!text2) {
      let box = Array.from(pane.querySelectorAll("h2, h3, span, div")).find((el) => el.children.length <= 1 && /^about the job$/i.test(clean(el.textContent))) ?? null;
      while (box && box !== pane && (box.innerText || "").length < 300) box = box.parentElement;
      text2 = box?.innerText || pane.innerText || "";
    }
    const description = text2.replace(/\n{3,}/g, "\n\n").trim().slice(0, 8e3);
    return { title: title.slice(0, 200), company: company.slice(0, 200), description };
  }
  function linkedinCard(jobId) {
    if (!jobId) return null;
    const marked2 = document.querySelector(`[data-occludable-job-id='${jobId}'], [data-job-id='${jobId}']`);
    const linked = Array.from(document.querySelectorAll(`a[href*='/jobs/view/${jobId}'], a[href*='currentJobId=${jobId}']`)).map((a) => a.closest("li")).find((li) => li && li.parentElement && distinctJobLinks(li.parentElement) > 1) ?? null;
    const box = marked2 ?? linked;
    if (!box) return null;
    const link = box.querySelector(`a[href*='/jobs/view/'], a[href*='currentJobId=']`);
    const title = clean((link?.innerText || link?.textContent || link?.getAttribute("aria-label") || "").split("\n").find((line) => clean(line)) ?? "").replace(/\s+with verification$/i, "");
    if (!title || notJobTitle(title) || NOT_JOB_NAME.test(title)) return null;
    const companyEl = box.querySelector(".artdeco-entity-lockup__subtitle, .job-card-container__primary-description, .job-card-container__company-name, [class*='company-name'], [class*='subtitle']");
    const company = cleanCompanyName(clean((companyEl?.innerText || companyEl?.textContent || "").split("\n")[0]));
    return { title, company: goodEmployer(company, title) ? company : "" };
  }
  function hiringTeam() {
    if (!/(^|\.)linkedin\.com$/.test(window.location.hostname)) return null;
    const heading = Array.from(document.querySelectorAll("h2, h3, span, div")).find((el) => el.children.length <= 1 && /^(meet the hiring team|people you can reach out to)$/i.test(clean(el.textContent)) && visible(el)) ?? Array.from(document.querySelectorAll(".hirer-card__hirer-information, [class*='people-who-can-help'], [class*='hirer-card']")).find(visible);
    if (!heading) return null;
    let box = heading;
    while (box && box !== document.body && !box.querySelector("a[href*='/in/']")) box = box.parentElement;
    const link = box?.querySelector("a[href*='/in/']");
    if (!box || !link) return null;
    const lines = (box.innerText || "").split("\n").map((line) => clean(line)).filter(Boolean);
    const name = clean(link.innerText.split("\n")[0]).replace(/\s*•.*$/, "") || lines.find((line) => /^[A-Z][a-zA-Z'’.-]+( [A-Z][a-zA-Z'’.-]+)+$/.test(line)) || "";
    if (name.split(" ").length < 2 || name.length > 80) return null;
    const after = lines.slice(lines.findIndex((line) => line.startsWith(name)) + 1);
    const title = after.find((line) => !/^(•|\d|1st|2nd|3rd|job poster|message|connect|follow|meet the hiring team)/i.test(line) && line.length <= 160) ?? "";
    let profileUrl = "";
    try {
      const url = new URL(link.href);
      profileUrl = `${url.origin}${url.pathname}`;
    } catch {
      profileUrl = "";
    }
    return { name, title, profileUrl };
  }
  function structuredJob() {
    return structuredJobs()[0] ?? null;
  }
  function structuredJobs() {
    const postings = [];
    const collect = (value) => {
      if (Array.isArray(value)) value.forEach(collect);
      else if (value && typeof value === "object") {
        const item = value;
        const type = item["@type"];
        if (type === "JobPosting" || Array.isArray(type) && type.includes("JobPosting")) postings.push(item);
        if (item["@graph"]) collect(item["@graph"]);
      }
    };
    for (const script of Array.from(document.querySelectorAll('script[type="application/ld+json"]'))) {
      try {
        collect(JSON.parse(script.textContent || ""));
      } catch {
      }
    }
    return postings.map((job) => {
      const org = job.hiringOrganization;
      const company = cleanCompanyName(clean(typeof org === "string" ? org : String(org?.name ?? "")));
      const title = clean(String(job.title ?? ""));
      const html = String(job.description ?? "").replace(/<br\s*\/?>|<\/(p|li|div|h[1-6]|ul|ol|tr)>/gi, (tag) => `${tag}
`);
      const text2 = new DOMParser().parseFromString(html, "text/html").body.textContent || "";
      const description = text2.replace(/[ \t]+/g, " ").replace(/\n{3,}/g, "\n\n").trim().slice(0, 8e3);
      return { title: title.slice(0, 200), company: company.slice(0, 200), description };
    }).filter((job) => job.title);
  }
  var JOB_SITE_NAME = /^(workday|greenhouse|lever|ashby|icims|smartrecruiters|jobvite|taleo|workable|careers?|jobs?|job application|handshake|ziprecruiter|indeed|glassdoor|wellfound|dice|simplify|built ?in|monster|simplyhired|careerbuilder|wayup|idealist|usajobs|linkedin)$/i;
  var BOARD_SUFFIX = /\s*[|·–—-]\s*(handshake|ziprecruiter|indeed(\.com)?|glassdoor|wellfound|dice|simplify|built ?in[a-z ]*|monster(\.com)?|simplyhired|careerbuilder|wayup|idealist|usajobs|linkedin)\s*$/i;
  function titleParts(text2) {
    const plainText = text2.replace(/^\(\d+\)\s*/, "").replace(/\s+/g, " ").trim();
    if (!BOARD_SUFFIX.test(plainText) && !/ at | hiring /i.test(plainText)) return null;
    const bare2 = plainText.replace(BOARD_SUFFIX, "").replace(/\s+(job|jobs)$/i, "").trim();
    const hiring = bare2.match(/^(.{2,80}?) (?:is )?hiring (?:for )?(?:an? )?(.{2,120}?)(?: (?:job )?in .{2,60})?$/i);
    if (hiring) return { title: hiring[2].trim(), company: hiring[1].trim() };
    const at = bare2.match(/^(.{2,120}?)(?: job)? at (.{2,80}?)(?:\s*[-–|,·]\s*.{2,60})?$/i);
    if (at) return { title: at[1].trim(), company: at[2].trim() };
    const parts = bare2.split(/\s+[|·–—-]\s+/).map((part) => part.trim()).filter(Boolean);
    if (parts.length >= 2 && !JOB_SITE_NAME.test(parts[1])) return { title: parts[0], company: parts[1] };
    return null;
  }
  function workdayCompany(where = window.location) {
    const parts = where.pathname.split("/").filter(Boolean).filter((part) => !/^[a-z]{2}-[A-Z]{2}$/.test(part));
    const tenant = where.hostname.endsWith(".myworkdayjobs.com") ? where.hostname.split(".")[0] : parts[0] === "recruiting" ? parts[1] ?? "" : "";
    return tenant.replace(/[-_]+/g, " ").replace(/\b\w/g, (c) => c.toUpperCase()).trim();
  }
  function hostCompany(host3) {
    if (QUICK_BOARDS.test(host3) || /(^|\.)linkedin\.com$/.test(host3)) return "";
    const first = host3.replace(/^(www|jobs|careers|boards|apply|job-boards|hire|recruiting)\./, "").split(".")[0];
    return NOT_COMPANY.test(first) ? "" : first;
  }
  var NO_TITLE = "Job title missing";
  function applyDialogCompany() {
    const dialog = openDialog();
    if (!dialog) return "";
    return Array.from(dialog.querySelectorAll(HEADING)).map((el) => companyFromApplyHeading(clean(el.textContent))).find(Boolean) ?? "";
  }
  function scanPage() {
    const host3 = window.location.hostname;
    const ats = detectAts(host3);
    const meta = (name) => document.querySelector(`meta[property="${name}"], meta[name="${name}"]`)?.content ?? "";
    const heading = clean(document.querySelector("h1")?.textContent);
    const greenhouseTitle = document.title.match(/^Job Application for (.+) at (.+)$/);
    const opened2 = QUICK_BOARDS.test(host3) ? findOpenedJob() : null;
    const posting = handshakeJob() ?? linkedinJob() ?? opened2 ?? structuredJob();
    const poster = hiringTeam();
    const fromTitle = posting || !QUICK_BOARDS.test(host3) ? null : titleParts(document.title) ?? titleParts(meta("og:title"));
    const named = (text2) => text2 && !notJobTitle(text2) ? text2 : "";
    const firstHeading = Array.from(document.querySelectorAll("h1")).map((el) => clean(el.textContent)).find((text2) => text2 && !notJobTitle(text2)) ?? "";
    const tabName = clean(document.title.split(/\s+[|–—-]\s+/)[0]);
    const waiting = Boolean(posting && "waiting" in posting && posting.waiting);
    const title = waiting ? NO_TITLE : (named(posting?.title) || greenhouseTitle?.[1] || named(fromTitle?.title) || named(heading) || firstHeading || named(meta("og:title")) || named(tabName) || NO_TITLE).slice(0, 200);
    const siteName = meta("og:site_name");
    const company = waiting ? "" : (posting?.company || greenhouseTitle?.[2] || fromTitle?.company || (ats === "workday" ? workdayCompany() : "") || applyDialogCompany() || (siteName && !JOB_SITE_NAME.test(siteName.trim()) ? siteName : "") || hostCompany(host3)).slice(0, 200);
    const frame = document.querySelector("iframe#grnhse_iframe, iframe[src*='greenhouse.io/embed'], iframe[src*='jobs.lever.co'], iframe[src*='ashbyhq.com']");
    const captcha = Array.from(document.querySelectorAll("iframe[src*='hcaptcha'], iframe[title*='recaptcha challenge' i], iframe[src*='recaptcha/api2/bframe']")).some(visible);
    return {
      url: window.location.href,
      ...opened2 ? { jobUrl: opened2.url } : {},
      title,
      company,
      ...posting?.description ? { description: posting.description } : {},
      ...poster ? { poster } : {},
      ats,
      useServerSchema: ats === "greenhouse" && Boolean(document.getElementById("first_name")),
      fields: scanFields(),
      embeddedForm: frame?.src ?? null,
      captcha,
      passwordBoxes: deepAll("input[type=password]").filter(visible).length,
      mentionsCv: /\bCV\b|curriculum vitae/.test(document.body.innerText || "")
    };
  }
  var JOB_HREF = /\/(jobs?|job-search|stu\/jobs|viewjob|job-listing|job-detail|jobs\/view|rc\/clk|partner\/joblisting\.htm|c\/[^/]+\/job)(\/|\?|$|\.htm)|[?&](jk|vjk|jid|jl|joblistingid|currentjobid|jobid|job_id)=/i;
  var APPLY_LABEL = /^(1-click apply|one-click apply|quick apply|easy apply|instant apply|apply|apply now|apply externally|apply on company (site|website)|apply on employer site|apply with (my )?(profile|resume)|i'?m interested)$/i;
  var NOT_JOB_NAME = /^(job details|about the job|meet the hiring team|people you can reach out to|about the company|job search faster with premium|show more|see more|about (the |this )?(company|role|position)|description|job description|overview|qualifications|requirements|benefits|similar jobs|more jobs|recommended( jobs)?|people also viewed|jobs you may like|salary|location|full job description|apply|share|report)$/i;
  var COMPANY_LINK = "a[href*='/company/'], a[href*='/cmp/'], a[href*='/companies/'], a[href*='/e/'], a[href*='/emp/'], a[href*='/employers/'], a[href*='/organizations/'], a[href*='/Overview/'], a[href*='/c/']";
  var COMPANY_NAMED = "[data-testid*='company' i], [data-testid*='employer' i], [data-test*='employer' i], [data-test*='company' i], [data-hook*='employer' i], [data-hook*='company' i], [class*='companyName' i], [class*='company-name' i], [class*='employer-name' i], [class*='employerName' i], [class*='employer_name' i], [itemprop='hiringOrganization']";
  var distinctJobLinks = (root) => {
    const seen = /* @__PURE__ */ new Set();
    const links = [...root.matches("a[href]") ? [root] : [], ...Array.from(root.querySelectorAll("a[href]"))];
    for (const a of links) {
      if ((a.getAttribute("href") ?? "").startsWith("#")) continue;
      try {
        const url = new URL(a.href);
        if (!/\d/.test(`${url.pathname}${url.search}`)) continue;
        if (JOB_HREF.test(`${url.pathname}${url.search}`)) seen.add(`${url.pathname}?${["jk", "vjk", "jid", "jl", "jobListingId", "currentJobId", "jobId"].map((key2) => url.searchParams.get(key2) ?? "").join("|")}`);
      } catch {
      }
    }
    return seen.size;
  };
  var sameName = (a, b) => {
    const word = (text2) => text2.toLowerCase().replace(/[^a-z0-9]+/g, " ").trim();
    const [x, y] = [word(a), word(b)];
    return Boolean(x && y) && (x === y || x.startsWith(y) || y.startsWith(x));
  };
  function jobLink(href) {
    try {
      const url = new URL(href);
      const indeedJob = /(^|\.)indeed\.com$/.test(url.hostname) ? url.searchParams.get("jk") ?? url.searchParams.get("vjk") : null;
      if (indeedJob) return `${url.origin}/viewjob?jk=${indeedJob}`;
      const handshake = /(^|\.)joinhandshake\.com$/.test(url.hostname) ? url.pathname.match(/^\/(?:stu\/)?(?:job-search|jobs)\/(\d+)/)?.[1] : null;
      if (handshake) return `${url.origin}/jobs/${handshake}`;
      const linkedin = linkedinJobId(url.href);
      if (linkedin) return `https://www.linkedin.com/jobs/view/${linkedin}/`;
      return url.href;
    } catch {
      return href;
    }
  }
  var NOT_COMPANY = /^(app|www|my|portal|localhost|students?|jobs?|careers?|employers?|companies|company|organization|job board|logo|image|avatar|profile|view profile|follow|following|message|save|saved|share|report|apply|more|see more|show more|about|overview|reviews?|salaries|benefits|united states|usa|us|remote|hybrid|on-?site)$/i;
  var LOCATION = /^[A-Z][a-zA-Z .'-]+, ([A-Z]{2}|[A-Z][a-z]+)( \d{5})?$|^(remote|hybrid|on-?site)\b/i;
  function goodEmployer(raw, title) {
    const text2 = raw.trim();
    return text2.length >= 2 && text2.length <= 80 && !sameName(text2, title) && !notJobTitle(text2) && !NOT_EMPLOYER.test(text2) && !NOT_COMPANY.test(text2) && !JOB_SITE_NAME.test(text2) && !LOCATION.test(text2) && !/^https?:|\.(com|org|io|net)$/i.test(text2) && /[a-z]/i.test(text2);
  }
  var firstPart = (text2) => cleanCompanyName(cleanCompanyName(clean(text2)).split(/\s+[·|•–—]\s+|\s-\s|\n/)[0]);
  function employerIn(pane, heading, title) {
    const pick = (values) => values.map((value) => firstPart(value ?? "")).find((value) => goodEmployer(value, title)) ?? "";
    const shown2 = (el) => visible(el);
    const named = pick(Array.from(pane.querySelectorAll(COMPANY_NAMED)).filter(shown2).map((el) => el.innerText || el.textContent || el.getAttribute("aria-label")));
    if (named) return named;
    const linked = pick(Array.from(pane.querySelectorAll(COMPANY_LINK)).filter(shown2).map((a) => clean(a.innerText || a.textContent) || a.getAttribute("aria-label") || a.querySelector("img")?.alt || a.title));
    if (linked) return linked;
    let near = heading?.parentElement ?? null;
    for (let level = 0; near && level < 4 && near !== pane.parentElement; level += 1, near = near.parentElement) {
      const logo = pick(Array.from(near.querySelectorAll("img[alt], [role=img][aria-label], [aria-label*='logo' i]")).map((el) => el.alt || el.getAttribute("aria-label")));
      if (logo) return logo;
    }
    const about = pick(Array.from(pane.querySelectorAll("h2, h3, h4, strong")).map((el) => clean(el.textContent).match(/^about (?!the |this |us$|the$)(.{2,60})$/i)?.[1]));
    if (about) return about;
    const lines = (pane.innerText || "").split("\n").map((line) => clean(line)).filter(Boolean);
    const at = lines.findIndex((line) => sameName(line, title));
    if (at >= 0) {
      const beside = pick([lines[at - 1], lines[at + 1], lines[at - 2], lines[at + 2]]);
      if (beside) return beside;
    }
    const fromTitle = titleParts(document.title)?.company;
    if (fromTitle && goodEmployer(fromTitle, title)) return fromTitle;
    const text2 = (pane.innerText || "").slice(0, 6e3);
    const said = text2.match(/\b([A-Z][\w&.'’-]*(?: [A-Z][\w&.'’-]*){0,3}) (?:is hiring|is looking for|is seeking|seeks)\b/)?.[1] ?? text2.match(/\b(?:Join|At|About) ([A-Z][\w&.'’-]*(?: [A-Z][\w&.'’-]*){0,3})(?:,| we\b| is\b|!|\.)/)?.[1];
    return said && goodEmployer(said, title) ? said : "";
  }
  var NOT_EMPLOYER = /^(remote|hybrid|on-?site|in person|full[- ]time|part[- ]time|internship|contract|\$|\d|posted|new|today|easy apply|apply)/i;
  function openedJob(pressed) {
    const found = findOpenedJob(pressed);
    if (found) return found;
    const address = jobLink(window.location.href);
    const fromTitle = titleParts(document.title);
    if (fromTitle) return { ...fromTitle, description: "", url: address, from: "page title" };
    const page = scanPage();
    return { title: page.title, company: page.company, description: page.description ?? "", url: address, from: "page" };
  }
  function findOpenedJob(given) {
    const marked2 = document.querySelector("[data-unnepo-pressed]");
    const pressed = given ?? (marked2 && visible(marked2) && Date.now() - Number(marked2.dataset.unnepoPressed) < 5 * 6e4 ? marked2 : null);
    const handshake = handshakeJob();
    const address = jobLink(window.location.href);
    if (handshake?.title) return { ...handshake, url: address, from: "details pane" };
    const linkedin = linkedinJob();
    if (linkedin?.waiting) return { title: "", company: "", description: "", url: address, from: "details pane" };
    if (linkedin?.title) return { title: linkedin.title, company: linkedin.company, description: linkedin.description, url: address, from: "details pane" };
    const postings = structuredJobs();
    const buttons2 = pressed ? [pressed] : Array.from(document.querySelectorAll("button, a, [role=button], input[type=submit]")).filter((el) => visible(el) && APPLY_LABEL.test(clean(el.textContent || el.value || el.getAttribute("aria-label"))));
    const panes = buttons2.map((button) => {
      let pane2 = button;
      while (pane2.parentElement && pane2.parentElement !== document.body && distinctJobLinks(pane2.parentElement) <= 1) pane2 = pane2.parentElement;
      return pane2;
    });
    const pane = panes.sort((a, b) => (b.innerText || "").length - (a.innerText || "").length)[0];
    if (pane && (pressed || (pane.innerText || "").length > 200)) {
      const heading = ["h1", "h2", "h3"].map((tag) => Array.from(pane.querySelectorAll(tag)).find((el) => visible(el) && clean(el.textContent).length >= 3 && clean(el.textContent).length <= 150 && !NOT_JOB_NAME.test(clean(el.textContent)) && !notJobTitle(clean(el.textContent)))).find(Boolean);
      const title = clean(heading?.textContent);
      if (title) {
        const matching = postings.find((posting) => sameName(posting.title, title));
        const company = (matching?.company && goodEmployer(matching.company, title) ? matching.company : "") || employerIn(pane, heading ?? null, title);
        const own = Array.from(pane.querySelectorAll("a[href]")).find((a) => JOB_HREF.test(a.href) && sameName(clean(a.textContent), title));
        const description = matching?.description || (pane.innerText || "").replace(/\n{3,}/g, "\n\n").trim().slice(0, 8e3);
        return { title: title.slice(0, 200), company: company.slice(0, 200), description, url: own ? jobLink(own.href) : address, from: matching ? "posting data" : "details pane" };
      }
    }
    if (postings.length === 1 && distinctJobLinks(document.body) < 3) return { ...postings[0], url: address, from: "posting data" };
    const selected = Array.from(document.querySelectorAll("[aria-selected='true'], [aria-current='true'], [aria-current='page'], [class*='selected' i], [class*='active' i]")).find((el) => visible(el) && distinctJobLinks(el) === 1 && (el.innerText || "").length < 600);
    if (selected) {
      const lines = (selected.innerText || "").split("\n").map((line) => clean(line)).filter((line) => line.length >= 2 && !notJobTitle(line) && !/^(new|applied|easy apply|promoted|sponsored|urgently hiring|\d+ ?[dh]|\d+ days? ago|today|just posted)$/i.test(line));
      const link = selected.matches("a[href]") ? selected : selected.querySelector("a[href]");
      if (lines.length >= 2) return { title: lines[0].slice(0, 200), company: lines[1].slice(0, 200), description: "", url: link && JOB_HREF.test(link.href) ? jobLink(link.href) : address, from: "selected result" };
    }
    return null;
  }
  function jobPane() {
    if (/(^|\.)joinhandshake\.com$/.test(window.location.hostname)) {
      const pane2 = handshakePane();
      if (pane2) return pane2;
    }
    const marked2 = document.querySelector("[data-unnepo-pressed]");
    const pressed = marked2 && marked2.isConnected && visible(marked2) && outsideDialog(marked2) && Date.now() - Number(marked2.dataset.unnepoPressed) < 10 * 6e4 ? marked2 : null;
    const button = pressed ?? Array.from(document.querySelectorAll("button, a, [role=button]")).find((el) => visible(el) && outsideDialog(el) && (APPLY_LABEL.test(clean(el.textContent)) || /^([✓✔]\s*)?applied\b/i.test(clean(el.textContent))));
    const start = button ?? Array.from(document.querySelectorAll("h1, h2")).find((el) => visible(el) && outsideDialog(el));
    if (!start) return document.body;
    let pane = start;
    while (pane.parentElement && pane.parentElement !== document.body && distinctJobLinks(pane.parentElement) <= 1) pane = pane.parentElement;
    return pane;
  }

  // extension/src/content/dom.ts
  var sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
  async function waitFor(find2, timeout = 4e3) {
    const end = Date.now() + timeout;
    for (; ; ) {
      const found = find2();
      if (found) return found;
      if (Date.now() > end) return null;
      await sleep(60);
    }
  }
  function typeInto(el, value, blur = true) {
    el.focus();
    const proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    Object.getOwnPropertyDescriptor(proto, "value")?.set?.call(el, value);
    el.dispatchEvent(new Event("input", { bubbles: true, composed: true }));
    el.dispatchEvent(new Event("change", { bubbles: true, composed: true }));
    if (blur) leave(el);
  }
  function leave(el) {
    if (el.matches(":focus")) el.blur();
    else el.dispatchEvent(new FocusEvent("focusout", { bubbles: true, composed: true }));
  }
  function press(el) {
    const rect = el.getBoundingClientRect();
    const at = { bubbles: true, cancelable: true, clientX: rect.left + rect.width / 2, clientY: rect.top + rect.height / 2, button: 0 };
    el.dispatchEvent(new PointerEvent("pointerdown", at));
    el.dispatchEvent(new MouseEvent("mousedown", at));
    el.dispatchEvent(new PointerEvent("pointerup", at));
    el.dispatchEvent(new MouseEvent("mouseup", at));
    el.click();
  }
  function chooseNativeSelect(el, answer) {
    const labels = Array.from(el.options).map((option) => option.text.trim());
    const choice = answerChoices(answer).map((candidate) => bestOption(candidate, labels)).find(Boolean);
    if (!choice) throw new FillError(`no option matching "${answer}"`, "no_option", labels.filter(Boolean).slice(0, 100));
    el.value = el.options[labels.indexOf(choice)].value;
    el.dispatchEvent(new Event("input", { bubbles: true, composed: true }));
    el.dispatchEvent(new Event("change", { bubbles: true, composed: true }));
  }
  function matchOption(answer, texts, pick) {
    if (pick) return pick(texts);
    if (DECLINE.test(answer)) return texts.find((option) => DECLINE.test(option)) ?? null;
    return answerChoices(answer).map((candidate) => bestOption(candidate, texts)).find(Boolean) ?? null;
  }
  var optionText = (el) => (el.textContent ?? "").replace(/\s+/g, " ").trim();
  var FillError = class extends Error {
    constructor(message, problem, options2 = []) {
      super(message);
      this.problem = problem;
      this.options = options2;
    }
    problem;
    options;
  };
  function visibleOptions(scope = document) {
    return deepAll("[role=option], [data-automation-id='promptOption']", scope).filter((el) => el.getBoundingClientRect().height > 0);
  }
  function focused() {
    let el = document.activeElement;
    while (el?.shadowRoot?.activeElement) el = el.shadowRoot.activeElement;
    return el && el !== document.body ? el : null;
  }
  function key(el, name) {
    const codes = { ArrowDown: 40, ArrowUp: 38, Enter: 13, Escape: 27, " ": 32, Tab: 9 };
    const at = { key: name, code: name.length === 1 ? name === " " ? "Space" : `Key${name.toUpperCase()}` : name, keyCode: codes[name] ?? name.toUpperCase().charCodeAt(0), which: codes[name] ?? name.toUpperCase().charCodeAt(0), bubbles: true, cancelable: true, composed: true };
    el.dispatchEvent(new KeyboardEvent("keydown", at));
    if (name.length === 1 || name === "Enter") el.dispatchEvent(new KeyboardEvent("keypress", at));
    el.dispatchEvent(new KeyboardEvent("keyup", at));
  }
  async function typeKeys(el, value, blur = true) {
    el.focus();
    const proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const set = (text2) => Object.getOwnPropertyDescriptor(proto, "value")?.set?.call(el, text2);
    set("");
    el.dispatchEvent(new InputEvent("input", { bubbles: true, composed: true, inputType: "deleteContentBackward" }));
    let typed = "";
    for (const char of value) {
      const at = { key: char, bubbles: true, cancelable: true, composed: true };
      el.dispatchEvent(new KeyboardEvent("keydown", at));
      el.dispatchEvent(new KeyboardEvent("keypress", at));
      typed += char;
      set(typed);
      el.dispatchEvent(new InputEvent("input", { bubbles: true, composed: true, data: char, inputType: "insertText" }));
      el.dispatchEvent(new KeyboardEvent("keyup", at));
      if (value.length <= 40) await sleep(25);
    }
    el.dispatchEvent(new Event("change", { bubbles: true, composed: true }));
    if (blur) leave(el);
  }
  var BLANK_CHOICE = /^(select( one)?(\.{1,3}|…)?|choose( one)?(\.{1,3}|…)?|please select|search|--.*|)$/i;
  var CHOSEN = "[class*='single-value'], [class*='singleValue'], [class*='multi-value'], [class*='multiValue'], [data-automation-id='selectedItem'], [class*='selected-value'], [class*='selectedValue']";
  var loose = (text2) => text2.toLowerCase().replace(/\s*\([^)]*\)/g, "").replace(/[^a-z0-9]+/g, " ").trim();
  function chosenBeside(trigger) {
    let node = trigger;
    for (let depth = 0; node && depth < 5; depth += 1, node = node.parentElement) {
      const chosen = Array.from(node.querySelectorAll(CHOSEN)).map(optionText).filter(Boolean);
      if (chosen.length) return chosen.join(", ");
      if (depth > 0 && node.querySelectorAll("input:not([type=hidden]), select, button, [role=combobox]").length > 2) break;
    }
    return null;
  }
  function shownChoice(trigger) {
    const beside = chosenBeside(trigger);
    if (beside) return beside;
    if (trigger instanceof HTMLInputElement) return trigger.value.trim();
    const shown2 = (trigger.innerText || trigger.textContent || "").replace(/\s+/g, " ").trim();
    if (BLANK_CHOICE.test(shown2)) return "";
    return shown2 || null;
  }
  function showsChoice(trigger, choice) {
    const shown2 = shownChoice(trigger);
    if (shown2 === null) return true;
    if (!shown2) return false;
    const have = loose(shown2);
    const want = loose(choice);
    if (!want) return true;
    if (trigger instanceof HTMLInputElement && !chosenBeside(trigger)) return have.includes(want);
    return have.includes(want) || want.includes(have);
  }
  function scroller(el) {
    let node = el?.parentElement ?? null;
    for (let depth = 0; node && depth < 6; depth += 1, node = node.parentElement) {
      const overflow = getComputedStyle(node).overflowY;
      if ((overflow === "auto" || overflow === "scroll") && node.scrollHeight > node.clientHeight + 2) return node;
    }
    return null;
  }
  var waysFrom = (first) => first === "keyboard" ? ["keyboard", "click"] : ["click", "keyboard"];
  function listFor(trigger, before, options2) {
    return options2.list ?? (() => {
      const owned = ownedList(trigger);
      const shown2 = owned ? visibleOptions(owned) : visibleOptions();
      const fresh = shown2.filter((el) => !before.has(el));
      return fresh.length ? fresh : shown2;
    });
  }
  async function findChoice(list, answer, pick) {
    const seen = [];
    for (let round = 0; round < 30; round += 1) {
      const items = list();
      const texts = items.map(optionText);
      for (const text2 of texts) if (text2 && !seen.includes(text2)) seen.push(text2);
      const choice = matchOption(answer, texts, pick);
      if (choice) return { item: items[texts.indexOf(choice)], choice, seen };
      const box = scroller(items[items.length - 1]);
      if (!box || box.scrollTop + box.clientHeight >= box.scrollHeight - 2) break;
      box.scrollTop += Math.max(box.clientHeight - 20, 40);
      box.dispatchEvent(new Event("scroll", { bubbles: true }));
      await sleep(180);
    }
    return { item: null, choice: null, seen };
  }
  async function nestedChoice(trigger, answer, choice, before, firstList, pick) {
    const nested = visibleOptions().filter((el) => !firstList.includes(el) && !before.has(el));
    if (!nested.length) return choice;
    const nestedTexts = nested.map(optionText);
    const second = matchOption(answer, nestedTexts, pick) ?? nestedTexts.find((text2) => /^other\b/i.test(text2)) ?? (nested.length === 1 ? nestedTexts[0] : null);
    if (!second) {
      close(trigger);
      throw new FillError(`"${choice}" opened more choices, and none fits "${answer}"`, "more_choices", nestedTexts.slice(0, 100));
    }
    press(nested[nestedTexts.indexOf(second)]);
    await sleep(250);
    return second;
  }
  function notOpened(trigger, options2, message) {
    const searched = options2.type && trigger instanceof HTMLInputElement && (trigger.getAttribute("aria-expanded") === "true" || ownedList(trigger));
    return searched ? new FillError(`searching "${options2.type.slice(0, 40)}" showed no options`, "no_option") : new FillError(message, "list_didnt_open");
  }
  async function byClicking(trigger, answer, options2) {
    const before = new Set(visibleOptions());
    const list = listFor(trigger, before, options2);
    trigger.scrollIntoView({ block: "center" });
    const control = trigger.closest("[class*='select__control'], [class*='-control']") ?? trigger;
    press(control);
    if (trigger instanceof HTMLInputElement) trigger.focus();
    if (options2.type && trigger instanceof HTMLInputElement) typeInto(trigger, options2.type.slice(0, 40), false);
    const found = await waitFor(() => list().length ? list() : null, options2.type ? 6e3 : 3e3);
    if (!found) throw notOpened(trigger, options2, "the list didn't open");
    if (options2.type) await sleep(350);
    const { item, choice, seen } = await findChoice(list, answer, options2.pick);
    if (!item || !choice) {
      close(trigger);
      throw new FillError(`no option matching "${answer}"`, "no_option", seen.slice(0, 100));
    }
    const firstList = list();
    press(item);
    await sleep(250);
    const final = await nestedChoice(trigger, answer, choice, before, firstList, options2.pick);
    if (firstList.some((el) => el.isConnected && el.getBoundingClientRect().height > 0) && !multiSelect(trigger)) close(trigger);
    return final;
  }
  function activeIndex(trigger, items) {
    const pointed = [trigger, focused()].map((el) => el?.getAttribute("aria-activedescendant")).find(Boolean);
    if (pointed) {
      const index = items.findIndex((item) => item.id === pointed);
      if (index >= 0) return index;
    }
    const marked2 = items.findIndex((item) => item === focused() || item.getAttribute("data-focused") === "true" || /\b(is-?focused|focused|highlighted|is-active|active)\b/i.test(item.className));
    if (marked2 >= 0) return marked2;
    return items.findIndex((item) => item.getAttribute("aria-selected") === "true");
  }
  async function byKeyboard(trigger, answer, options2) {
    const before = new Set(visibleOptions());
    const list = listFor(trigger, before, options2);
    trigger.scrollIntoView({ block: "center" });
    trigger.focus();
    const typing = trigger instanceof HTMLInputElement && options2.type;
    if (typing) await typeKeys(trigger, options2.type.slice(0, 40), false);
    key(focused() ?? trigger, "ArrowDown");
    let found = await waitFor(() => list().length ? list() : null, typing ? 6e3 : 1200);
    for (const opener of typing ? [] : [" ", "Enter"]) {
      if (found) break;
      key(focused() ?? trigger, opener);
      found = await waitFor(() => list().length ? list() : null, 1200);
    }
    if (!found) throw notOpened(trigger, options2, "the list didn't open, by click or keyboard");
    if (typing) await sleep(350);
    const { item, choice, seen } = await findChoice(list, answer, options2.pick);
    if (!item || !choice) {
      close(trigger);
      throw new FillError(`no option matching "${answer}"`, "no_option", seen.slice(0, 100));
    }
    const firstList = list();
    let moved = false;
    for (let presses = 0; presses < 300; presses += 1) {
      const items = list();
      const at = activeIndex(trigger, items);
      const target = items.map(optionText).indexOf(choice);
      if (at < 0 || target < 0) break;
      if (at === target) {
        moved = true;
        break;
      }
      key(focused() ?? trigger, at < target ? "ArrowDown" : "ArrowUp");
      await sleep(15);
    }
    if (moved) key(focused() ?? trigger, "Enter");
    else (list().find((el) => optionText(el) === choice) ?? item).click();
    await sleep(250);
    const final = await nestedChoice(trigger, answer, choice, before, firstList, options2.pick);
    if (firstList.some((el) => el.isConnected && el.getBoundingClientRect().height > 0) && !multiSelect(trigger)) close(trigger);
    return final;
  }
  async function chooseCustom(trigger, answer, options2 = {}) {
    const ways = { click: byClicking, keyboard: byKeyboard };
    let last2 = null;
    for (const method of options2.ways ?? waysFrom()) {
      try {
        const choice = await ways[method](trigger, answer, options2);
        await sleep(60);
        if (showsChoice(trigger, choice)) return method;
        last2 = new FillError(`picked "${choice}", but the box still shows "${shownChoice(trigger) || "nothing"}"`, "didnt_stick");
      } catch (error) {
        last2 = error instanceof FillError ? error : new FillError(error instanceof Error ? error.message : "couldn't fill", "error");
        if (last2.problem === "no_option" && !(trigger instanceof HTMLInputElement && options2.type) || last2.problem === "more_choices") break;
      }
    }
    throw last2 ?? new FillError("couldn't fill", "error");
  }
  function ownedList(trigger) {
    const ids = `${trigger.getAttribute("aria-controls") ?? ""} ${trigger.getAttribute("aria-owns") ?? ""}`.trim().split(/\s+/).filter(Boolean);
    for (const id of ids) {
      const el = trigger.getRootNode().getElementById(id) ?? document.getElementById(id);
      if (el) return el;
    }
    return null;
  }
  var multiSelect = (trigger) => trigger.getAttribute("aria-multiselectable") === "true" || Boolean(trigger.closest("[aria-multiselectable='true'], [class*='multi']"));
  function close(trigger) {
    trigger.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", bubbles: true }));
  }
  function attachFile(input, file) {
    const bytes = Uint8Array.from(atob(file.base64), (char) => char.charCodeAt(0));
    const transfer = new DataTransfer();
    transfer.items.add(new File([bytes], file.name, { type: file.mime }));
    input.files = transfer.files;
    input.dispatchEvent(new Event("input", { bubbles: true, composed: true }));
    input.dispatchEvent(new Event("change", { bubbles: true, composed: true }));
  }
  var YES = /^(yes|true|y|1|i agree|agree|checked)$/i;

  // extension/src/content/actions.ts
  var SUBMIT = /^(submit( (my )?application)?|send( my)? application|complete( my)? application|submit (and|&) apply|finish( application)?)$/i;
  var APPLY_SUBMIT = /^apply( now)?$/i;
  var NEXT = /^(next|continue|proceed|save (and|&) (continue|next|proceed))\b[^.?!]{0,32}$|^(next|continue) ?[›>]$/i;
  var NOT_NEXT = /\b(with|using|via) (linkedin|google|indeed|facebook|apple|microsoft|seek|email)\b|sign ?in|log ?in|shopping/i;
  var APPLY = /^(apply( now| for this (job|position|role|opportunity)| here| online| today)?|i(?:'|’)?m interested|start (my |your )?application|begin application|apply manually)$/i;
  var CREATE = /^(create (an |my |your )?account|register|sign up|create account (and|&) continue)$/i;
  var SIGN_IN = /^(sign in|log ?in)$/i;
  var text = (el) => (el.textContent || el.value || el.getAttribute("aria-label") || "").replace(/\s+/g, " ").trim();
  function usable(el) {
    if (!el) return false;
    const rect = el.getBoundingClientRect();
    if (rect.width < 4 || rect.height < 4) return false;
    if (el.disabled || el.getAttribute("aria-disabled") === "true") return false;
    const style = getComputedStyle(el);
    return style.visibility !== "hidden" && style.display !== "none";
  }
  var byId = (id) => Array.from(document.querySelectorAll(`[data-automation-id='${id}']`)).find(usable) ?? null;
  var BACKWARD = /^(back|previous|go back|prev)\b/i;
  var BACKWARD_ID = /back|previous|prev\b/i;
  function goesBack(el) {
    const id = el.closest("[data-automation-id]")?.getAttribute("data-automation-id") ?? "";
    return BACKWARD.test(text(el)) || BACKWARD_ID.test(id) || Boolean(el.closest("[data-automation-id^='progressBar']"));
  }
  function buttons() {
    return deepAll("button, input[type=submit], input[type=button], a, [role=button]", openDialog() ?? document).filter(usable).filter((el) => !el.closest("header, footer, nav, [data-automation-id='utilityButtonBar'], [role=banner], [role=navigation]")).filter((el) => !goesBack(el));
  }
  function workdayStep() {
    const active = Array.from(document.querySelectorAll("[data-automation-id='progressBarActiveStep']")).find(usable);
    if (!active) return null;
    const words2 = (active.textContent ?? "").replace(/\s+/g, " ").trim();
    const found = words2.match(/step (\d+) of (\d+)\s*(.*)$/i);
    if (!found) return null;
    const heading = Array.from(document.querySelectorAll("[data-automation-id*='pageHeader' i], main h2, [role=main] h2, h2")).find((el) => el.getBoundingClientRect().height > 0 && Boolean(el.textContent?.trim()));
    const name = found[3].trim() || active.getAttribute("aria-label")?.match(/step \d+ of \d+\s*(.*)$/i)?.[1]?.trim() || (heading?.textContent ?? "").replace(/\s+/g, " ").trim();
    return { index: Number(found[1]), total: Number(found[2]), name: name.slice(0, 80) };
  }
  var find = (pattern) => buttons().find((el) => pattern.test(text(el))) ?? null;
  function findAction(knownAccount, formFields) {
    const passwords = deepAll("input[type=password]").filter(usable).length;
    const make2 = (kind, el) => el ? { kind, label: text(el) || kind, el } : null;
    const createSubmit = byId("createAccountSubmitButton");
    if (createSubmit) return knownAccount && byId("signInLink") ? make2("sign_in", byId("signInLink")) : make2("create_account", createSubmit);
    const signInSubmit = byId("signInSubmitButton");
    if (signInSubmit) return !knownAccount && byId("createAccountLink") ? make2("create_account", byId("createAccountLink")) : make2("sign_in", signInSubmit);
    if (passwords >= 2) {
      const create = find(CREATE);
      if (create) return make2("create_account", create);
    }
    if (passwords === 1) {
      const signIn = knownAccount ? find(SIGN_IN) : find(CREATE) ?? find(SIGN_IN);
      if (signIn) return make2(CREATE.test(text(signIn)) ? "create_account" : "sign_in", signIn);
    }
    const footer = [byId("bottom-navigation-next-button"), byId("pageFooterNextButton")].find((el) => el && !goesBack(el)) ?? null;
    if (footer) return make2(SUBMIT.test(text(footer)) ? "submit" : "next", footer);
    const next = buttons().find((el) => NEXT.test(text(el)) && !NOT_NEXT.test(text(el))) ?? null;
    if (next) return make2("next", next);
    const submit = find(SUBMIT) ?? (formFields >= 3 ? find(APPLY_SUBMIT) : null);
    if (submit) return make2("submit", submit);
    if (formFields < 3 && !inApplication()) {
      const apply = byId("applyManually") ?? byId("adventureButton") ?? find(APPLY);
      if (apply) return make2("apply", apply);
    }
    return null;
  }
  function findApply() {
    if (inApplication()) return null;
    const known = byId("applyManually") ?? byId("adventureButton");
    if (known) return known;
    return buttons().find((el) => {
      if (!APPLY.test(text(el))) return false;
      const form = el.closest("form");
      const isSubmit = el.type === "submit" || el.matches("input[type=submit]");
      return !(form && (isSubmit || form.querySelectorAll("input:not([type=hidden]), select, textarea").length >= 3));
    }) ?? null;
  }
  function inApplication() {
    if (/\/apply(\/|$|\?)/.test(location.pathname + location.search) && !byId("applyManually")) return true;
    if (byId("bottom-navigation-next-button") || byId("pageFooterNextButton") || byId("progressBar") || byId("progressBarActiveStep")) return true;
    return Boolean(document.querySelector("[data-automation-id^='progressBar']"));
  }
  function overlayOn(el) {
    const rect = el.getBoundingClientRect();
    if (rect.width < 1 || rect.height < 1) return null;
    const x = rect.left + rect.width / 2;
    const y = rect.top + rect.height / 2;
    const root = el.getRootNode();
    const hits = "elementsFromPoint" in root ? root.elementsFromPoint(x, y) : document.elementsFromPoint(x, y);
    const overlay = hits.find((hit) => hit.matches("[data-automation-id='click_filter']"));
    if (!overlay || !usable(overlay)) return null;
    const box = overlay.getBoundingClientRect();
    return box.left <= x && x <= box.right && box.top <= y && y <= box.bottom ? overlay : null;
  }
  function pressAction(el) {
    if (goesBack(el)) return null;
    el.scrollIntoView({ block: "center" });
    const overlay = overlayOn(el);
    press(overlay ?? el);
    return { label: text(el).slice(0, 80), id: el.getAttribute("data-automation-id") ?? "", overlay: Boolean(overlay) };
  }
  function buttonUnder(overlay) {
    const box = overlay.getBoundingClientRect();
    const hits = document.elementsFromPoint(box.left + box.width / 2, box.top + box.height / 2);
    return hits.find((hit) => hit !== overlay && hit.matches("button, [role=button]")) ?? null;
  }
  var ERROR_WORDS = /\b(error|errors|invalid|incorrect|please (check|correct|fix|review|complete|enter|fill|select|provide|try)|(is|are) required|required (field|information)|must (be|contain|enter|select|have)|not all (fields|required|questions)|(field|fields|information) (is|are)? ?(missing|incomplete)|couldn(?:'|’)?t (be )?(saved|submitted|processed)|try again)\b/i;
  var NOT_ERROR = /indicates (a )?required|required fields? (are|is) marked|^\*?\s*required\s*$|^\*$|fields marked with/i;
  var ERROR_PLACES = "[role=alert], [role=alertdialog], [aria-live=assertive], [aria-live=polite], [data-automation-id*='error' i], [class*='error' i], [class*='invalid' i], [class*='alert' i], [class*='toast' i], [class*='notification' i]";
  var shownNow = (el) => {
    const rect = el.getBoundingClientRect();
    const style = getComputedStyle(el);
    return rect.width > 0 && rect.height > 0 && style.display !== "none" && style.visibility !== "hidden" && style.opacity !== "0";
  };
  function formErrors() {
    const seen = /* @__PURE__ */ new Set();
    for (const el of deepAll(ERROR_PLACES)) {
      if (el.closest("[data-unnepo-spiders], [data-unnepo-launcher]") || !shownNow(el)) continue;
      const words2 = (el.innerText || el.textContent || "").replace(/\s+/g, " ").trim();
      if (words2.length < 3 || words2.length > 300 || !ERROR_WORDS.test(words2) || NOT_ERROR.test(words2)) continue;
      if ([...seen].some((known) => words2.includes(known) || known.includes(words2))) continue;
      seen.add(words2);
      if (seen.size >= 3) break;
    }
    return [...seen];
  }
  function flaggedFields() {
    const labels = /* @__PURE__ */ new Set();
    for (const el of deepAll("[aria-invalid='true']")) if (shownNow(el)) labels.add(questionText(el));
    for (const message of deepAll(ERROR_PLACES)) {
      if (!shownNow(message) || !ERROR_WORDS.test(message.textContent ?? "")) continue;
      let node = message;
      for (let depth = 0; node && depth < 4; depth += 1, node = parentOf(node)) {
        const controls = Array.from(node.querySelectorAll("input:not([type=hidden]), select, textarea, button[aria-haspopup='listbox']"));
        if (controls.length === 1) {
          labels.add(questionText(controls[0]));
          break;
        }
        if (controls.length > 1) break;
      }
    }
    return [...labels].filter(Boolean).slice(0, 8);
  }
  function valuesKey() {
    return scanFields().map((field) => {
      const el = findMarked(field.id);
      const control = el && (el.matches("input, select, textarea, button") ? el : el.querySelector("input, select, textarea, button"));
      if (!control) return "";
      if (control instanceof HTMLInputElement && (control.type === "checkbox" || control.type === "radio")) return String(control.checked);
      return "value" in control ? String(control.value) : (control.textContent ?? "").trim();
    }).join("|");
  }
  function pageNotes() {
    const alerts = Array.from(document.querySelectorAll("[role=alert], [aria-live=assertive], [data-automation-id*='error' i], [class*='error' i]")).map((el) => el.innerText || "").join(" ");
    const body = (document.body.innerText || "").replace(/\s+/g, " ");
    return {
      accountExists: /(already|previously) (been )?(registered|exists?|in use|taken)|account (already )?exists|email address is already|already have an account/i.test(alerts),
      // "You may have entered the wrong email address or password or your account might be locked."
      signInFailed: /wrong (email|e-mail|username|password)|(email|username|password)( address)? (or password )?(is |was )?(incorrect|invalid|not recogni[sz]ed)|incorrect (email|e-mail|username|password)|invalid (email|username|password|credentials|login)|account (might be|may be|is|has been) locked|couldn(?:'|’)?t sign you in|sign[- ]?in (failed|unsuccessful)|unable to sign in|login failed/i.test(`${alerts} ${deepAll("input[type=password]").length ? body : ""}`),
      verifyEmail: /verify your (email|account)|verification (email|link|code)|check your (email|inbox)|confirm your email/i.test(body) && !document.querySelector("input:not([type=hidden])"),
      confirmed: CONFIRM_TEXT.test(body),
      formErrors: formErrors(),
      flagged: flaggedFields(),
      valuesKey: valuesKey()
    };
  }

  // extension/src/content/generic.ts
  var COVER_LETTER = /cover ?letter|letter of (interest|motivation)|motivation(al)? letter/i;
  var RESUME = /r[eé]sum[eé]|\bcv\b|curriculum vitae/i;
  var OTHER_DOCUMENT = /transcript|portfolio|writing sample|work sample|photo|picture|headshot|certificat|licen[cs]e|\bid\b|identification|reference|recommendation/i;
  function fileFor(field, files) {
    const words2 = `${field.label} ${field.section}`;
    if (COVER_LETTER.test(field.label)) return files.coverLetter;
    if (RESUME.test(words2)) return files.resume;
    return OTHER_DOCUMENT.test(words2) ? null : files.resume;
  }
  var uploadedHere = /* @__PURE__ */ new Set();
  function alreadyUploaded(field) {
    if (uploadedHere.has(`${location.pathname}|${field.label}`)) return true;
    const el = findMarked(field.id);
    if (!el) return false;
    if (!isEmpty(el)) return true;
    let box = el.parentElement;
    for (let depth = 0; box && depth < 6; depth += 1, box = box.parentElement) {
      if (box.querySelector("[data-automation-id*='file-upload-item' i], [data-automation-id*='fileName' i], [data-automation-id*='uploaded' i], [data-automation-id='delete-file']")) return true;
      if (/successfully uploaded|[\w)-]\.(pdf|docx?|rtf)\b/i.test(box.innerText ?? "")) return true;
      if (box.querySelectorAll("input[type=file]").length > 1) break;
    }
    return false;
  }
  function uploadPlan(fields, files) {
    const boxes = fields.filter((field) => field.type === "file");
    const named = boxes.some((field) => RESUME.test(`${field.label} ${field.section}`));
    let generic = 0;
    return new Set(boxes.filter((field) => {
      if (alreadyUploaded(field)) return false;
      const file = fileFor(field, files);
      if (!file) return false;
      if (file !== files.resume || RESUME.test(`${field.label} ${field.section}`)) return true;
      return !named && generic++ === 0;
    }).map((field) => field.id));
  }
  function pickLabel(answer, labels) {
    return answerChoices(answer).map((candidate) => bestOption(candidate, labels)).find(Boolean) ?? null;
  }
  var COUNTRY_CODE = /country (phone )?code|phone (country )?code|dialing code|^country code$|calling code/i;
  var PHONE_NUMBER = /\b(phone|mobile|cell)\b/i;
  function nationalNumber(value) {
    const trimmed = value.trim();
    let digits = trimmed.replace(/\D/g, "");
    if (trimmed.startsWith("+")) {
      const code = trimmed.match(/^\+(\d{1,3})[\s.\-(]/)?.[1] ?? (digits.startsWith("1") && digits.length === 11 ? "1" : "");
      if (code) digits = digits.slice(code.length);
    } else if (digits.length === 11 && digits.startsWith("1")) {
      digits = digits.slice(1);
    }
    return digits;
  }
  var separateCountryCode = false;
  var dropdownWays = waysFrom();
  var TEXT_WAYS = ["set", "keys"];
  var CHECK_WAYS = ["press", "label"];
  function pressLabel(input) {
    const label = (input.id ? rootOf(input).querySelector(`label[for="${CSS.escape(input.id)}"]`) : null) ?? input.closest("label");
    press(label ?? input);
  }
  var LINK_FIELD = /linked ?in|github|portfolio|website|\burl\b|web ?site|personal site|profile link/i;
  var SKILLS = /^(type to add )?skills?\b/i;
  function valueFor(field, answer) {
    const value = answer.values[0] ?? "";
    if ((field.type === "url" || field.type === "text" && LINK_FIELD.test(field.label)) && /^(www\.)?[\w-]+(\.[\w-]+)+(\/\S*)?$/i.test(value.trim())) return `https://${value.trim()}`;
    if (separateCountryCode && (field.type === "tel" || PHONE_NUMBER.test(field.label)) && !COUNTRY_CODE.test(field.label) && !/type|extension|\bext\b/i.test(field.label) && field.type !== "select" && field.type !== "combobox") {
      return nationalNumber(value) || value;
    }
    return value;
  }
  function chosenRadio(el, value) {
    const name = el.name;
    const radios = Array.from(rootOf(el).querySelectorAll(`input[type=radio][name="${CSS.escape(name)}"]`));
    const labels = radios.map(labelOf);
    const choice = pickLabel(value, labels);
    if (!choice) throw new FillError(`no option matching "${value}"`, "no_option", labels.filter(Boolean).slice(0, 100));
    return radios[labels.indexOf(choice)];
  }
  async function fillOne(field, answer, files, way) {
    const el = findMarked(field.id);
    if (!el) throw new FillError("not on the page", "not_on_page");
    const value = valueFor(field, answer);
    switch (field.type) {
      case "radio": {
        if (way >= CHECK_WAYS.length) return null;
        const radio = chosenRadio(el, value);
        if (way === 0) press(radio);
        else pressLabel(radio);
        return CHECK_WAYS[way];
      }
      case "checkbox": {
        if (way >= CHECK_WAYS.length) return null;
        const box = el;
        if (YES.test(value) !== box.checked) (way === 0 ? press : pressLabel)(box);
        return CHECK_WAYS[way];
      }
      case "multiselect": {
        if (way >= CHECK_WAYS.length) return null;
        for (const box of Array.from(el.querySelectorAll("input[type=checkbox]"))) {
          const wanted = answer.values.some((chosen) => pickLabel(chosen, [labelOf(box)]));
          if (wanted !== box.checked) (way === 0 ? press : pressLabel)(box);
        }
        return CHECK_WAYS[way];
      }
      case "select":
        if (way > 0) return null;
        chooseNativeSelect(el, value);
        return "select";
      case "combobox": {
        const skills = SKILLS.test(field.label.trim()) ? answer.values.flatMap((item) => item.split(/\n|,|;/)).map((item) => item.trim()).filter(Boolean) : [];
        if (skills.length > 1) {
          if (way > 0) return null;
          const missing = [];
          for (const skill of skills.slice(0, 15)) {
            try {
              await chooseCustom(el, skill, { type: el instanceof HTMLInputElement ? skill : void 0, ways: dropdownWays });
            } catch {
              missing.push(skill);
            }
          }
          if (missing.length === skills.length) throw new FillError(`none of the skills were in the site's list (${missing.slice(0, 5).join(", ")})`, "no_option");
          return missing.length ? `added ${skills.length - missing.length} of ${skills.length} skills` : "each skill";
        }
        if (way > 1) return null;
        const ways = way === 0 ? dropdownWays : [...dropdownWays].reverse();
        return chooseCustom(el, value, { type: el instanceof HTMLInputElement ? value : void 0, ways });
      }
      case "file": {
        if (way > 0) return null;
        const file = fileFor(field, files);
        if (!file) throw new FillError("no file", "no_file");
        attachFile(el, file);
        return "upload";
      }
      default: {
        if (way >= TEXT_WAYS.length) return null;
        const box = el;
        if (way === 0) typeInto(box, value);
        else await typeKeys(box, value);
        return TEXT_WAYS[way];
      }
    }
  }
  function readBack(field, answer) {
    const el = findMarked(field.id);
    if (!el) return "it went from the page";
    const value = valueFor(field, answer);
    switch (field.type) {
      case "radio":
        return rootOf(el).querySelector(`input[type=radio][name="${CSS.escape(el.name)}"]:checked`) ? null : "no choice is selected";
      case "checkbox":
        return el.checked === YES.test(value) ? null : "the box didn't change";
      case "multiselect": {
        const boxes = Array.from(el.querySelectorAll("input[type=checkbox]"));
        const wrong = boxes.filter((box) => answer.values.some((chosen) => pickLabel(chosen, [labelOf(box)])) !== box.checked);
        return wrong.length ? `${wrong.length} box${wrong.length === 1 ? "" : "es"} didn't change` : null;
      }
      case "select":
        return isEmpty(el) ? "the list still shows no choice" : null;
      case "combobox":
        return shownChoice(el) === "" ? "the box shows no choice" : null;
      case "file":
        return isEmpty(el) ? "the page shows no file" : null;
      default: {
        const shown2 = el.value.trim();
        if (!shown2) return "the box is empty";
        return sameText(field, shown2, value);
      }
    }
  }
  var letters = (text2) => text2.replace(/[^\p{L}\p{N}]/gu, "");
  function sameText(field, shown2, value) {
    const [a, b] = [letters(shown2), letters(value)];
    const [low, want] = [a.toLowerCase(), b.toLowerCase()];
    if (!want || low.includes(want) || low.length >= 20 && want.startsWith(low)) {
      return /name/i.test(field.label) && low === want && a !== b ? `the site shows "${shown2.slice(0, 40)}" in other capitals` : null;
    }
    return "the site put back other text";
  }
  function brief(field, value) {
    if (!["select", "combobox", "radio", "checkbox", "multiselect"].includes(field.type)) return "";
    const words2 = value.split(/\s+/).filter(Boolean);
    const short = words2.slice(0, 6).join(" ");
    return (words2.length > 6 ? `${short}\u2026` : short).slice(0, 60);
  }
  async function fillChecked(field, answer, files, from = 0) {
    let problem = "";
    for (let way = from; ; way += 1) {
      const method = await fillOne(field, answer, files, way);
      if (!method) throw new FillError(problem ? `${problem}, however it was filled` : "couldn't fill", "didnt_stick");
      problem = readBack(field, answer) ?? "";
      if (!problem) return { method, way };
    }
  }
  async function fillGeneric(fields, answers, files, options2 = {}) {
    const filled = [];
    const failed = [];
    const attempts = [];
    const byId3 = new Map(answers.map((answer) => [answer.id, answer]));
    const ordered = [...fields.filter((field) => field.type === "file"), ...fields.filter((field) => field.type !== "file")];
    const uploads = uploadPlan(fields, files);
    separateCountryCode = fields.some((field) => COUNTRY_CODE.test(field.label));
    dropdownWays = options2.dropdownWays ?? waysFrom(options2.dropdownFirst);
    const site = location.hostname;
    const done = [];
    const fail = (field, attempt, error) => {
      const known = error instanceof FillError ? error : null;
      attempt.ok = false;
      attempt.problem = known?.problem ?? "error";
      attempt.reason = (error instanceof Error ? error.message : "couldn't fill").slice(0, 200);
      failed.push({ label: field.label, reason: attempt.reason, id: field.id, ...known?.problem === "no_option" && known.options.length ? { options: known.options } : {} });
    };
    let uploaded = false;
    for (const field of ordered) {
      if (uploaded && field.type !== "file") {
        uploaded = false;
        await settleAfterUpload();
      }
      const given = byId3.get(field.id);
      const isFile = field.type === "file";
      if (isFile ? !uploads.has(field.id) : !given?.values.length) continue;
      const answer = given ?? { id: field.id, label: field.label, type: field.type, required: field.required, values: [field.label], source: null, why: null };
      const attempt = { site, label: field.label.slice(0, 200), type: field.type, answer: brief(field, answer.values.join(", ")), method: "", ok: true };
      attempts.push(attempt);
      try {
        const { method, way } = await fillChecked(field, answer, files);
        attempt.method = method;
        done.push({ field, answer, way, attempt });
        if (field.type === "file") {
          uploaded = true;
          uploadedHere.add(`${location.pathname}|${field.label}`);
        }
      } catch (error) {
        fail(field, attempt, error);
      }
    }
    if (done.length) await sleep(250);
    for (const item of done) {
      if (!readBack(item.field, item.answer)) continue;
      try {
        const { method } = await fillChecked(item.field, item.answer, files, item.way + 1);
        item.attempt.method = `${item.attempt.method}, then ${method}`;
      } catch (error) {
        fail(item.field, item.attempt, error);
        item.attempt.reason = `cleared after filling: ${item.attempt.reason}`;
      }
    }
    for (const item of done) if (item.attempt.ok) filled.push(item.field.label);
    return { filled, failed, attempts };
  }
  var READING = /(analy[sz]ing|parsing|uploading|reading|processing|scanning) (your )?(r[eé]sum[eé]|cv|file|document)|autofill(ing)? (in progress|your application)/i;
  async function settleAfterUpload() {
    await sleep(700);
    const until = Date.now() + 6e3;
    while (Date.now() < until && READING.test(document.body.innerText || "")) await sleep(250);
  }
  function uploadResumeNow(fields, resume) {
    const files = { resume, coverLetter: null };
    const plan = uploadPlan(fields, files);
    const done = [];
    for (const field of fields) {
      if (field.type !== "file" || !plan.has(field.id)) continue;
      const el = findMarked(field.id);
      if (!(el instanceof HTMLInputElement)) continue;
      try {
        attachFile(el, resume);
        uploadedHere.add(`${location.pathname}|${field.label}`);
        done.push(field.label);
      } catch {
      }
    }
    return done;
  }
  var EXTRA_DOCUMENT = /additional (documents?|files?|attachments?|information)|supporting documents?|other (documents?|files?|attachments?)|attachments?$|optional (documents?|files?)/i;
  function uploadCoverLetterNow(fields, letter) {
    const boxes = fields.filter((field) => field.type === "file" && !alreadyUploaded(field));
    const named = boxes.filter((field) => COVER_LETTER.test(`${field.label} ${field.section}`));
    const extra = boxes.find((field) => EXTRA_DOCUMENT.test(`${field.label} ${field.section}`) && !RESUME.test(field.label));
    const done = [];
    for (const field of named.length ? named : extra ? [extra] : []) {
      const el = findMarked(field.id);
      if (!(el instanceof HTMLInputElement)) continue;
      try {
        attachFile(el, letter);
        uploadedHere.add(`${location.pathname}|${field.label}`);
        done.push(field.label);
      } catch {
      }
    }
    return done;
  }

  // extension/src/content/greenhouse.ts
  var byId2 = (id) => document.getElementById(id);
  var options = (id) => () => Array.from(document.querySelectorAll(`[id^="react-select-${CSS.escape(id)}-option-"]`));
  function greenhouseValue(id, type) {
    if (type === "multiselect") return document.getElementById(id)?.querySelector("input[type=checkbox]:checked") ? "checked" : "";
    const el = byId2(id);
    if (!el) return "";
    if (el.type === "file") return el.files?.length ? el.files[0].name : "";
    if (el.getAttribute("role") === "combobox") return el.closest(".select")?.querySelector("[class*='single-value'], [class*='multi-value']")?.textContent?.trim() ?? "";
    return el.value.trim();
  }
  async function fillOne2(answer, files) {
    const value = answer.values[0] ?? "";
    const el = byId2(answer.id);
    switch (answer.type) {
      case "text":
      case "email":
      case "tel":
      case "textarea":
        if (!(el instanceof HTMLInputElement || el instanceof HTMLTextAreaElement)) throw new FillError("not on the page", "not_on_page");
        typeInto(el, value);
        return;
      case "file": {
        const file = answer.id === "cover_letter" ? files.coverLetter : files.resume;
        if (!(el instanceof HTMLInputElement) || !file) throw file ? new FillError("not on the page", "not_on_page") : new FillError("no file", "no_file");
        attachFile(el, file);
        return;
      }
      case "multiselect": {
        const group = el ?? document.getElementById(`${answer.id}`);
        if (!group) throw new FillError("not on the page", "not_on_page");
        for (const box of Array.from(group.querySelectorAll("input[type=checkbox]"))) {
          const wanted = answer.values.some((chosen) => bestOption(chosen, [labelOf(box)]));
          if (wanted !== box.checked) press(box);
        }
        return;
      }
      case "phone_country":
        if (!(el instanceof HTMLInputElement)) throw new FillError("not on the page", "not_on_page");
        return chooseCustom(el, value, { type: value, list: options(answer.id), pick: (texts) => texts.find((text2) => text2.toLowerCase().startsWith(value.toLowerCase())) ?? bestOption(value, texts) });
      case "location": {
        if (!(el instanceof HTMLInputElement)) throw new FillError("not on the page", "not_on_page");
        const [city, state] = value.split(",").map((part) => part.trim());
        return chooseCustom(el, value, { type: city, list: options(answer.id), pick: (texts) => texts.find((text2) => text2.toLowerCase().startsWith(city.toLowerCase()) && (!state || text2.toLowerCase().includes(state.toLowerCase()))) ?? (texts.length === 1 ? texts[0] : null) });
      }
      case "school":
        if (!(el instanceof HTMLInputElement)) throw new FillError("not on the page", "not_on_page");
        return chooseCustom(el, value, { type: value, list: options(answer.id), pick: (texts) => bestOption(value, texts) ?? texts.find((text2) => /^other$/i.test(text2)) ?? null });
      case "degree":
        if (!(el instanceof HTMLInputElement)) throw new FillError("not on the page", "not_on_page");
        return chooseCustom(el, value, { list: options(answer.id), pick: (texts) => degreeAnswer(value, texts) });
      default:
        if (!(el instanceof HTMLInputElement)) throw new FillError("not on the page", "not_on_page");
        return chooseCustom(el, value, { list: options(answer.id) });
    }
  }
  async function greenhouseReady() {
    await waitFor(() => {
      const el = byId2("first_name");
      return Boolean(el && Object.keys(el).some((key2) => key2.startsWith("__react")));
    }, 5e3);
  }
  async function fillGreenhouse(answers, files) {
    await greenhouseReady();
    const filled = [];
    const failed = [];
    const attempts = [];
    if (files.resume && byId2("resume") && !answers.some((answer) => answer.id === "resume")) {
      answers = [...answers, { id: "resume", label: "Resume/CV", type: "file", required: true, values: [files.resume.name], source: "resume_file", why: null }];
    }
    for (const answer of answers) {
      if (!answer.values.length) continue;
      if (!byId2(answer.id)) continue;
      const attempt = { site: location.hostname, label: answer.label.slice(0, 200), type: answer.type, answer: answer.type === "select" || answer.type === "multiselect" ? answer.values.join(", ").slice(0, 60) : "", method: "greenhouse", ok: true };
      attempts.push(attempt);
      try {
        attempt.method = await fillOne2(answer, files) ?? "greenhouse";
        filled.push(answer.label);
      } catch (error) {
        const known = error instanceof FillError ? error : null;
        Object.assign(attempt, { ok: false, problem: known?.problem ?? "error", reason: (error instanceof Error ? error.message : "couldn't fill").slice(0, 200) });
        failed.push({ label: answer.label, reason: attempt.reason, id: answer.id });
      }
    }
    for (const answer of answers) {
      if (!["text", "email", "tel", "textarea"].includes(answer.type) || !filled.includes(answer.label) || greenhouseValue(answer.id, answer.type)) continue;
      const el = byId2(answer.id);
      if (el instanceof HTMLInputElement || el instanceof HTMLTextAreaElement) typeInto(el, answer.values[0]);
    }
    return { filled, failed, attempts };
  }

  // extension/src/content/edits.ts
  var EDITED = "data-unnepo-edited";
  var opened = null;
  var fieldOf = (el) => el.closest("[data-unnepo-id]") ?? el;
  function touch(el) {
    el.setAttribute(EDITED, "");
    fieldOf(el).setAttribute(EDITED, "");
    if (el instanceof HTMLInputElement && (el.type === "radio" || el.type === "checkbox") && el.name) {
      const root = el.getRootNode();
      root.querySelectorAll(`input[name="${CSS.escape(el.name)}"]`).forEach((item) => item.setAttribute(EDITED, ""));
    }
  }
  function targetOf(event) {
    const target = event.composedPath()[0];
    return target instanceof Element ? target : null;
  }
  function watchEdits() {
    if (window.__unnepoEdits) return;
    window.__unnepoEdits = true;
    const onEdit = (event) => {
      const target = targetOf(event);
      if (event.isTrusted && target?.matches("input, select, textarea, [contenteditable]")) touch(target);
    };
    document.addEventListener("input", onEdit, true);
    document.addEventListener("change", onEdit, true);
    document.addEventListener("pointerdown", (event) => {
      const target = targetOf(event);
      if (!event.isTrusted || !target) return;
      const option = target.closest("[role=option], [data-automation-id*='promptOption' i]");
      if (option) {
        if (opened?.isConnected) touch(opened);
      } else {
        opened = target.closest("[data-unnepo-id], [role=combobox], [aria-haspopup=listbox]");
      }
    }, true);
    document.addEventListener("keydown", (event) => {
      const target = targetOf(event);
      if (event.isTrusted && target && event.key === "Enter" && target.closest("[role=combobox], [aria-haspopup=listbox]")) touch(target);
    }, true);
  }
  function editedByStudent(el) {
    return Boolean(el.closest(`[${EDITED}]`) || el.querySelector(`[${EDITED}]`));
  }

  // extension/src/shared/applied-line.ts
  var MONTHS = ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"];
  var MONTH2 = "(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\\.?";
  var WHEN2 = `(${MONTH2} \\d{1,2}(?:st|nd|rd|th)?(?:,? \\d{4})?|\\d{1,2}/\\d{1,2}(?:/\\d{2,4})?|\\d{4}-\\d{2}-\\d{2}|\\d+ ?(?:s|sec|seconds?|m|mins?|minutes?|h|hrs?|hours?|d|days?|w|wks?|weeks?|mo|months?) ago|today|yesterday|just now)`;
  var APPLIED_LINE = new RegExp(`^([\u2713\u2714\u2611]\\s*)?(you )?(applied|application (?:submitted|sent|received)|submitted)[\\s:\xB7\u2022,-]*(on\\s+)?${WHEN2}\\.?$`, "i");
  var APPLIED_BARE = /^([✓✔☑]\s*)?(applied|already applied|you(?:'|’)ve applied|application (submitted|sent))!?$/i;
  function appliedDay(text2, now = /* @__PURE__ */ new Date()) {
    const iso = (date) => `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
    const lower = text2.toLowerCase();
    if (/\b(today|just now|\d+ ?(s|sec|seconds?|m|mins?|minutes?|h|hrs?|hours?) ago)\b/.test(lower)) return iso(now);
    if (/\byesterday\b/.test(lower)) return iso(new Date(now.getFullYear(), now.getMonth(), now.getDate() - 1));
    const ago = lower.match(/\b(\d+) ?(d|days?|w|wks?|weeks?|mo|months?) ago\b/);
    if (ago) {
      const n = Number(ago[1]);
      const days = /^d/.test(ago[2]) ? n : /^w/.test(ago[2]) ? n * 7 : n * 30;
      return iso(new Date(now.getFullYear(), now.getMonth(), now.getDate() - days));
    }
    const isoDay = lower.match(/\b(\d{4})-(\d{2})-(\d{2})\b/);
    if (isoDay) return `${isoDay[1]}-${isoDay[2]}-${isoDay[3]}`;
    const named = lower.match(new RegExp(`\\b${MONTH2} (\\d{1,2})(?:st|nd|rd|th)?(?:,? (\\d{4}))?`));
    if (named) {
      const month = MONTHS.indexOf(named[1].slice(0, 3));
      let date = new Date(named[3] ? Number(named[3]) : now.getFullYear(), month, Number(named[2]));
      if (!named[3] && date.getTime() > now.getTime() + 864e5) date = new Date(now.getFullYear() - 1, month, Number(named[2]));
      return iso(date);
    }
    const slash = lower.match(/\b(\d{1,2})\/(\d{1,2})(?:\/(\d{2,4}))?\b/);
    if (slash) {
      const year = slash[3] ? slash[3].length === 2 ? 2e3 + Number(slash[3]) : Number(slash[3]) : now.getFullYear();
      return iso(new Date(year, Number(slash[1]) - 1, Number(slash[2])));
    }
    return "";
  }

  // extension/src/content/board-status.ts
  var clean2 = (text2) => (text2 ?? "").replace(/\s+/g, " ").trim();
  var shown = (el) => el.getBoundingClientRect().height > 0;
  function appliedStatus(root = jobPane()) {
    const candidates = Array.from(root.querySelectorAll("span, p, div, li, time, strong, small, button, a, [role=status], [role=button], h2, h3, h4, h5")).filter((el) => !el.closest("[role=dialog], [aria-modal='true'], dialog"));
    for (const el of candidates) {
      const text2 = clean2(el.innerText || el.textContent);
      if (!text2 || text2.length > 70 || !shown(el)) continue;
      if (APPLIED_LINE.test(text2)) return { text: text2, day: appliedDay(text2) };
      const control = el.matches("button, a, [role=button], [role=status]") || el.getAttribute("aria-disabled") === "true" || el.disabled;
      if (control && APPLIED_BARE.test(text2)) return { text: text2, day: "" };
    }
    return null;
  }

  // extension/src/content/kept.ts
  function keptByStudent(answer, useServerSchema) {
    if (answer.type === "file") return false;
    const el = useServerSchema ? document.getElementById(answer.id) : findMarked(answer.id);
    if (!el || !editedByStudent(el)) return false;
    if (useServerSchema) return Boolean(greenhouseValue(answer.id, answer.type));
    const control = el.matches("input, select, textarea, button") ? el : el.querySelector("input") ?? el;
    return !isEmpty(control);
  }

  // extension/src/content/needs.ts
  var COLOR = "#FF8A3D";
  var CHECK = "#3D8BFF";
  var marked = [];
  var host = null;
  var lastSet = "";
  var current = 0;
  var listening = false;
  var reviewed = /* @__PURE__ */ new Map();
  var pageReviewed = () => {
    const key2 = location.href;
    if (!reviewed.has(key2)) reviewed.set(key2, /* @__PURE__ */ new Set());
    return reviewed.get(key2);
  };
  var hadItems = false;
  function fieldControl(label) {
    const fields = scanFields();
    const wanted = label.trim().toLowerCase();
    const field = fields.find((item) => item.label.toLowerCase() === wanted) ?? fields.find((item) => item.label.toLowerCase().startsWith(wanted));
    const el = field ? findMarked(field.id) : null;
    if (!el) return null;
    return el.matches("input, select, textarea, button") ? el : el.querySelector("input, select, textarea, button") ?? el;
  }
  var outlined = (control) => control instanceof HTMLInputElement && (control.type === "radio" || control.type === "checkbox") ? control.closest("fieldset, [role=radiogroup], [role=group]") ?? control : control;
  function unmark(item) {
    const box = outlined(item.control);
    Object.assign(box.style, item.before);
    box.removeAttribute("data-unnepo-needs");
  }
  function scrollTo(control) {
    const reduce = matchMedia("(prefers-reduced-motion: reduce)").matches;
    outlined(control).scrollIntoView({ block: "center", behavior: reduce ? "auto" : "smooth" });
  }
  function reviewLeft() {
    return marked.filter((item) => item.kind === "check").length;
  }
  function goTo(index) {
    if (!marked.length) return;
    current = (index % marked.length + marked.length) % marked.length;
    const { control } = marked[current];
    scrollTo(control);
    setTimeout(() => control.focus({ preventScroll: true }), 300);
    drawBar();
  }
  function looksRight() {
    const item = marked[current];
    if (!item) return;
    if (item.kind === "check") {
      pageReviewed().add(item.label);
      unmark(item);
      marked.splice(current, 1);
    } else current += 1;
    if (marked.length) goTo(current);
    else drawBar();
  }
  function allLookRight() {
    for (const item of marked.filter((entry) => entry.kind === "check")) {
      pageReviewed().add(item.label);
      unmark(item);
    }
    marked = marked.filter((item) => item.kind !== "check");
    if (marked.length) goTo(0);
    else drawBar();
  }
  var esc = (text2) => text2.replace(/[&<>"]/g, (char) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[char]);
  function drawBar() {
    const done = !marked.length;
    if (done && !hadItems) {
      host?.remove();
      host = null;
      return;
    }
    if (!host) {
      host = document.createElement("div");
      host.setAttribute("data-unnepo-needs-bar", "");
      const root = host.attachShadow({ mode: "open" });
      root.innerHTML = `
      <style>
        :host { all: initial; position: fixed; right: 16px; bottom: 16px; z-index: 2147483646; font: 13px/1.3 system-ui, -apple-system, sans-serif; }
        .bar { display: flex; flex-direction: column; gap: 8px; width: min(340px, calc(100vw - 32px)); padding: 12px 14px; border-radius: 16px; background: #0A0A0B; color: #fff; box-shadow: 0 8px 28px rgba(0,0,0,.32); border: 2px solid var(--c, ${COLOR}); }
        .top { display: flex; align-items: center; justify-content: space-between; gap: 8px; font-weight: 700; }
        .count { font: 600 11px/1 ui-monospace, monospace; letter-spacing: .5px; text-transform: uppercase; color: #9A9AA3; }
        .label { font-weight: 600; overflow: hidden; text-overflow: ellipsis; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; }
        .why { color: #B4B4BC; font-size: 12px; }
        .row { display: flex; flex-wrap: wrap; gap: 6px; }
        button { all: unset; cursor: pointer; padding: 7px 11px; border-radius: 999px; font-weight: 600; font-size: 12px; border: 1px solid #33333A; color: #E6E6EA; }
        button.main { background: #fff; color: #0A0A0B; border-color: #fff; }
        button.quiet { border-color: transparent; color: #9A9AA3; padding-left: 4px; padding-right: 4px; }
        button:focus-visible { outline: 3px solid ${CHECK}; outline-offset: 2px; }
        .close { padding: 2px 6px; color: #9A9AA3; border: 0; }
      </style>
      <div class="bar" role="region" aria-label="Unnepo review checklist"></div>`;
      root.addEventListener("click", (event) => {
        const button = event.target.closest("button");
        const act = button?.dataset.act;
        if (act === "next") goTo(current + 1);
        else if (act === "back") goTo(current - 1);
        else if (act === "ok") looksRight();
        else if (act === "all") allLookRight();
        else if (act === "start") goTo(current);
        else if (act === "action") showAction();
        else if (act === "close") {
          hadItems = false;
          host?.remove();
          host = null;
        }
      });
      document.documentElement.appendChild(host);
    }
    const bar = host.shadowRoot.querySelector(".bar");
    if (done) {
      const action = findAction(false, scanFields().length);
      bar.style.setProperty("--c", "#4ADE80");
      bar.innerHTML = `<div class="top"><span>All checked \u2713</span><button class="close" data-act="close" aria-label="Close">\xD7</button></div>
      <div class="why">${action?.kind === "submit" ? `Press "${esc(action.label)}" when you're ready.` : action?.kind === "next" ? "Unnepo goes on to the next page." : "Nothing left to look at on this page."}</div>
      ${action?.kind === "submit" ? `<div class="row"><button class="main" data-act="action">Show me ${esc(action.label)}</button></div>` : ""}`;
      return;
    }
    current = Math.min(current, marked.length - 1);
    const item = marked[current];
    const checks = reviewLeft();
    bar.style.setProperty("--c", item.kind === "check" ? CHECK : COLOR);
    bar.innerHTML = `<div class="top"><span class="count">Review \xB7 ${current + 1} of ${marked.length}</span><button class="close" data-act="close" aria-label="Close the checklist">\xD7</button></div>
    <div class="label">${esc(item.label)}</div>
    <div class="why">${esc(item.kind === "check" ? item.why || "Check this answer." : item.why || "Needs your answer.")}</div>
    <div class="row">
      ${item.kind === "check" ? `<button class="main" data-act="ok" title="Alt+Enter">\u2713 Looks right</button>` : `<button class="main" data-act="start">Go to it</button>`}
      <button data-act="next">${item.kind === "check" ? "Skip" : "Next"} \u2192</button>
      ${checks > 1 ? `<button class="quiet" data-act="all">All ${checks} look right</button>` : ""}
      ${marked.length > 1 ? `<button class="quiet" data-act="back">\u2190 Back</button>` : ""}
    </div>`;
  }
  function showAction() {
    const action = findAction(false, scanFields().length);
    if (!action) return;
    scrollTo(action.el);
    const before = { outline: action.el.style.outline, outlineOffset: action.el.style.outlineOffset };
    action.el.style.outline = "3px solid #4ADE80";
    action.el.style.outlineOffset = "3px";
    action.el.focus({ preventScroll: true });
    setTimeout(() => Object.assign(action.el.style, before), 4e3);
  }
  var chips = null;
  var placing = 0;
  function writable(control, label) {
    if (control instanceof HTMLTextAreaElement) return true;
    if (!(control instanceof HTMLInputElement) || control.type !== "text" || control.getAttribute("role") === "combobox") return false;
    return label.split(/\s+/).length >= 5 || /\b(why|describe|tell us|explain|how would|what (makes|interests))\b/i.test(label);
  }
  function placeChips() {
    placing = 0;
    if (!chips) return;
    for (const chip of Array.from(chips.shadowRoot.querySelectorAll("button"))) {
      const item = marked.find((entry) => entry.label === chip.dataset.label);
      const rect = item?.control.getBoundingClientRect();
      if (!item || !rect || rect.height === 0 || rect.bottom < 0 || rect.top > innerHeight) {
        chip.style.display = "none";
        continue;
      }
      chip.style.display = "";
      chip.style.top = `${Math.max(4, rect.top - 30)}px`;
      chip.style.left = `${Math.max(4, Math.min(innerWidth - 150, rect.right - 140))}px`;
    }
  }
  var schedulePlace = () => {
    if (!placing) placing = requestAnimationFrame(placeChips);
  };
  async function writeFor(chip, item) {
    chip.disabled = true;
    chip.textContent = "Writing\u2026";
    const result = await chrome.runtime.sendMessage({ type: "write-answer", label: item.label }).catch(() => null);
    const control = item.control;
    if (result?.answer && control.isConnected && (control instanceof HTMLInputElement || control instanceof HTMLTextAreaElement) && isEmpty(control)) {
      typeInto(control, result.answer);
      control.focus({ preventScroll: true });
      chip.textContent = "Written: check it";
      setTimeout(refresh, 400);
      return;
    }
    chip.disabled = false;
    chip.textContent = "Write with AI";
    chip.title = result?.error || "Couldn't write this one. Try again.";
    chip.dataset.error = "1";
    setTimeout(() => delete chip.dataset.error, 2500);
  }
  function drawChips() {
    const items = marked.filter((item) => writable(item.control, item.label));
    if (!items.length) {
      chips?.remove();
      chips = null;
      return;
    }
    if (!chips) {
      chips = document.createElement("div");
      chips.setAttribute("data-unnepo-write", "");
      const root2 = chips.attachShadow({ mode: "open" });
      root2.innerHTML = `
      <style>
        :host { all: initial; position: fixed; inset: 0; pointer-events: none; z-index: 2147483645; font: 600 12px/1 system-ui, -apple-system, sans-serif; }
        button { all: unset; pointer-events: auto; cursor: pointer; position: fixed; display: inline-flex; align-items: center; gap: 6px; padding: 6px 10px; border-radius: 999px; background: #0A0A0B; color: #fff; border: 1.5px solid ${COLOR}; box-shadow: 0 4px 14px rgba(0,0,0,.22); white-space: nowrap; }
        button:disabled { cursor: progress; opacity: .8; }
        button[data-error] { border-color: #F87171; }
        button:focus-visible { outline: 3px solid #3D8BFF; outline-offset: 2px; }
      </style>`;
      document.documentElement.appendChild(chips);
      addEventListener("scroll", schedulePlace, { capture: true, passive: true });
      addEventListener("resize", schedulePlace, { passive: true });
    }
    const root = chips.shadowRoot;
    const wanted = new Set(items.map((item) => item.label));
    for (const chip of Array.from(root.querySelectorAll("button"))) if (!wanted.has(chip.dataset.label ?? "")) chip.remove();
    for (const item of items) {
      if (Array.from(root.querySelectorAll("button")).some((chip2) => chip2.dataset.label === item.label)) continue;
      const chip = document.createElement("button");
      chip.type = "button";
      chip.dataset.label = item.label;
      chip.textContent = "Write with AI";
      chip.setAttribute("aria-label", `Write an answer with AI for: ${item.label}`);
      chip.addEventListener("click", () => void writeFor(chip, item));
      root.appendChild(chip);
    }
    placeChips();
  }
  function refresh() {
    const still = [];
    for (const item of marked) {
      if (!item.control.isConnected || item.kind === "needs" && !isEmpty(item.control)) unmark(item);
      else still.push(item);
    }
    const moved = still.length !== marked.length;
    marked = still;
    if (moved && current >= marked.length) current = 0;
    drawBar();
    drawChips();
  }
  function changed(event) {
    const item = marked[current];
    const target = event.target;
    if (!item || !target || !(outlined(item.control).contains(target) || item.control === target)) return;
    setTimeout(() => {
      if (item.kind === "check") {
        pageReviewed().add(item.label);
        unmark(item);
        marked = marked.filter((entry) => entry !== item);
      } else if (!isEmpty(item.control)) {
        unmark(item);
        marked = marked.filter((entry) => entry !== item);
      } else return;
      if (marked.length) goTo(current);
      else drawBar();
    }, 250);
  }
  function markNeeds(labels, check = []) {
    const keep = /* @__PURE__ */ new Set();
    const found = [];
    for (const label of [...new Set(labels.map((item) => item.trim()).filter(Boolean))]) {
      const control = fieldControl(label);
      if (!control || !control.isConnected || !isEmpty(control) || keep.has(control)) continue;
      keep.add(control);
      found.push({ label, control, kind: "needs", why: "" });
    }
    const done = pageReviewed();
    for (const item of check) {
      const label = item.label.trim();
      if (!label || done.has(label)) continue;
      const control = fieldControl(label);
      if (!control || !control.isConnected || isEmpty(control) || keep.has(control)) continue;
      keep.add(control);
      found.push({ label, control, kind: "check", why: item.why });
    }
    for (const item of marked) if (!keep.has(item.control)) unmark(item);
    const already = new Map(marked.map((item) => [item.control, item]));
    const at = marked[current]?.control;
    marked = found.map(({ label, control, kind, why }) => {
      const existing = already.get(control);
      if (existing && existing.kind === kind) return existing;
      if (existing) unmark(existing);
      const box = outlined(control);
      const item = { label, control, kind, why, before: { outline: box.style.outline, outlineOffset: box.style.outlineOffset } };
      box.style.outline = `3px ${kind === "check" ? "dashed" : "solid"} ${kind === "check" ? CHECK : COLOR}`;
      box.style.outlineOffset = "3px";
      box.setAttribute("data-unnepo-needs", label);
      return item;
    });
    marked.sort((a, b) => a.control.compareDocumentPosition(b.control) & Node.DOCUMENT_POSITION_FOLLOWING ? -1 : 1);
    current = Math.max(0, marked.findIndex((item) => item.control === at));
    if (marked.length) hadItems = true;
    drawBar();
    drawChips();
    if (!listening) {
      listening = true;
      for (const type of ["input", "change", "click"]) document.addEventListener(type, () => setTimeout(refresh, 150), true);
      document.addEventListener("change", changed, true);
      document.addEventListener("keydown", (event) => {
        if (event.altKey && event.key === "Enter" && marked.length) {
          event.preventDefault();
          looksRight();
        }
      }, true);
    }
    const set = marked.map((item) => item.label).join("|");
    const before = new Set(lastSet.split("|"));
    if (marked.some((item) => !before.has(item.label))) {
      current = 0;
      const typing = document.activeElement?.matches("input, textarea, select, [contenteditable=true]");
      if (!typing) scrollTo(marked[0].control);
      drawBar();
    }
    lastSet = set;
    return marked.map((item) => item.label);
  }

  // lib/spiders.ts
  var SKINS = [
    { id: "classic", name: "Unnepo", unlockAt: 0, color: "#6E5B6E" },
    { id: "school", name: "School spirit", unlockAt: 0, color: "#6E5B6E" },
    { id: "blue", name: "Blue", unlockAt: 50, color: "#3D8BFF" },
    { id: "green", name: "Green", unlockAt: 150, color: "#2FBF71" },
    { id: "purple", name: "Purple", unlockAt: 300, color: "#9B5CFF" },
    { id: "gold", name: "Gold", unlockAt: 500, color: "#F2B227" },
    { id: "pink", name: "Pink", unlockAt: 1e3, color: "#FF5C9A" }
  ];
  var isSkin = (value) => SKINS.some((skin) => skin.id === value);
  var SCHOOL_STYLES = {
    "colby college": { color: "#002169", text: "#FFFFFF", letters: "C" },
    "university of vermont": { color: "#154734", text: "#FFD416", letters: "UVM" },
    "uvm": { color: "#154734", text: "#FFD416", letters: "UVM" },
    "university of pennsylvania": { color: "#011F5B", text: "#FFFFFF", letters: "P" },
    "university of pittsburgh": { color: "#003594", text: "#FFB81C", letters: "P" },
    "cornell university": { color: "#B31B1B", text: "#FFFFFF", letters: "C" },
    "columbia university": { color: "#6CACE4", text: "#FFFFFF", letters: "C" },
    "boston college": { color: "#8A100B", text: "#E0C48A", letters: "BC" },
    "new york university": { color: "#57068C", text: "#FFFFFF", letters: "NYU" },
    "university of washington": { color: "#4B2E83", text: "#B7A57A", letters: "W" },
    "university of texas at austin": { color: "#BF5700", text: "#FFFFFF", letters: "T" },
    "bowdoin college": { color: "#1A1A1A", text: "#FFFFFF", letters: "B" },
    "bates college": { color: "#881124", text: "#FFFFFF", letters: "B" },
    "middlebury college": { color: "#0D395F", text: "#FFFFFF", letters: "M" },
    "williams college": { color: "#500082", text: "#FFCC00", letters: "W" },
    "amherst college": { color: "#3F1F69", text: "#FFFFFF", letters: "A" },
    "brown university": { color: "#4E3629", text: "#ED1C24", letters: "B" },
    "dartmouth college": { color: "#00693E", text: "#FFFFFF", letters: "D" },
    "yale university": { color: "#00356B", text: "#FFFFFF", letters: "Y" },
    "harvard university": { color: "#A51C30", text: "#FFFFFF", letters: "H" },
    "princeton university": { color: "#E77500", text: "#121212", letters: "P" },
    "stanford university": { color: "#8C1515", text: "#FFFFFF", letters: "S" },
    "university of michigan": { color: "#00274C", text: "#FFCB05", letters: "M" },
    "university of california, berkeley": { color: "#003262", text: "#FDB515", letters: "CAL" },
    "georgetown university": { color: "#041E42", text: "#A7B1B7", letters: "G" },
    "duke university": { color: "#00539B", text: "#FFFFFF", letters: "D" },
    "northwestern university": { color: "#4E2A84", text: "#FFFFFF", letters: "N" }
  };
  var FALLBACK_COLORS = ["#1D4F91", "#7A1F2B", "#1F6B45", "#5B2C83", "#B35A00", "#0F5A6B"];
  var FILLER = /* @__PURE__ */ new Set(["of", "the", "at", "and", "for", "in"]);
  function schoolStyle(school) {
    const name = (school ?? "").replace(/\s+/g, " ").trim();
    if (!name) return null;
    const known = SCHOOL_STYLES[name.toLowerCase()];
    if (known) return known;
    const words2 = name.split(/[\s,-]+/).filter((word) => word && !FILLER.has(word.toLowerCase()));
    const general = words2.filter((word) => !/^(college|university|school|institute)$/i.test(word));
    const letters2 = (words2[0] && /^university$/i.test(words2[0]) ? words2 : general.length ? general : words2).map((word) => word[0]).join("").toUpperCase().slice(0, 3) || name[0].toUpperCase();
    const hash = [...name].reduce((sum, char) => sum * 31 + char.charCodeAt(0) >>> 0, 7);
    return { color: FALLBACK_COLORS[hash % FALLBACK_COLORS.length], text: "#FFFFFF", letters: letters2.length === 2 && general.length === 1 ? letters2[0] : letters2 };
  }
  function shade(hex, amount) {
    const value = parseInt(hex.replace("#", ""), 16);
    const target = amount > 0 ? 255 : 0;
    const mix = (channel) => Math.round(channel + (target - channel) * Math.abs(amount));
    const [r, g, b] = [value >> 16 & 255, value >> 8 & 255, value & 255].map(mix);
    return `#${(1 << 24 | r << 16 | g << 8 | b).toString(16).slice(1).toUpperCase()}`;
  }
  function spiderPalette(look) {
    if (look.skin === "classic") {
      return {
        o: "#000000",
        b: "#6E5B6E",
        h: "#B48FAE",
        d: "#4E3549",
        a: "#3D8BFF",
        e: "#3D8BFF",
        k: "#7E6580",
        K: "#5A4258",
        l: "#6E5B6E",
        L: "#4E3549",
        w: "#FFFFFF",
        m: "#1A0E14",
        f: "#F7F7F8",
        p: "#965E8C",
        t: "#FFFFFF",
        r: "#4E3549"
      };
    }
    const skin = SKINS.find((item) => item.id === look.skin) ?? SKINS[0];
    const style = look.skin === "school" ? schoolStyle(look.school) : null;
    const body = skin.color;
    const back = style?.color ?? body;
    return {
      o: "#000000",
      b: back,
      h: shade(back, 0.35),
      d: shade(back, -0.3),
      k: shade(body, 0.12),
      K: shade(body, -0.15),
      l: body,
      L: shade(body, -0.3),
      a: skin.id === "school" ? "#3D8BFF" : shade(body, 0.55),
      e: skin.id === "school" ? "#3D8BFF" : shade(body, 0.55),
      t: style?.text ?? "#FFFFFF",
      r: shade(back, -0.45),
      m: "#1A0E14",
      w: "#FFFFFF",
      f: "#F7F7F8",
      p: "#965E8C"
    };
  }
  function crawlerColors(look) {
    if (look.skin === "classic") return {};
    const palette = spiderPalette(look);
    return { b: palette.b, s: palette.h, l: palette.L };
  }

  // extension/src/shared/sprite.ts
  var W = 20;
  var H = 17;
  var COLORS = { o: "#000000", b: "#2B2531", s: "#4A4252", l: "#1B171F", w: "#EAF6F2", p: "#1B171F", c: "#F2949E" };
  function spiderGrid(step) {
    const g = Array.from({ length: H }, () => Array(W).fill(""));
    const set = (x, y, c) => {
      if (x >= 0 && x < W && y >= 0 && y < H) g[y][x] = c;
    };
    const legs = step === 0 ? [[[6, 6], [5, 5], [4, 4], [4, 3], [3, 2]], [[5, 8], [4, 7], [3, 7], [2, 7], [1, 8]], [[5, 10], [4, 10], [3, 11], [2, 11], [2, 12]], [[6, 12], [5, 13], [4, 14], [4, 15]]] : [[[6, 6], [5, 5], [5, 4], [4, 3], [4, 2]], [[5, 8], [4, 8], [3, 8], [2, 8], [1, 9]], [[5, 10], [4, 11], [3, 11], [3, 12], [2, 13]], [[6, 12], [6, 13], [5, 14], [5, 15]]];
    for (const leg of legs) for (const [x, y] of leg) {
      set(x, y, "l");
      set(W - 1 - x, y, "l");
    }
    for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
      const nx = (x + 0.5 - 10) / 4.6, ny = (y + 0.5 - 9.2) / 5;
      if (nx * nx + ny * ny <= 1) set(x, y, "b");
    }
    for (const ex of [6, 11]) for (let dx = 0; dx < 3; dx++) for (let dy = 0; dy < 3; dy++) set(ex + dx, 5 + dy, "w");
    set(7, 6, "p");
    set(12, 6, "p");
    set(5, 8, "c");
    set(14, 8, "c");
    set(11, 11, "s");
    const out = g.map((row) => row.slice());
    for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
      if (g[y][x]) continue;
      if ([[1, 0], [-1, 0], [0, 1], [0, -1]].some(([dx, dy]) => g[y + dy]?.[x + dx])) out[y][x] = "o";
    }
    return out;
  }
  function spiderRects(step, colors = {}) {
    const out = spiderGrid(step);
    const palette = { ...COLORS, ...colors };
    let rects = "";
    for (let y = 0; y < H; y++) {
      let x = 0;
      while (x < W) {
        const c = out[y][x];
        if (!c) {
          x++;
          continue;
        }
        let w = 1;
        while (x + w < W && out[y][x + w] === c) w++;
        rects += `<rect x="${x}" y="${y}" width="${w}" height="1" fill="${palette[c]}"/>`;
        x += w;
      }
    }
    return rects;
  }
  async function storedSpiderColors() {
    try {
      const { spider } = await chrome.storage.local.get("spider");
      return spider && isSkin(spider.skin) ? crawlerColors(spider) : {};
    } catch {
      return {};
    }
  }

  // extension/src/content/spiders.ts
  var FRAMES = [spiderRects(0), spiderRects(1)];
  void storedSpiderColors().then((colors) => {
    FRAMES = [spiderRects(0, colors), spiderRects(1, colors)];
  });
  var host2 = null;
  var spiders = [];
  var raf = 0;
  var leaving = false;
  var exitTimer = 0;
  var last = 0;
  var rand = (min, max) => min + Math.random() * (max - min);
  function pickTarget(spider) {
    const m = spider.size;
    return [rand(m, innerWidth - m), rand(m, innerHeight - m)];
  }
  function exitPoint(spider) {
    const options2 = [[-spider.size * 2, spider.y], [innerWidth + spider.size * 2, spider.y], [spider.x, -spider.size * 2], [spider.x, innerHeight + spider.size * 2]];
    return options2.sort((a, b) => Math.hypot(a[0] - spider.x, a[1] - spider.y) - Math.hypot(b[0] - spider.x, b[1] - spider.y))[0];
  }
  function make(root, index, count, now, drop) {
    const size = Math.round(rand(40, 58));
    const el = document.createElement("div");
    el.className = "spider";
    el.style.width = `${size}px`;
    el.style.height = `${Math.round(size * H / W)}px`;
    const thread = document.createElement("div");
    thread.className = "thread";
    const svg = `<svg viewBox="0 0 ${W} ${H}" width="100%" height="100%" shape-rendering="crispEdges"><g>${FRAMES[0]}</g><g style="display:none">${FRAMES[1]}</g></svg>`;
    el.innerHTML = svg;
    el.prepend(thread);
    root.appendChild(el);
    const lane = (index + 0.5) / count;
    const x = Math.min(innerWidth - size, Math.max(size, innerWidth * lane + rand(-40, 40)));
    const spider = {
      el,
      thread,
      frames: Array.from(el.querySelectorAll("g")),
      size,
      x,
      y: -size,
      angle: 180,
      phase: "wait",
      start: now + index * rand(90, 180),
      dropTo: rand(innerHeight * 0.18, innerHeight * 0.55),
      target: [0, 0],
      speed: rand(70, 120),
      restUntil: 0,
      frame: 0,
      lastStep: 0,
      home: [0, 0],
      scale: 1
    };
    if (!drop) {
      thread.remove();
      spider.y = rand(size, innerHeight - size);
      spider.angle = rand(0, 360);
      spider.phase = "rest";
      spider.restUntil = now + rand(0, 600);
    }
    return spider;
  }
  function draw(spider) {
    const h = spider.size * H / W;
    spider.el.style.transform = `translate(${spider.x - spider.size / 2}px, ${spider.y - h / 2}px)`;
    const svg = spider.el.querySelector("svg");
    svg.style.transform = `rotate(${spider.angle}deg) scale(${spider.scale})`;
    spider.frames[0].style.display = spider.frame ? "none" : "";
    spider.frames[1].style.display = spider.frame ? "" : "none";
  }
  function tick(now) {
    const dt = Math.min(0.05, (now - (last || now)) / 1e3);
    last = now;
    for (const spider of spiders) {
      if (spider.phase === "gone") continue;
      const moving = () => {
        if (now - spider.lastStep > 110) {
          spider.frame = spider.frame ? 0 : 1;
          spider.lastStep = now;
        }
      };
      if (spider.phase === "wait" && now >= spider.start) spider.phase = "drop";
      if (spider.phase === "drop") {
        const t = Math.min(1, (now - spider.start) / 900);
        const ease = t < 1 ? 1 - Math.pow(1 - t, 3) + Math.sin(t * Math.PI) * 0.06 : 1;
        spider.y = -spider.size + (spider.dropTo + spider.size) * ease;
        spider.thread.style.height = `${Math.max(0, spider.y + spider.size)}px`;
        if (t >= 1) {
          spider.phase = "turn";
          spider.start = now;
          spider.target = pickTarget(spider);
        }
      } else if (spider.phase === "turn") {
        const t = Math.min(1, (now - spider.start) / 320);
        spider.thread.style.opacity = String(1 - t);
        const heading = Math.atan2(spider.target[0] - spider.x, -(spider.target[1] - spider.y)) * 180 / Math.PI;
        spider.angle = 180 + ((heading - 180 + 540) % 360 - 180) * t;
        if (t >= 1) {
          spider.thread.remove();
          spider.phase = "crawl";
        }
      } else if (spider.phase === "crawl" || spider.phase === "leave") {
        const [tx, ty] = spider.target;
        const dx = tx - spider.x, dy = ty - spider.y;
        const distance = Math.hypot(dx, dy);
        const speed = spider.phase === "leave" ? 320 : spider.speed;
        if (distance < 4) {
          if (spider.phase === "leave") {
            spider.phase = "gone";
            spider.el.remove();
            continue;
          }
          spider.phase = "rest";
          spider.restUntil = now + rand(250, 1100);
        } else {
          const stepLength = Math.min(distance, speed * dt);
          spider.x += dx / distance * stepLength;
          spider.y += dy / distance * stepLength;
          const heading = Math.atan2(dx, -dy) * 180 / Math.PI;
          const diff = (heading - spider.angle + 540) % 360 - 180;
          spider.angle += diff * Math.min(1, dt * 10);
          moving();
        }
      } else if (spider.phase === "dance") {
        const t = (now - spider.start) / 1e3;
        const [hx, hy] = spider.home;
        if (t < 0) {
          draw(spider);
          continue;
        }
        if (t < 0.5) {
          const jump = Math.sin(t / 0.5 * Math.PI);
          spider.y = hy - jump * 110;
          spider.x = hx;
          spider.scale = 1 + jump * 0.25;
          spider.angle += ((0 - spider.angle + 540) % 360 - 180) * Math.min(1, dt * 14);
        } else {
          const beat = (t - 0.5) * Math.PI * 3.2;
          spider.y = hy - Math.abs(Math.sin(beat)) * 30;
          spider.x = hx + Math.sin(beat / 2) * 14;
          spider.angle = Math.sin(beat / 2) * 22;
          spider.scale = 1 + Math.abs(Math.sin(beat)) * 0.08;
        }
        if (now - spider.lastStep > 80) {
          spider.frame = spider.frame ? 0 : 1;
          spider.lastStep = now;
        }
      } else if (spider.phase === "rest" && now >= spider.restUntil) {
        spider.target = pickTarget(spider);
        spider.phase = "crawl";
      }
      draw(spider);
    }
    if (spiders.every((spider) => spider.phase === "gone")) return stop();
    raf = requestAnimationFrame(tick);
  }
  function stop() {
    cancelAnimationFrame(raf);
    dancing = false;
    host2?.remove();
    host2 = null;
    spiders = [];
    leaving = false;
    last = 0;
  }
  function startSpiders(drop = true) {
    clearTimeout(exitTimer);
    if (matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    if (host2) {
      if (dancing) return;
      if (leaving) {
        leaving = false;
        for (const spider of spiders) if (spider.phase === "leave") {
          spider.phase = "crawl";
          spider.target = pickTarget(spider);
        }
      }
      return;
    }
    const stale = document.querySelectorAll("[data-unnepo-spiders]");
    if (stale.length) drop = false;
    stale.forEach((el) => el.remove());
    host2 = document.createElement("div");
    host2.setAttribute("data-unnepo-spiders", "");
    host2.setAttribute("aria-hidden", "true");
    const root = host2.attachShadow({ mode: "open" });
    const style = document.createElement("style");
    style.textContent = `
    :host { all: initial; position: fixed; inset: 0; pointer-events: none; z-index: 2147483647; overflow: hidden; }
    .spider { position: absolute; left: 0; top: 0; will-change: transform; filter: drop-shadow(2px 3px 0 rgba(0,0,0,.18)); }
    .spider svg { display: block; transform-origin: 50% 50%; }
    .thread { position: absolute; left: calc(50% - 1.5px); bottom: 70%; width: 3px; background: linear-gradient(90deg, #000 0 1px, #EAF6F2 1px 2px, #000 2px); }
  `;
    root.appendChild(style);
    document.documentElement.appendChild(host2);
    const count = innerWidth < 700 ? 3 : 5;
    const now = performance.now();
    spiders = Array.from({ length: count }, (_, index) => make(root, index, count, now, drop));
    for (const spider of spiders) draw(spider);
    raf = requestAnimationFrame(tick);
  }
  var DANCE_MS = 4800;
  var LAND_MS = 1500;
  var dancing = false;
  var celebrated = false;
  function celebrateSpiders() {
    if (celebrated) return;
    celebrated = true;
    if (host2 && spiders.some((spider) => spider.phase !== "gone")) return dance();
    if (matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    startSpiders(true);
    dancing = true;
    window.setTimeout(dance, LAND_MS);
  }
  function dance() {
    if (!host2) return;
    clearTimeout(exitTimer);
    dancing = true;
    leaving = false;
    const now = performance.now();
    spiders.forEach((spider, index) => {
      if (spider.phase === "gone") return;
      spider.thread.remove();
      spider.home = [Math.min(innerWidth - spider.size, Math.max(spider.size, spider.x)), Math.min(innerHeight - spider.size, Math.max(spider.size + 120, spider.y))];
      spider.phase = "dance";
      spider.start = now + index * 120;
    });
    exitTimer = window.setTimeout(() => {
      dancing = false;
      for (const spider of spiders) spider.scale = 1;
      stopSpiders(0);
    }, DANCE_MS);
  }
  function stopSpiders(after = 400) {
    if (dancing) return;
    clearTimeout(exitTimer);
    exitTimer = window.setTimeout(() => {
      if (!host2) return;
      leaving = true;
      for (const spider of spiders) {
        if (spider.phase === "gone") continue;
        spider.thread.remove();
        spider.phase = "leave";
        spider.target = exitPoint(spider);
      }
      exitTimer = window.setTimeout(() => {
        if (leaving) stop();
      }, 4e3);
    }, after);
  }

  // extension/src/content/apply-help.ts
  var clean3 = (text2) => String(text2 ?? "").replace(/\s+/g, " ").trim();
  function postingFacts(title) {
    const raw = [];
    const collect = (value2) => {
      if (Array.isArray(value2)) value2.forEach(collect);
      else if (value2 && typeof value2 === "object") {
        const item = value2;
        const type2 = item["@type"];
        if (type2 === "JobPosting" || Array.isArray(type2) && type2.includes("JobPosting")) raw.push(item);
        if (item["@graph"]) collect(item["@graph"]);
      }
    };
    for (const script of Array.from(document.querySelectorAll('script[type="application/ld+json"]'))) {
      try {
        collect(JSON.parse(script.textContent || ""));
      } catch {
      }
    }
    const job = raw.find((item) => clean3(item.title).toLowerCase() === title.toLowerCase()) ?? (raw.length === 1 ? raw[0] : null);
    if (!job) return { location: "", pay: "", type: "", posted: "", remote: "" };
    const places = (Array.isArray(job.jobLocation) ? job.jobLocation : [job.jobLocation]).map((place2) => {
      const address = place2?.address ?? {};
      return [address.addressLocality, address.addressRegion].map(clean3).filter(Boolean).join(", ");
    }).filter(Boolean);
    const salary = job.baseSalary ?? {};
    const value = salary.value ?? {};
    const money = (amount) => Number(amount) ? `$${Number(amount).toLocaleString("en-US")}` : "";
    const low = money(value.minValue ?? value.value);
    const high = money(value.maxValue);
    const unit = clean3(value.unitText).toLowerCase();
    const per = { hour: "/hr", year: "/yr", month: "/mo", week: "/wk", day: "/day" };
    const pay = low ? `${low}${high && high !== low ? `\u2013${high}` : ""}${per[unit] ?? ""}` : "";
    const type = (Array.isArray(job.employmentType) ? job.employmentType : [job.employmentType]).map((kind) => clean3(kind).replace(/_/g, " ").toLowerCase()).filter(Boolean).join(", ");
    const day = clean3(job.datePosted);
    const posted = day ? new Date(/^\d{4}-\d{2}-\d{2}$/.test(day) ? `${day}T12:00:00` : day).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" }) : "";
    return { location: [...new Set(places)].slice(0, 3).join(" \xB7 "), pay, type, posted: posted === "Invalid Date" ? "" : posted, remote: job.jobLocationType === "TELECOMMUTE" ? "Remote" : "" };
  }
  function factsFromText(text2) {
    const pay = text2.match(/\$\s?\d[\d,.]*\s?[kK]?(?:\s?(?:-|–|to)\s?\$?\s?\d[\d,.]*\s?[kK]?)?\s?(?:\/|per |an |a )?\s?(?:hour|hr|year|yr|annually|month)\b/i)?.[0] ?? "";
    const remote = /\b(fully remote|remote[- ]first|100% remote)\b/i.test(text2) ? "Remote" : /\bhybrid\b/i.test(text2) ? "Hybrid" : "";
    const type = text2.match(/\b(full[- ]time|part[- ]time|internship|co-?op|contract|temporary|seasonal)\b/i)?.[0].toLowerCase() ?? "";
    return { pay: clean3(pay), remote, type };
  }
  function jobDetails() {
    if (linkedinJob()?.waiting) {
      return { title: "", company: "", description: "", url: location.href, from: "details pane", location: "", pay: "", type: "", posted: "", remote: "", site: location.hostname.replace(/^www\./, ""), questions: 0, uploads: 0, resumeBox: false };
    }
    const opened2 = openedJob();
    const scan = scanPage();
    const title = opened2.title || scan.title;
    const company = opened2.company || scan.company;
    const description = (opened2.description || scan.description || structuredJobs()[0]?.description || "").slice(0, 8e3);
    const facts = postingFacts(title);
    const fromText = factsFromText(description || (document.body.innerText || "").slice(0, 2e4));
    const fields = scanFields();
    const host3 = location.hostname.replace(/^www\./, "");
    return {
      title,
      company,
      description,
      url: opened2.url || location.href,
      from: opened2.from,
      location: facts.location,
      pay: facts.pay || fromText.pay,
      type: facts.type || fromText.type,
      posted: facts.posted,
      remote: facts.remote || fromText.remote,
      site: host3,
      questions: fields.filter((field) => field.type !== "file").length,
      uploads: fields.filter((field) => field.type === "file").length,
      resumeBox: fields.some((field) => field.type === "file" && !/cover ?letter|transcript|portfolio|writing sample/i.test(`${field.label} ${field.section}`))
    };
  }
  var QUESTION_WORDS = /\b(why|how|what|describe|tell us|explain|share|walk us|give an example|example of|talk about|discuss|elaborate|in your own words|motivat|interest(s|ed)? you|excit|challenge|proud|accomplish|strength|weakness|goal|hope to|would you|have you ever|a time when|cover letter|additional information|anything else)\b/i;
  var BASIC = /\b(first|last|full|preferred|legal|middle) ?name\b|^name\b|e-?mail|phone|mobile|address|city|state|zip|postal|country|linked ?in|github|portfolio|website|\burl\b|salary|compensation|pay\b|start date|date|gpa|school|university|college|degree|major|minor|graduat|year|pronoun|referr(ed|al)|how did you hear|source|sponsor|authori[sz]ed|visa|relocat|citizen|clearance|age\b|18\b/i;
  function complexQuestions(fields = scanFields()) {
    return fields.filter((field) => {
      if (field.type !== "textarea" && field.type !== "text") return false;
      const label = field.label.trim();
      if (label.length < 8 || classifyQuestion(label).sensitive || classifyQuestion(label).field) return false;
      if (field.type === "textarea") return !BASIC.test(label) || QUESTION_WORDS.test(label);
      return label.length >= 30 && QUESTION_WORDS.test(label) && !BASIC.test(label);
    });
  }
  var layer = null;
  var layerRoot = null;
  var markers = /* @__PURE__ */ new Map();
  var frames = [spiderRects(0), spiderRects(1)];
  void storedSpiderColors().then((colors) => {
    frames = [spiderRects(0, colors), spiderRects(1, colors)];
  });
  var placing2 = 0;
  function ensureLayer() {
    if (layer?.isConnected && layerRoot) return layerRoot;
    layer = document.createElement("div");
    layer.setAttribute("data-unnepo-question-spiders", "");
    layer.setAttribute("aria-hidden", "true");
    layerRoot = layer.attachShadow({ mode: "open" });
    const still = matchMedia("(prefers-reduced-motion: reduce)").matches;
    layerRoot.innerHTML = `<style>
    :host { all: initial; position: absolute; left: 0; top: 0; width: 0; height: 0; z-index: 2147483645; pointer-events: none; }
    .q { position: absolute; width: 26px; height: ${Math.round(26 * H / W)}px; filter: drop-shadow(1px 2px 0 rgba(0,0,0,.2)); transition: opacity .3s; }
    .q svg { display: block; width: 100%; height: 100%; transform: rotate(180deg); }
    .q .thread { position: absolute; left: 12px; bottom: 100%; width: 2px; height: 14px; background: #2B2531; opacity: .55; }
    .q g + g { display: none; }
    ${still ? "" : `
    .q { animation: bob 1.6s ease-in-out infinite; }
    .q svg g { animation: legs .36s steps(1) infinite; }
    .q svg g + g { display: block; animation: legs2 .36s steps(1) infinite; }
    @keyframes bob { 0%, 100% { transform: translate(0, 0); } 25% { transform: translate(-3px, 2px); } 50% { transform: translate(0, 4px); } 75% { transform: translate(3px, 2px); } }
    @keyframes legs { 0%, 49% { opacity: 1; } 50%, 100% { opacity: 0; } }
    @keyframes legs2 { 0%, 49% { opacity: 0; } 50%, 100% { opacity: 1; } }`}
    .q.done { opacity: 0; }
  </style>`;
    document.documentElement.appendChild(layer);
    window.addEventListener("scroll", schedulePlace2, { passive: true, capture: true });
    window.addEventListener("resize", schedulePlace2, { passive: true });
    return layerRoot;
  }
  function controlFor(id) {
    const el = findMarked(id);
    if (!el) return null;
    return el.matches("input, textarea, select") ? el : el.querySelector("input, textarea") ?? el;
  }
  function place() {
    placing2 = 0;
    for (const [id, marker] of markers) {
      const control = controlFor(id);
      const box = control?.getBoundingClientRect();
      if (!control || !box || box.height === 0) {
        marker.style.display = "none";
        continue;
      }
      marker.style.display = "";
      marker.style.left = `${Math.round(Math.min(box.right - 30, document.documentElement.clientWidth - 34) + scrollX)}px`;
      marker.style.top = `${Math.round(box.top + scrollY - 20)}px`;
    }
  }
  function schedulePlace2() {
    if (!placing2) placing2 = requestAnimationFrame(place);
  }
  function markQuestion(field) {
    if (markers.has(field.id)) return;
    const root = ensureLayer();
    const marker = document.createElement("div");
    marker.className = "q";
    marker.innerHTML = `<div class="thread"></div><svg viewBox="0 0 ${W} ${H}" shape-rendering="crispEdges"><g>${frames[0]}</g><g>${frames[1]}</g></svg>`;
    root.appendChild(marker);
    markers.set(field.id, marker);
  }
  function unmarkQuestion(id) {
    const marker = markers.get(id);
    if (!marker) return;
    markers.delete(id);
    marker.classList.add("done");
    setTimeout(() => marker.remove(), 350);
  }
  function clearQuestionSpiders() {
    for (const id of [...markers.keys()]) unmarkQuestion(id);
    observer?.disconnect();
    observer = null;
    applyingResume = null;
  }
  var applyingResume = null;
  var observer = null;
  var rerun = 0;
  var onChange = null;
  function pass() {
    const fields = scanFields();
    const uploaded = applyingResume ? uploadResumeNow(fields, applyingResume) : [];
    const found = complexQuestions(fields);
    const live = new Set(found.map((field) => field.id));
    for (const id of [...markers.keys()]) if (!live.has(id)) unmarkQuestion(id);
    const questions = found.map((field) => {
      const control = controlFor(field.id);
      const answered = Boolean(control && !isEmpty(control));
      if (answered) unmarkQuestion(field.id);
      else markQuestion(field);
      return { id: field.id, label: field.label, required: field.required, answered };
    });
    schedulePlace2();
    return { uploaded, questions, resumeBox: fields.some((field) => field.type === "file") };
  }
  function beginApplying(resume, changed2) {
    applyingResume = resume;
    onChange = changed2;
    const first = pass();
    observer?.disconnect();
    observer = new MutationObserver((records) => {
      if (records.every((record) => layer && (record.target === layer || layer.contains(record.target)))) return;
      clearTimeout(rerun);
      rerun = window.setTimeout(() => {
        const before = [...markers.keys()].join("|");
        const result = pass();
        if (result.uploaded.length || [...markers.keys()].join("|") !== before) onChange?.(result);
      }, 700);
    });
    observer.observe(document.body, { childList: true, subtree: true });
    setTimeout(() => {
      observer?.disconnect();
      observer = null;
    }, 30 * 6e4);
    return first;
  }
  function putAnswer(id, text2, replace = false) {
    const control = controlFor(id);
    if (!(control instanceof HTMLTextAreaElement || control instanceof HTMLInputElement)) return { ok: false, reason: "That question isn't on the page any more." };
    if (!replace && control.value.trim()) return { ok: false, reason: "That box already has an answer." };
    typeInto(control, text2);
    unmarkQuestion(id);
    return { ok: Boolean(control.value.trim()), reason: "" };
  }
  function showQuestion(id) {
    const control = controlFor(id);
    if (!control) return false;
    control.scrollIntoView({ block: "center", behavior: matchMedia("(prefers-reduced-motion: reduce)").matches ? "auto" : "smooth" });
    setTimeout(() => control.focus({ preventScroll: true }), 300);
    return true;
  }

  // extension/src/content/fill.ts
  function fillPasswords(password) {
    if (!password) return [];
    const boxes = deepAll("input[type=password]").filter((box) => !box.disabled && !box.readOnly && !box.value && box.getBoundingClientRect().height > 0);
    boxes.forEach((box) => typeInto(box, password));
    return boxes.map((box, index) => index === 0 ? "Password" : /confirm|verify|re-?enter|again/i.test(`${labelOf(box)} ${box.name} ${box.id} ${box.getAttribute("aria-label") ?? ""} ${box.getAttribute("data-automation-id") ?? ""}`) ? "Confirm password" : `Password ${index + 1}`);
  }
  async function withOptions(fields) {
    for (const field of fields) {
      if (field.type !== "combobox" || field.options.length) continue;
      const el = findMarked(field.id);
      if (!el) continue;
      const control = el.closest("[class*='select__control'], [class*='-control']") ?? el;
      press(control);
      const options2 = await waitFor(() => visibleOptions().length ? visibleOptions() : null, 1500);
      field.options = (options2 ?? []).map((option) => (option.textContent ?? "").replace(/\s+/g, " ").trim()).filter(Boolean).slice(0, 100);
      (el instanceof HTMLInputElement ? el : control).dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", bubbles: true }));
      el.blur();
      await sleep(80);
    }
    return fields;
  }
  function showField(label) {
    const control = fieldControl(label);
    if (!control) return false;
    const reduce = matchMedia("(prefers-reduced-motion: reduce)").matches;
    control.scrollIntoView({ block: "center", behavior: reduce ? "auto" : "smooth" });
    const before = { outline: control.style.outline, outlineOffset: control.style.outlineOffset, boxShadow: control.style.boxShadow };
    control.style.outline = "3px solid #3D8BFF";
    control.style.outlineOffset = "3px";
    control.style.boxShadow = "0 0 0 8px rgba(61, 139, 255, .25)";
    setTimeout(() => control.focus({ preventScroll: true }), reduce ? 0 : 350);
    setTimeout(() => Object.assign(control.style, before), 2600);
    return true;
  }
  async function recheckFlagged() {
    const boxes = deepAll("input[aria-invalid='true'], textarea[aria-invalid='true']").filter((box) => box.type !== "file" && box.value.trim());
    for (const box of boxes) {
      box.focus();
      await sleep(40);
      leave(box);
      await sleep(40);
    }
  }
  var planned = [];
  var plannedValues = /* @__PURE__ */ new Map();
  async function fill(plan) {
    const started = Date.now();
    const files = { resume: plan.resume, coverLetter: plan.coverLetter };
    if (!plan.useServerSchema) planned = scanFields();
    const kept = plan.answers.filter((answer) => keptByStudent(answer, plan.useServerSchema));
    const answers = plan.answers.filter((answer) => !kept.includes(answer));
    const result = plan.useServerSchema ? await fillGreenhouse(answers, files) : await fillGeneric(planned, answers, files, { dropdownFirst: plan.dropdownFirst });
    result.filled.push(...kept.map((answer) => answer.label));
    result.filled.push(...fillPasswords(plan.password));
    plannedValues = new Map(plan.answers.map((answer) => [answer.label, answer.values.join(", ")]));
    await sleep(300);
    await recheckFlagged();
    const missing = emptyRequired().map((field) => field.label);
    if (plan.useServerSchema) {
      for (const answer of plan.answers) {
        if (answer.required && document.getElementById(answer.id) && !greenhouseValue(answer.id, answer.type) && !missing.includes(answer.label)) missing.push(answer.label);
      }
    }
    return { filled: result.filled, failed: result.failed, attempts: result.attempts, needsYou: [...new Set(missing)], captcha: scanPage().captcha, submitted: false, ms: Date.now() - started };
  }
  function typedAnswers() {
    const fields = planned.length ? planned : scanFields();
    return fields.flatMap((field) => {
      const el = findMarked(field.id);
      if (!el || field.type === "file") return [];
      const control = el.matches("input, select, textarea, button") ? el : el.querySelector("input") ?? el;
      if (isEmpty(control)) return [];
      const value = control instanceof HTMLSelectElement ? control.selectedOptions[0]?.textContent?.trim() ?? "" : control instanceof HTMLInputElement && (control.type === "radio" || control.type === "checkbox") ? (rootOf(control).querySelector(`input[name="${CSS.escape(control.name)}"]:checked`)?.closest("label")?.textContent ?? "").trim() : control instanceof HTMLInputElement || control instanceof HTMLTextAreaElement ? control.value.trim() : (control.textContent ?? "").trim();
      if (!value || value.length > 400 || plannedValues.get(field.label) === value) return [];
      return [{ question: field.label, answer: value, section: field.section }];
    });
  }
  function alive() {
    try {
      return Boolean(chrome.runtime?.id);
    } catch {
      return false;
    }
  }
  function tell(message) {
    if (!alive()) return;
    try {
      void chrome.runtime.sendMessage(message).catch(() => void 0);
    } catch {
    }
  }
  var announcedAt = 0;
  function announceSubmit() {
    if (Date.now() - announcedAt < 3e3) return;
    announcedAt = Date.now();
    if (!alive()) return;
    tell({ type: "submit-clicked", answers: typedAnswers(), url: location.href });
    const until = Date.now() + 2e4;
    const timer = setInterval(() => {
      const text2 = (document.body.innerText || "").replace(/\s+/g, " ");
      const match = text2.match(CONFIRM_TEXT);
      if (match) {
        clearInterval(timer);
        const start = Math.max(0, (match.index ?? 0) - 40);
        tell({ type: "submitted-page", text: text2.slice(start, start + 200), url: location.href });
      } else if (Date.now() > until) clearInterval(timer);
    }, 700);
  }
  function watchSubmit() {
    document.addEventListener("click", (event) => {
      let target = event.target?.closest("button, input[type=submit], [data-automation-id='click_filter']");
      if (target?.matches("[data-automation-id='click_filter']")) target = buttonUnder(target) ?? target;
      if (target && SUBMIT.test((target.textContent || target.value || target.getAttribute("aria-label") || "").replace(/\s+/g, " ").trim())) announceSubmit();
    }, true);
  }
  if (!window.__unnepo || !window.__unnepo.alive()) {
    window.__unnepo = { scan: scanPage, fill, alive };
    watchSubmit();
    watchEdits();
    chrome.runtime.onMessage.addListener((message, _sender, reply) => {
      if (message?.type === "scan") {
        reply(scanPage());
        return false;
      }
      if (message?.type === "opened-job") {
        reply(openedJob());
        return false;
      }
      if (message?.type === "job-details") {
        reply(jobDetails());
        return false;
      }
      if (message?.type === "begin-applying") {
        reply(beginApplying(message.resume ?? null, (result) => tell({ type: "applying-changed", result })));
        return false;
      }
      if (message?.type === "attach-letter") {
        reply({ attached: uploadCoverLetterNow(scanFields(), message.file) });
        return false;
      }
      if (message?.type === "attach-resume") {
        reply({ attached: uploadResumeNow(scanFields(), message.file) });
        return false;
      }
      if (message?.type === "put-answer") {
        reply(putAnswer(String(message.id ?? ""), String(message.text ?? ""), Boolean(message.replace)));
        return false;
      }
      if (message?.type === "show-question") {
        reply({ ok: showQuestion(String(message.id ?? "")) });
        return false;
      }
      if (message?.type === "stop-applying") {
        clearQuestionSpiders();
        reply({ ok: true });
        return false;
      }
      if (message?.type === "spiders") {
        if (message.celebrate) celebrateSpiders();
        else if (message.on) startSpiders(Boolean(message.drop));
        else stopSpiders();
        reply({ ok: true });
        return false;
      }
      if (message?.type === "status") {
        const fields = scanFields();
        const action = findAction(Boolean(message.knownAccount), fields.length);
        const apply = findApply();
        reply({ needsYou: emptyRequired(fields).map((field) => field.label), action: action ? { kind: action.kind, label: action.label } : null, apply: apply ? (apply.textContent ?? "").trim() || "Apply" : null, captcha: scanPage().captcha, step: workdayStep(), reviewLeft: reviewLeft(), ...pageNotes() });
        return false;
      }
      if (message?.type === "leftovers") {
        const known = new Set(message.ids ?? []);
        const fields = scanFields().filter((field) => {
          const el = findMarked(field.id);
          if (!el || field.type === "file") return false;
          const control = el.matches("input, select, textarea, button") ? el : el.querySelector("input") ?? el;
          const ids = [control.id, control.name, el.id].filter(Boolean);
          return !ids.some((id) => known.has(id) || [...known].some((k) => id.startsWith(`${k}-`) || id.startsWith(`${k}_`))) && isEmpty(control);
        });
        void withOptions(fields).then((withChoices) => reply({ fields: withChoices }));
        return true;
      }
      if (message?.type === "mark-needs") {
        const check = (Array.isArray(message.check) ? message.check : []).map((item) => ({ label: String(item?.label ?? ""), why: String(item?.why ?? "") }));
        reply({ marked: markNeeds(Array.isArray(message.labels) ? message.labels.map(String) : [], check) });
        return false;
      }
      if (message?.type === "page-report") {
        const visible2 = (el) => el.getBoundingClientRect().height > 0;
        const label = (el) => (el.innerText || el.getAttribute("aria-label") || el.value || "").replace(/\s+/g, " ").trim();
        const buttons2 = [...new Set(Array.from(document.querySelectorAll("button, [role=button], a.btn, a[class*=button], input[type=submit]")).filter(visible2).map(label).filter((text2) => text2 && text2.length <= 40))].slice(0, 30);
        const headings = Array.from(document.querySelectorAll("h1, h2")).filter(visible2).map(label).filter(Boolean).slice(0, 4).map((text2) => text2.slice(0, 80));
        const posting = scanPage();
        const dialog = Boolean(document.querySelector("[role=dialog], [aria-modal='true'], dialog[open]"));
        reply({ path: location.pathname.slice(0, 120), title: document.title.slice(0, 120), headings, buttons: buttons2, postingData: Boolean(posting.description), job: { title: posting.title.slice(0, 120), company: posting.company.slice(0, 80) }, status: appliedStatus()?.text ?? "", dialog });
        return false;
      }
      if (message?.type === "focus-field") {
        reply({ ok: showField(String(message.label ?? "")) });
        return false;
      }
      if (message?.type === "press" && message.first) {
        const apply = findApply();
        const pressed = apply ? pressAction(apply) : null;
        reply({ pressed: Boolean(pressed), label: apply?.textContent?.trim(), what: pressed });
        return false;
      }
      if (message?.type === "press") {
        const fields = scanFields();
        const action = findAction(Boolean(message.knownAccount), fields.length);
        if (!action || action.kind !== message.kind) {
          reply({ pressed: false });
          return false;
        }
        if (action.kind === "submit") announceSubmit();
        const pressed = pressAction(action.el);
        reply({ pressed: Boolean(pressed), label: action.label, what: pressed });
        return false;
      }
      if (message?.type === "fill") {
        fill(message.plan).then(reply, (error) => reply({ filled: [], failed: [{ label: "Form", reason: error instanceof Error ? error.message : "couldn't fill" }], needsYou: [], captcha: false, submitted: false, ms: 0 }));
        return true;
      }
      return false;
    });
  }
})();
