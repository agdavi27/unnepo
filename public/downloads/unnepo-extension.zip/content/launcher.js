"use strict";
(() => {
  // lib/spiders.ts
  var SKINS = [
    { id: "classic", name: "Unnepo", unlockAt: 0, color: "#6E5B6E" },
    { id: "school", name: "School spirit", unlockAt: 0, color: "#6E5B6E" },
    { id: "blue", name: "Blue", unlockAt: 50, color: "#3D8BFF" },
    { id: "green", name: "Green", unlockAt: 150, color: "#2FBF71" },
    { id: "purple", name: "Purple", unlockAt: 300, color: "#9B5CFF" },
    { id: "gold", name: "Gold", unlockAt: 500, color: "#F2B227" },
    { id: "pink", name: "Pink", unlockAt: 1e3, color: "#FF5C9A" }
  ];
  var isSkin = (value) => SKINS.some((skin) => skin.id === value);
  var SCHOOL_STYLES = {
    "colby college": { color: "#002169", text: "#FFFFFF", letters: "C" },
    "university of vermont": { color: "#154734", text: "#FFD416", letters: "UVM" },
    "uvm": { color: "#154734", text: "#FFD416", letters: "UVM" },
    "university of pennsylvania": { color: "#011F5B", text: "#FFFFFF", letters: "P" },
    "university of pittsburgh": { color: "#003594", text: "#FFB81C", letters: "P" },
    "cornell university": { color: "#B31B1B", text: "#FFFFFF", letters: "C" },
    "columbia university": { color: "#6CACE4", text: "#FFFFFF", letters: "C" },
    "boston college": { color: "#8A100B", text: "#E0C48A", letters: "BC" },
    "new york university": { color: "#57068C", text: "#FFFFFF", letters: "NYU" },
    "university of washington": { color: "#4B2E83", text: "#B7A57A", letters: "W" },
    "university of texas at austin": { color: "#BF5700", text: "#FFFFFF", letters: "T" },
    "bowdoin college": { color: "#1A1A1A", text: "#FFFFFF", letters: "B" },
    "bates college": { color: "#881124", text: "#FFFFFF", letters: "B" },
    "middlebury college": { color: "#0D395F", text: "#FFFFFF", letters: "M" },
    "williams college": { color: "#500082", text: "#FFCC00", letters: "W" },
    "amherst college": { color: "#3F1F69", text: "#FFFFFF", letters: "A" },
    "brown university": { color: "#4E3629", text: "#ED1C24", letters: "B" },
    "dartmouth college": { color: "#00693E", text: "#FFFFFF", letters: "D" },
    "yale university": { color: "#00356B", text: "#FFFFFF", letters: "Y" },
    "harvard university": { color: "#A51C30", text: "#FFFFFF", letters: "H" },
    "princeton university": { color: "#E77500", text: "#121212", letters: "P" },
    "stanford university": { color: "#8C1515", text: "#FFFFFF", letters: "S" },
    "university of michigan": { color: "#00274C", text: "#FFCB05", letters: "M" },
    "university of california, berkeley": { color: "#003262", text: "#FDB515", letters: "CAL" },
    "georgetown university": { color: "#041E42", text: "#A7B1B7", letters: "G" },
    "duke university": { color: "#00539B", text: "#FFFFFF", letters: "D" },
    "northwestern university": { color: "#4E2A84", text: "#FFFFFF", letters: "N" }
  };
  var FALLBACK_COLORS = ["#1D4F91", "#7A1F2B", "#1F6B45", "#5B2C83", "#B35A00", "#0F5A6B"];
  var FILLER = /* @__PURE__ */ new Set(["of", "the", "at", "and", "for", "in"]);
  function schoolStyle(school) {
    const name = (school ?? "").replace(/\s+/g, " ").trim();
    if (!name) return null;
    const known = SCHOOL_STYLES[name.toLowerCase()];
    if (known) return known;
    const words = name.split(/[\s,-]+/).filter((word) => word && !FILLER.has(word.toLowerCase()));
    const general = words.filter((word) => !/^(college|university|school|institute)$/i.test(word));
    const letters = (words[0] && /^university$/i.test(words[0]) ? words : general.length ? general : words).map((word) => word[0]).join("").toUpperCase().slice(0, 3) || name[0].toUpperCase();
    const hash = [...name].reduce((sum, char) => sum * 31 + char.charCodeAt(0) >>> 0, 7);
    return { color: FALLBACK_COLORS[hash % FALLBACK_COLORS.length], text: "#FFFFFF", letters: letters.length === 2 && general.length === 1 ? letters[0] : letters };
  }
  function shade(hex, amount) {
    const value = parseInt(hex.replace("#", ""), 16);
    const target = amount > 0 ? 255 : 0;
    const mix = (channel) => Math.round(channel + (target - channel) * Math.abs(amount));
    const [r, g, b] = [value >> 16 & 255, value >> 8 & 255, value & 255].map(mix);
    return `#${(1 << 24 | r << 16 | g << 8 | b).toString(16).slice(1).toUpperCase()}`;
  }
  function spiderPalette(look) {
    if (look.skin === "classic") {
      return {
        o: "#000000",
        b: "#6E5B6E",
        h: "#B48FAE",
        d: "#4E3549",
        a: "#3D8BFF",
        e: "#3D8BFF",
        k: "#7E6580",
        K: "#5A4258",
        l: "#6E5B6E",
        L: "#4E3549",
        w: "#FFFFFF",
        m: "#1A0E14",
        f: "#F7F7F8",
        p: "#965E8C",
        t: "#FFFFFF",
        r: "#4E3549"
      };
    }
    const skin = SKINS.find((item) => item.id === look.skin) ?? SKINS[0];
    const style = look.skin === "school" ? schoolStyle(look.school) : null;
    const body = skin.color;
    const back = style?.color ?? body;
    return {
      o: "#000000",
      b: back,
      h: shade(back, 0.35),
      d: shade(back, -0.3),
      k: shade(body, 0.12),
      K: shade(body, -0.15),
      l: body,
      L: shade(body, -0.3),
      a: skin.id === "school" ? "#3D8BFF" : shade(body, 0.55),
      e: skin.id === "school" ? "#3D8BFF" : shade(body, 0.55),
      t: style?.text ?? "#FFFFFF",
      r: shade(back, -0.45),
      m: "#1A0E14",
      w: "#FFFFFF",
      f: "#F7F7F8",
      p: "#965E8C"
    };
  }
  function crawlerColors(look) {
    if (look.skin === "classic") return {};
    const palette = spiderPalette(look);
    return { b: palette.b, s: palette.h, l: palette.L };
  }

  // extension/src/shared/sprite.ts
  var W = 20;
  var H = 17;
  var COLORS = { o: "#000000", b: "#2B2531", s: "#4A4252", l: "#1B171F", w: "#EAF6F2", p: "#1B171F", c: "#F2949E" };
  function spiderGrid(step) {
    const g = Array.from({ length: H }, () => Array(W).fill(""));
    const set = (x, y, c) => {
      if (x >= 0 && x < W && y >= 0 && y < H) g[y][x] = c;
    };
    const legs = step === 0 ? [[[6, 6], [5, 5], [4, 4], [4, 3], [3, 2]], [[5, 8], [4, 7], [3, 7], [2, 7], [1, 8]], [[5, 10], [4, 10], [3, 11], [2, 11], [2, 12]], [[6, 12], [5, 13], [4, 14], [4, 15]]] : [[[6, 6], [5, 5], [5, 4], [4, 3], [4, 2]], [[5, 8], [4, 8], [3, 8], [2, 8], [1, 9]], [[5, 10], [4, 11], [3, 11], [3, 12], [2, 13]], [[6, 12], [6, 13], [5, 14], [5, 15]]];
    for (const leg of legs) for (const [x, y] of leg) {
      set(x, y, "l");
      set(W - 1 - x, y, "l");
    }
    for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
      const nx = (x + 0.5 - 10) / 4.6, ny = (y + 0.5 - 9.2) / 5;
      if (nx * nx + ny * ny <= 1) set(x, y, "b");
    }
    for (const ex of [6, 11]) for (let dx = 0; dx < 3; dx++) for (let dy = 0; dy < 3; dy++) set(ex + dx, 5 + dy, "w");
    set(7, 6, "p");
    set(12, 6, "p");
    set(5, 8, "c");
    set(14, 8, "c");
    set(11, 11, "s");
    const out = g.map((row) => row.slice());
    for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
      if (g[y][x]) continue;
      if ([[1, 0], [-1, 0], [0, 1], [0, -1]].some(([dx, dy]) => g[y + dy]?.[x + dx])) out[y][x] = "o";
    }
    return out;
  }
  function spiderRects(step, colors = {}) {
    const out = spiderGrid(step);
    const palette = { ...COLORS, ...colors };
    let rects = "";
    for (let y = 0; y < H; y++) {
      let x = 0;
      while (x < W) {
        const c = out[y][x];
        if (!c) {
          x++;
          continue;
        }
        let w = 1;
        while (x + w < W && out[y][x + w] === c) w++;
        rects += `<rect x="${x}" y="${y}" width="${w}" height="1" fill="${palette[c]}"/>`;
        x += w;
      }
    }
    return rects;
  }
  async function storedSpiderColors() {
    try {
      const { spider } = await chrome.storage.local.get("spider");
      return spider && isSkin(spider.skin) ? crawlerColors(spider) : {};
    } catch {
      return {};
    }
  }

  // extension/src/content/quick-apply.ts
  var QUICK_BOARDS = /(^|\.)((joinhandshake|linkedin|ziprecruiter|indeed|simplyhired|wellfound|glassdoor|dice|builtin|monster|careerbuilder|wayup)\.com|simplify\.jobs|idealist\.org|usajobs\.gov)$/;
  var APPLY_PRESS = /^(1-click apply|one-click apply|quick apply|easy apply|instant apply|apply|apply now|submit( my)? application|send( my)? application|submit|apply with (my )?(profile|resume))$/i;
  var FINAL_PRESS = /1-click|one-click|quick apply|instant apply|submit|send|apply with/i;
  var ELSEWHERE = /externally|company('|’)?s? (site|website)|employer('|’)?s? (site|website)|on company site/i;
  var APPLIED_NOW = /^([✓✔☑]\s*)?((you )?applied|application (sent|submitted|received|complete)|you(?:'|’| ha)ve applied|already applied|your application (was |has been )?(sent|submitted|received))\b.{0,40}$/i;
  var NOT_STATUS = /^([✓✔☑]\s*)?applied (scientist|research|mathematics|physics|ai|ml|machine|data|economist|statistic|behavior|linguist)/i;
  var shortText = (el) => (el.innerText || el.textContent || "").replace(/\s+/g, " ").trim();
  var shown = (el) => el.getBoundingClientRect().height > 0;
  function appliedLabels() {
    const counts = /* @__PURE__ */ new Map();
    for (const el of Array.from(document.querySelectorAll("button, a, [role=button], [role=status], [role=alert], span, p, div, li, time, small, strong, h2, h3, h4"))) {
      if (el.closest("[data-unnepo-launcher]")) continue;
      const text = shortText(el);
      if (!text || text.length > 80 || !shown(el) || !APPLIED_NOW.test(text) || NOT_STATUS.test(text)) continue;
      if (Array.from(el.children).some((child) => shortText(child) === text)) continue;
      counts.set(text, (counts.get(text) ?? 0) + 1);
    }
    return counts;
  }
  function newLabel(before, now) {
    for (const [text, count] of now) if (count > (before.get(text) ?? 0)) return text;
    return "";
  }
  function watchApplyPresses(tell) {
    let watching = 0;
    document.addEventListener("click", (event) => {
      const button = event.target?.closest("button, a, [role=button], input[type=submit]");
      const label = button ? shortText(button) || button.value || "" : "";
      if (!button) return;
      const mark = () => {
        document.querySelectorAll("[data-unnepo-pressed]").forEach((el) => el.removeAttribute("data-unnepo-pressed"));
        button.setAttribute("data-unnepo-pressed", String(Date.now()));
      };
      if (ELSEWHERE.test(label) || /^apply( now)? (on|at) /i.test(label)) {
        mark();
        tell({ type: "apply-clicked", url: location.href, label, final: false, elsewhere: true });
        return;
      }
      if (!APPLY_PRESS.test(label)) return;
      mark();
      tell({ type: "apply-clicked", url: location.href, label, final: FINAL_PRESS.test(label) });
      const before = appliedLabels();
      const run = ++watching;
      const started = Date.now();
      const check = () => {
        if (run !== watching) return;
        const said = `${shortText(button)} ${button.getAttribute("aria-label") ?? ""}`.trim();
        const changed = button.isConnected && (APPLIED_NOW.test(shortText(button)) || /\bapplied\b/i.test(said) && (button.disabled || button.getAttribute("aria-disabled") === "true"));
        const added = newLabel(before, appliedLabels());
        if (changed || added) {
          tell({ type: "applied-detected", text: (changed ? shortText(button) : added).slice(0, 120), url: location.href });
          return;
        }
        if (Date.now() - started < 12e4) setTimeout(check, 700);
      };
      setTimeout(check, 700);
    }, true);
  }

  // extension/src/content/edits.ts
  var EDITED = "data-unnepo-edited";
  var opened = null;
  var fieldOf = (el) => el.closest("[data-unnepo-id]") ?? el;
  function touch(el) {
    el.setAttribute(EDITED, "");
    fieldOf(el).setAttribute(EDITED, "");
    if (el instanceof HTMLInputElement && (el.type === "radio" || el.type === "checkbox") && el.name) {
      const root = el.getRootNode();
      root.querySelectorAll(`input[name="${CSS.escape(el.name)}"]`).forEach((item) => item.setAttribute(EDITED, ""));
    }
  }
  function targetOf(event) {
    const target = event.composedPath()[0];
    return target instanceof Element ? target : null;
  }
  function watchEdits() {
    if (window.__unnepoEdits) return;
    window.__unnepoEdits = true;
    const onEdit = (event) => {
      const target = targetOf(event);
      if (event.isTrusted && target?.matches("input, select, textarea, [contenteditable]")) touch(target);
    };
    document.addEventListener("input", onEdit, true);
    document.addEventListener("change", onEdit, true);
    document.addEventListener("pointerdown", (event) => {
      const target = targetOf(event);
      if (!event.isTrusted || !target) return;
      const option = target.closest("[role=option], [data-automation-id*='promptOption' i]");
      if (option) {
        if (opened?.isConnected) touch(opened);
      } else {
        opened = target.closest("[data-unnepo-id], [role=combobox], [aria-haspopup=listbox]");
      }
    }, true);
    document.addEventListener("keydown", (event) => {
      const target = targetOf(event);
      if (event.isTrusted && target && event.key === "Enter" && target.closest("[role=combobox], [aria-haspopup=listbox]")) touch(target);
    }, true);
  }

  // lib/apply/job-title.ts
  var MONTH = "(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\\.?";
  var WHEN = `( on .+| \\d+ ?(m|min|minutes?|h|hours?|d|days?|w|weeks?|months?) ago| today| yesterday| just now| ${MONTH} \\d{1,2}.*| \\d{1,2}/\\d{1,2}.*)`;
  var STATUS = new RegExp(
    `^([\u2713\u2714\u2611]\\s*)?(applied${WHEN}?[.!]?|you(?:'|\u2019| ha)ve applied.*|you applied.*|already applied.*|application (sent|submitted|received|complete|completed|viewed|in progress)\\b.*|your application (was |has been )?(sent|submitted|received).*|(saved|viewed|submitted|withdrawn|archived|not interested)${WHEN}?|(posted|updated|reposted|closes|closing|deadline)\\b.*|no longer accepting.*|this job (has )?(expired|closed).*|(apply|applying) (to|for|at) .+|(details|questions|documents|attachments|information|info) (from|for) .+)$`,
    "i"
  );
  var DATE_ONLY = new RegExp(`^${MONTH} \\d{1,2}(, \\d{4})?$`, "i");
  var PAGE_NAME = /^(jobs?|job search|search( jobs| results)?|find (a )?jobs?|browse jobs|all jobs|saved jobs|recommended( jobs)?|jobs for you|job (postings?|board|listings?)|postings?|listings?|careers?|career (center|centre|services)|home|explore|discover|internships?( and jobs)?|opportunities|open (roles|positions)|positions|(my )?applications|messages|inbox|events|employers|companies|dashboard|feed|notifications|profile)$/i;
  var SITE_MENU = /^(\d+\+? (new |unread )?(notifications?|messages?|alerts?)|(new |unread )?(notifications?|messages?) \(\d+\)|my network|messaging|me|for business|try premium.*|skip to (main )?content|home|jobs home)$/i;
  var SITE_TALK = /\b(your feedback|feedback helps|give feedback|share (your )?feedback|are these (results|jobs) (helpful|relevant)|(was|is) this (page |job |result )?(helpful|relevant)|rate (this|your)|take (our|a|the) survey|how (are|did) we do|sign in to|log in to|join (now )?to (see|view|apply)|create (an|your) account|something went wrong|page (not found|unavailable)|access denied|verify (you are|you're) (a )?human|no longer available|we use cookies|accept (all )?cookies|showing \d+|\d+[,\d]* (results|jobs|openings)|results? for\b|jobs? (you may|you might|based on|recommended)|similar jobs|people also viewed|try premium|premium members)\b/i;
  var SITE_PROMO = /(\bstay (on top of|up to date|in the loop)\b|\bjob alerts?\b|\b(set|create|turn on|get|manage) (an? |your |job )?alerts?\b|\bget notified\b|\bnotify me\b|\bnew (job )?openings\b|\bnever miss\b|©|\(c\) \d{4}|\bcopyright\b|\ball rights reserved\b|\bcorporation\b.*\d{3}|\b(user agreement|privacy policy|cookie policy|copyright policy|community guidelines|about accessibility|brand policy|guest controls)\b|\bopen to work\b|\bupdate your (profile|preferences)\b)/i;
  var SENTENCE_START = /^(are|is|was|were|do|does|did|can|could|would|should|will|have|has|how|what|why|when|where|who|which|we|we're|we've|you|you're|your|our|this|these|that|please|thanks|thank you|sorry|oops|welcome|hi|hello|looking for|want to|ready to|don't|didn't)\b/i;
  function siteSentence(line) {
    const words = line.split(" ").length;
    if (SITE_TALK.test(line) || SITE_PROMO.test(line)) return true;
    if (/\?/.test(line)) return true;
    if (/[.!…]\s+\S/.test(line) || /\.\.\.$|…$/.test(line) && words > 4) return true;
    if (SENTENCE_START.test(line) && words >= 3) return true;
    return words > 16;
  }
  function notJobTitle(text) {
    const line = text.replace(/\s+/g, " ").trim();
    return line.length < 2 || line.length > 150 || STATUS.test(line) || DATE_ONLY.test(line) || PAGE_NAME.test(line) || SITE_MENU.test(line) || siteSentence(line);
  }
  var COMPANY_BEFORE = [
    /^(see|view|browse|explore|find|show|discover|check out)( all| more| other| open)? (jobs|openings|roles|positions|careers|opportunities|internships)( at| from| with| by)\s+/i,
    /^(more|other|all|open|similar)? ?(jobs|openings|roles|positions|careers|opportunities|internships) (at|from|with|by)\s+/i,
    /^(learn more about|more about|about|visit|follow|following|followed|work at|working at|life at|careers at|go to|company:|employer:|posted by|hiring company:?)\s+/i,
    /^(company |employer )?(logo|image|avatar|picture)( of| for)?\s+/i,
    // An apply pop-up's headings: "Details from Runway Services", "Apply to Runway Services".
    /^(details|questions|documents|attachments|information|info) from\s+/i,
    /^(apply|applying) (to|at)\s+/i
  ];
  var COMPANY_AFTER = [
    /\s*[·|•–—-]\s*(follow|following|view profile|\d[\d.,]*\s*(reviews?|followers?|employees|ratings?|jobs?)).*$/i,
    /\s*\d(\.\d)?\s*(★|☆|stars?|out of 5).*$/i,
    /\s*\(opens in a new (tab|window)\)$/i,
    /['’]s\s+(logo|jobs|careers|profile|page)$/i,
    /\s+(jobs|careers|careers page|job openings|openings|company profile|profile|reviews|logo|page)$/i,
    /\s+(is hiring|hiring now|is now hiring|now hiring)$/i,
    /\s*[→›»>]+$/
  ];
  function cleanCompanyName(raw) {
    let name = raw.replace(/\s+/g, " ").trim();
    for (let round = 0; round < 4; round += 1) {
      const before = name;
      for (const pattern of [...COMPANY_BEFORE, ...COMPANY_AFTER]) name = name.replace(pattern, "").trim();
      name = name.replace(/^[\s:,.–—-]+|[\s:,–—-]+$/g, "").trim();
      if (name === before) break;
    }
    return name;
  }

  // extension/src/content/scan.ts
  var clean = (text) => (text ?? "").replace(/\s+/g, " ").replace(/\b(select one|required)\b/gi, "").replace(/[*✱]/g, "").trim();
  function visible(el) {
    const style = window.getComputedStyle(el);
    const rect = el.getBoundingClientRect();
    return style.display !== "none" && style.visibility !== "hidden" && (rect.width > 0 || rect.height > 0);
  }
  var outsideDialog = (el) => !el.closest("[role=dialog], [role=alertdialog], [aria-modal='true'], dialog");
  var LINKEDIN_HOST = /(^|\.)linkedin\.com$/;
  function linkedinJobId(href) {
    try {
      const url = new URL(href);
      if (!LINKEDIN_HOST.test(url.hostname)) return "";
      return url.pathname.match(/\/jobs\/view\/(?:[^/]*?-)?(\d{6,})/)?.[1] ?? url.searchParams.get("currentJobId") ?? "";
    } catch {
      return "";
    }
  }
  var JOB_SITE_NAME = /^(workday|greenhouse|lever|ashby|icims|smartrecruiters|jobvite|taleo|workable|careers?|jobs?|job application|handshake|ziprecruiter|indeed|glassdoor|wellfound|dice|simplify|built ?in|monster|simplyhired|careerbuilder|wayup|idealist|usajobs|linkedin)$/i;
  var BOARD_SUFFIX = /\s*[|·–—-]\s*(handshake|ziprecruiter|indeed(\.com)?|glassdoor|wellfound|dice|simplify|built ?in[a-z ]*|monster(\.com)?|simplyhired|careerbuilder|wayup|idealist|usajobs|linkedin)\s*$/i;
  function titleParts(text) {
    const plainText = text.replace(/^\(\d+\)\s*/, "").replace(/\s+/g, " ").trim();
    if (!BOARD_SUFFIX.test(plainText) && !/ at | hiring /i.test(plainText)) return null;
    const bare = plainText.replace(BOARD_SUFFIX, "").replace(/\s+(job|jobs)$/i, "").trim();
    const hiring = bare.match(/^(.{2,80}?) (?:is )?hiring (?:for )?(?:an? )?(.{2,120}?)(?: (?:job )?in .{2,60})?$/i);
    if (hiring) return { title: hiring[2].trim(), company: hiring[1].trim() };
    const at = bare.match(/^(.{2,120}?)(?: job)? at (.{2,80}?)(?:\s*[-–|,·]\s*.{2,60})?$/i);
    if (at) return { title: at[1].trim(), company: at[2].trim() };
    const parts = bare.split(/\s+[|·–—-]\s+/).map((part) => part.trim()).filter(Boolean);
    if (parts.length >= 2 && !JOB_SITE_NAME.test(parts[1])) return { title: parts[0], company: parts[1] };
    return null;
  }
  var JOB_HREF = /\/(jobs?|job-search|stu\/jobs|viewjob|job-listing|job-detail|jobs\/view|rc\/clk|partner\/joblisting\.htm|c\/[^/]+\/job)(\/|\?|$|\.htm)|[?&](jk|vjk|jid|jl|joblistingid|currentjobid|jobid|job_id)=/i;
  var APPLY_LABEL = /^(1-click apply|one-click apply|quick apply|easy apply|instant apply|apply|apply now|apply externally|apply on company (site|website)|apply on employer site|apply with (my )?(profile|resume)|i'?m interested)$/i;
  var COMPANY_LINK = "a[href*='/company/'], a[href*='/cmp/'], a[href*='/companies/'], a[href*='/e/'], a[href*='/emp/'], a[href*='/employers/'], a[href*='/organizations/'], a[href*='/Overview/'], a[href*='/c/']";
  var COMPANY_NAMED = "[data-testid*='company' i], [data-testid*='employer' i], [data-test*='employer' i], [data-test*='company' i], [data-hook*='employer' i], [data-hook*='company' i], [class*='companyName' i], [class*='company-name' i], [class*='employer-name' i], [class*='employerName' i], [class*='employer_name' i], [itemprop='hiringOrganization']";
  var distinctJobLinks = (root) => {
    const seen = /* @__PURE__ */ new Set();
    const links = [...root.matches("a[href]") ? [root] : [], ...Array.from(root.querySelectorAll("a[href]"))];
    for (const a of links) {
      try {
        const url = new URL(a.href);
        if (JOB_HREF.test(`${url.pathname}${url.search}`)) seen.add(`${url.pathname}?${["jk", "vjk", "jid", "jl", "jobListingId", "currentJobId", "jobId"].map((key) => url.searchParams.get(key) ?? "").join("|")}`);
      } catch {
      }
    }
    return seen.size;
  };
  var sameName = (a, b) => {
    const word = (text) => text.toLowerCase().replace(/[^a-z0-9]+/g, " ").trim();
    const [x, y] = [word(a), word(b)];
    return Boolean(x && y) && (x === y || x.startsWith(y) || y.startsWith(x));
  };
  function jobLink(href) {
    try {
      const url = new URL(href);
      const indeedJob = /(^|\.)indeed\.com$/.test(url.hostname) ? url.searchParams.get("jk") ?? url.searchParams.get("vjk") : null;
      if (indeedJob) return `${url.origin}/viewjob?jk=${indeedJob}`;
      const linkedin = linkedinJobId(url.href);
      if (linkedin) return `https://www.linkedin.com/jobs/view/${linkedin}/`;
      return url.href;
    } catch {
      return href;
    }
  }
  var NOT_COMPANY = /^(app|www|my|portal|localhost|students?|jobs?|careers?|employers?|companies|company|organization|job board|logo|image|avatar|profile|view profile|follow|following|message|save|saved|share|report|apply|more|see more|show more|about|overview|reviews?|salaries|benefits|united states|usa|us|remote|hybrid|on-?site)$/i;
  var LOCATION = /^[A-Z][a-zA-Z .'-]+, ([A-Z]{2}|[A-Z][a-z]+)( \d{5})?$|^(remote|hybrid|on-?site)\b/i;
  function goodEmployer(raw, title) {
    const text = raw.trim();
    return text.length >= 2 && text.length <= 80 && !sameName(text, title) && !notJobTitle(text) && !NOT_EMPLOYER.test(text) && !NOT_COMPANY.test(text) && !JOB_SITE_NAME.test(text) && !LOCATION.test(text) && !/^https?:|\.(com|org|io|net)$/i.test(text) && /[a-z]/i.test(text);
  }
  var firstPart = (text) => cleanCompanyName(cleanCompanyName(clean(text)).split(/\s+[·|•–—]\s+|\s-\s|\n/)[0]);
  function employerIn(pane, heading, title) {
    const pick = (values) => values.map((value) => firstPart(value ?? "")).find((value) => goodEmployer(value, title)) ?? "";
    const shown3 = (el) => visible(el);
    const named = pick(Array.from(pane.querySelectorAll(COMPANY_NAMED)).filter(shown3).map((el) => el.innerText || el.textContent || el.getAttribute("aria-label")));
    if (named) return named;
    const linked = pick(Array.from(pane.querySelectorAll(COMPANY_LINK)).filter(shown3).map((a) => clean(a.innerText || a.textContent) || a.getAttribute("aria-label") || a.querySelector("img")?.alt || a.title));
    if (linked) return linked;
    let near = heading?.parentElement ?? null;
    for (let level = 0; near && level < 4 && near !== pane.parentElement; level += 1, near = near.parentElement) {
      const logo = pick(Array.from(near.querySelectorAll("img[alt], [role=img][aria-label], [aria-label*='logo' i]")).map((el) => el.alt || el.getAttribute("aria-label")));
      if (logo) return logo;
    }
    const about = pick(Array.from(pane.querySelectorAll("h2, h3, h4, strong")).map((el) => clean(el.textContent).match(/^about (?!the |this |us$|the$)(.{2,60})$/i)?.[1]));
    if (about) return about;
    const lines = (pane.innerText || "").split("\n").map((line) => clean(line)).filter(Boolean);
    const at = lines.findIndex((line) => sameName(line, title));
    if (at >= 0) {
      const beside = pick([lines[at - 1], lines[at + 1], lines[at - 2], lines[at + 2]]);
      if (beside) return beside;
    }
    const fromTitle = titleParts(document.title)?.company;
    if (fromTitle && goodEmployer(fromTitle, title)) return fromTitle;
    const text = (pane.innerText || "").slice(0, 6e3);
    const said = text.match(/\b([A-Z][\w&.'’-]*(?: [A-Z][\w&.'’-]*){0,3}) (?:is hiring|is looking for|is seeking|seeks)\b/)?.[1] ?? text.match(/\b(?:Join|At|About) ([A-Z][\w&.'’-]*(?: [A-Z][\w&.'’-]*){0,3})(?:,| we\b| is\b|!|\.)/)?.[1];
    return said && goodEmployer(said, title) ? said : "";
  }
  var NOT_EMPLOYER = /^(remote|hybrid|on-?site|in person|full[- ]time|part[- ]time|internship|contract|\$|\d|posted|new|today|easy apply|apply)/i;
  function jobPane() {
    const marked = document.querySelector("[data-unnepo-pressed]");
    const pressed = marked && marked.isConnected && visible(marked) && outsideDialog(marked) && Date.now() - Number(marked.dataset.unnepoPressed) < 10 * 6e4 ? marked : null;
    const button = pressed ?? Array.from(document.querySelectorAll("button, a, [role=button]")).find((el) => visible(el) && outsideDialog(el) && (APPLY_LABEL.test(clean(el.textContent)) || /^([✓✔]\s*)?applied\b/i.test(clean(el.textContent))));
    const start = button ?? Array.from(document.querySelectorAll("h1, h2")).find((el) => visible(el) && outsideDialog(el));
    if (!start) return document.body;
    let pane = start;
    while (pane.parentElement && pane.parentElement !== document.body && distinctJobLinks(pane.parentElement) <= 1) pane = pane.parentElement;
    return pane;
  }
  function employerOf(box, title) {
    const heading = Array.from(box.querySelectorAll("h1, h2, h3, h4, a")).find((el) => sameName(clean(el.textContent), title)) ?? null;
    return employerIn(box, heading, title);
  }

  // extension/src/content/board-status.ts
  var clean2 = (text) => (text ?? "").replace(/\s+/g, " ").trim();
  var shown2 = (el) => el.getBoundingClientRect().height > 0;
  var MONTHS = ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"];
  var MONTH2 = "(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\\.?";
  var WHEN2 = `(${MONTH2} \\d{1,2}(?:st|nd|rd|th)?(?:,? \\d{4})?|\\d{1,2}/\\d{1,2}(?:/\\d{2,4})?|\\d{4}-\\d{2}-\\d{2}|\\d+ ?(?:s|sec|seconds?|m|mins?|minutes?|h|hrs?|hours?|d|days?|w|wks?|weeks?|mo|months?) ago|today|yesterday|just now)`;
  var APPLIED_LINE = new RegExp(`^([\u2713\u2714\u2611]\\s*)?(you )?(applied|application (?:submitted|sent|received)|submitted)[\\s:\xB7\u2022,-]*(on\\s+)?${WHEN2}\\.?$`, "i");
  var APPLIED_BARE = /^([✓✔☑]\s*)?(applied|already applied|you(?:'|’)ve applied|application (submitted|sent))!?$/i;
  function appliedDay(text, now = /* @__PURE__ */ new Date()) {
    const iso = (date) => `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
    const lower = text.toLowerCase();
    if (/\b(today|just now|\d+ ?(s|sec|seconds?|m|mins?|minutes?|h|hrs?|hours?) ago)\b/.test(lower)) return iso(now);
    if (/\byesterday\b/.test(lower)) return iso(new Date(now.getFullYear(), now.getMonth(), now.getDate() - 1));
    const ago = lower.match(/\b(\d+) ?(d|days?|w|wks?|weeks?|mo|months?) ago\b/);
    if (ago) {
      const n = Number(ago[1]);
      const days = /^d/.test(ago[2]) ? n : /^w/.test(ago[2]) ? n * 7 : n * 30;
      return iso(new Date(now.getFullYear(), now.getMonth(), now.getDate() - days));
    }
    const isoDay = lower.match(/\b(\d{4})-(\d{2})-(\d{2})\b/);
    if (isoDay) return `${isoDay[1]}-${isoDay[2]}-${isoDay[3]}`;
    const named = lower.match(new RegExp(`\\b${MONTH2} (\\d{1,2})(?:st|nd|rd|th)?(?:,? (\\d{4}))?`));
    if (named) {
      const month = MONTHS.indexOf(named[1].slice(0, 3));
      let date = new Date(named[3] ? Number(named[3]) : now.getFullYear(), month, Number(named[2]));
      if (!named[3] && date.getTime() > now.getTime() + 864e5) date = new Date(now.getFullYear() - 1, month, Number(named[2]));
      return iso(date);
    }
    const slash = lower.match(/\b(\d{1,2})\/(\d{1,2})(?:\/(\d{2,4}))?\b/);
    if (slash) {
      const year = slash[3] ? slash[3].length === 2 ? 2e3 + Number(slash[3]) : Number(slash[3]) : now.getFullYear();
      return iso(new Date(year, Number(slash[1]) - 1, Number(slash[2])));
    }
    return "";
  }
  function appliedStatus(root = jobPane()) {
    const candidates = Array.from(root.querySelectorAll("span, p, div, li, time, strong, small, button, a, [role=status], [role=button], h2, h3, h4, h5")).filter((el) => !el.closest("[role=dialog], [aria-modal='true'], dialog"));
    for (const el of candidates) {
      const text = clean2(el.innerText || el.textContent);
      if (!text || text.length > 70 || !shown2(el)) continue;
      if (APPLIED_LINE.test(text)) return { text, day: appliedDay(text) };
      const control = el.matches("button, a, [role=button], [role=status]") || el.getAttribute("aria-disabled") === "true" || el.disabled;
      if (control && APPLIED_BARE.test(text)) return { text, day: "" };
    }
    return null;
  }
  function isAppliedListPage(where = window.location) {
    const { hostname: host, pathname: path, search } = where;
    if (/(^|\.)joinhandshake\.com$/.test(host)) return /^\/(stu\/)?applications\b/.test(path);
    if (/(^|\.)linkedin\.com$/.test(host)) return /^\/my-items\/saved-jobs/.test(path) && /cardType=APPLIED/i.test(search) || /^\/jobs-tracker/.test(path) && /stage=applied/i.test(search);
    if (/(^|\.)ziprecruiter\.com$/.test(host)) return /^\/(candidate\/)?(my-jobs|applications|applied)/.test(path);
    if (/(^|\.)indeed\.com$/.test(host)) return /^myjobs\./.test(host) || /^\/myjobs/.test(path);
    if (/(^|\.)glassdoor\.com$/.test(host)) return /applied/i.test(path);
    return false;
  }
  function appliedList() {
    const out = [];
    const seen = /* @__PURE__ */ new Set();
    for (const link of Array.from(document.querySelectorAll("a[href]"))) {
      let path = "";
      try {
        const url2 = new URL(link.href);
        path = `${url2.pathname}${url2.search}`;
      } catch {
        continue;
      }
      if (!JOB_HREF.test(path) || !shown2(link)) continue;
      const url = jobLink(link.href);
      if (seen.has(url)) continue;
      let card = link;
      while (card.parentElement && card.parentElement !== document.body && distinctJobLinks(card.parentElement) <= 1) card = card.parentElement;
      const lines = (card.innerText || "").split("\n").map(clean2).filter(Boolean);
      const ownText = clean2(link.innerText || link.textContent || link.getAttribute("aria-label"));
      const usable = (line2) => line2.length >= 3 && line2.length <= 150 && !notJobTitle(line2) && !APPLY_LABEL.test(line2) && !APPLIED_LINE.test(line2) && !/^(new|applied|view|view job|see job|withdraw|archive|status|promoted|easy apply)$/i.test(line2);
      const title = usable(ownText) ? ownText : lines.find(usable) ?? "";
      if (!title) continue;
      const company = employerOf(card, title) || lines[lines.indexOf(title) + 1] || "";
      if (!company || company === title) continue;
      const line = lines.find((text) => /\bappl(ied|ication)\b/i.test(text) && appliedDay(text)) ?? "";
      seen.add(url);
      out.push({ title: title.slice(0, 200), company: company.slice(0, 200), url, day: line ? appliedDay(line) : "" });
      if (out.length >= 100) break;
    }
    return out;
  }

  // extension/src/content/launcher.ts
  var ATS_HOST = /(myworkdayjobs|myworkdaysite|greenhouse|lever\.co|ashbyhq|workable|smartrecruiters|icims|jobvite|bamboohr|paycomonline|paylocity|ultipro|ukg|taleo|successfactors|breezy\.hr|recruitee|teamtailor|rippling|applytojob|dayforcehcm|oraclecloud|eightfold|avature|phenom|gem\.com|dover\.com|wellfound)\./i;
  var APPLY = /^(apply( now| for this (job|position|role|opportunity)| here| online| today)?|i(?:'|’)?m interested|start (my |your )?application|easy apply)$/i;
  var DISMISSED = "unnepo-launcher-dismissed";
  function looksLikeJobPage() {
    if (ATS_HOST.test(location.hostname)) return true;
    const buttons = Array.from(document.querySelectorAll("a, button, [role=button], input[type=submit]"));
    if (buttons.some((el) => APPLY.test((el.textContent || el.value || "").replace(/\s+/g, " ").trim()))) return true;
    const fields = document.querySelectorAll("input:not([type=hidden]):not([type=search]), textarea, select").length;
    if (document.querySelector("input[type=file]") && fields >= 3) return true;
    return fields >= 6 && /\b(resume|cv|cover letter|work authori[sz]ation|years of experience)\b/i.test(document.body.innerText || "");
  }
  function show() {
    if (document.querySelector("[data-unnepo-launcher]")) return;
    const host = document.createElement("div");
    host.setAttribute("data-unnepo-launcher", "");
    const root = host.attachShadow({ mode: "closed" });
    const reduce = matchMedia("(prefers-reduced-motion: reduce)").matches;
    root.innerHTML = `
    <style>
      :host { all: initial; position: fixed; top: 0; right: 22px; z-index: 2147483646; font: 13px/1.3 system-ui, -apple-system, sans-serif; }
      .wrap { position: relative; display: flex; flex-direction: column; align-items: center; animation: ${reduce ? "none" : "drop .9s cubic-bezier(.3,1.5,.6,1) both"}; }
      .thread { width: 2px; height: 96px; background: linear-gradient(90deg, #000 0 1px, #EAF6F2 1px 2px); }
      .spider { all: unset; cursor: pointer; display: block; width: 48px; height: ${Math.round(48 * H / W)}px; filter: drop-shadow(2px 3px 0 rgba(0,0,0,.2)); animation: ${reduce ? "none" : "sway 3.2s steps(4) 1s infinite"}; transform-origin: 50% -96px; }
      .spider svg { display: block; width: 100%; height: 100%; transform: rotate(180deg); }
      .spider:focus-visible { outline: 3px solid #3D8BFF; outline-offset: 4px; border-radius: 6px; }
      .tip { position: absolute; right: 58px; top: 104px; white-space: nowrap; background: #F7F7F8; color: #070708; border: 3px solid #070708; box-shadow: 0 0 0 2px #F7F7F8, 4px 4px 0 2px #3D8BFF; padding: 6px 10px; font-weight: 600; opacity: 0; transform: translateX(6px); transition: opacity .15s, transform .15s; pointer-events: none; }
      .wrap:hover .tip, .spider:focus-visible ~ .tip, .tip.say { opacity: 1; transform: none; }
      .close { all: unset; position: absolute; top: 96px; right: -14px; width: 18px; height: 18px; border-radius: 50%; background: #070708; color: #F7F7F8; font-size: 12px; line-height: 18px; text-align: center; cursor: pointer; opacity: 0; transition: opacity .15s; }
      .wrap:hover .close, .close:focus-visible { opacity: 1; }
      @keyframes drop { from { transform: translateY(-150px); } to { transform: none; } }
      @keyframes sway { 0%, 100% { transform: rotate(0); } 25% { transform: rotate(4deg); } 75% { transform: rotate(-4deg); } }
    </style>
    <div class="wrap">
      <div class="thread"></div>
      <button class="spider" type="button" aria-label="Fill this application with Unnepo"><svg viewBox="0 0 ${W} ${H}" shape-rendering="crispEdges" aria-hidden="true">${spiderRects(0)}</svg></button>
      <span class="tip" role="status">Fill with Unnepo</span>
      <button class="close" type="button" aria-label="Hide the Unnepo spider on this site">\xD7</button>
    </div>`;
    void storedSpiderColors().then((colors) => {
      const svg = root.querySelector(".spider svg");
      if (svg && Object.keys(colors).length) svg.innerHTML = spiderRects(0, colors);
    });
    const tip = root.querySelector(".tip");
    const say = (words) => {
      tip.textContent = words;
      tip.classList.add("say");
      setTimeout(() => {
        tip.classList.remove("say");
        tip.textContent = "Fill with Unnepo";
      }, 4e3);
    };
    root.querySelector(".spider").addEventListener("click", () => {
      let reachable = false;
      try {
        reachable = Boolean(chrome.runtime?.id);
      } catch {
        reachable = false;
      }
      if (!reachable) return say("Unnepo was updated. Refresh this page");
      try {
        chrome.runtime.sendMessage({ type: "open-panel" }).then((result) => {
          if (!result?.ok) say("Click the Unnepo icon in your toolbar");
        }, () => say("Refresh this page to use Unnepo"));
      } catch {
        say("Refresh this page to use Unnepo");
      }
    });
    const hideFor = (open) => {
      host.style.display = open ? "none" : "";
    };
    try {
      chrome.runtime.onMessage.addListener((message) => {
        if (message?.type === "panel") hideFor(message.open);
      });
      void chrome.runtime.sendMessage({ type: "panel-state" }).then((state) => hideFor(state?.open), () => void 0);
    } catch {
    }
    root.querySelector(".close").addEventListener("click", () => {
      try {
        sessionStorage.setItem(DISMISSED, "1");
      } catch {
      }
      host.remove();
    });
    document.documentElement.appendChild(host);
  }
  function dismissed() {
    try {
      return sessionStorage.getItem(DISMISSED) === "1";
    } catch {
      return false;
    }
  }
  var RECEIVED = /(application (has been |was )?(successfully )?(submitted|received|sent)|your application (was |has been )?sent to|you(?:'|’| ha)?ve (successfully )?applied (to|for) this|we(?:'|’| ha)?ve received your application|thank(s| you) for (applying|submitting your application)|successfully (submitted|applied)|your application is (in|complete))/i;
  function watchForReceived() {
    let toldFor = "";
    let pageAt = location.href;
    let showingBefore = false;
    let pending = 0;
    const found = () => {
      const boxes = Array.from(document.querySelectorAll("input:not([type=hidden]):not([type=search]), textarea, select")).filter((el) => el.getBoundingClientRect().height > 0);
      if (boxes.length > 4) return null;
      const text = (document.body.innerText || "").replace(/\s+/g, " ");
      const match = text.match(RECEIVED);
      return match ? text.slice(Math.max(0, (match.index ?? 0) - 40), Math.max(0, (match.index ?? 0) - 40) + 200) : null;
    };
    const check = () => {
      pending = 0;
      if (!document.body) return;
      if (location.href !== pageAt) {
        pageAt = location.href;
        showingBefore = Boolean(found());
        return;
      }
      if (toldFor === pageAt) return;
      const text = found();
      if (!text) {
        showingBefore = false;
        return;
      }
      if (showingBefore) return;
      toldFor = pageAt;
      try {
        void chrome.runtime.sendMessage({ type: "received-page", text, url: location.href }).catch(() => void 0);
      } catch {
        observer.disconnect();
      }
    };
    const observer = new MutationObserver(() => {
      if (!pending) pending = window.setTimeout(check, 800);
    });
    observer.observe(document.documentElement, { childList: true, subtree: true, characterData: true });
    check();
  }
  function watchBoard() {
    let pageAt = location.href;
    let openedAt = Date.now();
    const told = /* @__PURE__ */ new Set();
    let listed = "";
    let pending = 0;
    const send = (message) => {
      try {
        void chrome.runtime.sendMessage(message).catch(() => void 0);
      } catch {
        observer.disconnect();
      }
    };
    const check = () => {
      pending = 0;
      if (!document.body) return;
      if (location.href !== pageAt) {
        pageAt = location.href;
        openedAt = Date.now();
      }
      if (isAppliedListPage()) {
        const items = appliedList();
        const key2 = items.map((item) => item.url).join("|");
        if (items.length && key2 !== listed) {
          listed = key2;
          send({ type: "board-list", url: location.href, items });
        }
        return;
      }
      if (Date.now() - openedAt < 1500) {
        pending = window.setTimeout(check, 1600);
        return;
      }
      const status = appliedStatus();
      if (!status) return;
      const key = `${location.href.split("#")[0]}|${status.text}`;
      if (told.has(key)) return;
      told.add(key);
      send({ type: "board-applied", url: location.href, text: status.text, day: status.day });
    };
    const observer = new MutationObserver(() => {
      if (!pending) pending = window.setTimeout(check, 900);
    });
    observer.observe(document.documentElement, { childList: true, subtree: true, characterData: true });
    pending = window.setTimeout(check, 2e3);
  }
  watchEdits();
  if (window.top === window && !/unneponew\.vercel\.app$|(^|\.)unnepo\.com$|^localhost$/.test(location.hostname)) watchForReceived();
  if (window.top === window && QUICK_BOARDS.test(location.hostname)) watchBoard();
  if (window.top === window && QUICK_BOARDS.test(location.hostname)) {
    watchApplyPresses((message) => {
      try {
        void chrome.runtime.sendMessage(message).catch(() => void 0);
      } catch {
      }
    });
  }
  if (window.top === window && !/unneponew\.vercel\.app$|(^|\.)unnepo\.com$|^localhost$/.test(location.hostname) && !dismissed()) {
    let tries = 0;
    const check = () => {
      if (looksLikeJobPage()) return show();
      if (++tries < 15) setTimeout(check, 2e3);
    };
    void chrome.storage.local.get("notJobs").then((kept) => {
      if (!(kept.notJobs ?? []).includes(location.href.split("#")[0])) check();
    }, check);
  }
})();
