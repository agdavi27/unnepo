"use strict";
(() => {
  // lib/spiders.ts
  var SKINS = [
    { id: "classic", name: "Unnepo", unlockAt: 0, color: "#6E5B6E" },
    { id: "school", name: "School spirit", unlockAt: 0, color: "#6E5B6E" },
    { id: "blue", name: "Blue", unlockAt: 50, color: "#3D8BFF" },
    { id: "green", name: "Green", unlockAt: 150, color: "#2FBF71" },
    { id: "purple", name: "Purple", unlockAt: 300, color: "#9B5CFF" },
    { id: "gold", name: "Gold", unlockAt: 500, color: "#F2B227" },
    { id: "pink", name: "Pink", unlockAt: 1e3, color: "#FF5C9A" }
  ];
  var isSkin = (value) => SKINS.some((skin) => skin.id === value);
  var SCHOOL_STYLES = {
    "colby college": { color: "#002169", text: "#FFFFFF", letters: "C" },
    "university of vermont": { color: "#154734", text: "#FFD416", letters: "UVM" },
    "uvm": { color: "#154734", text: "#FFD416", letters: "UVM" },
    "university of pennsylvania": { color: "#011F5B", text: "#FFFFFF", letters: "P" },
    "university of pittsburgh": { color: "#003594", text: "#FFB81C", letters: "P" },
    "cornell university": { color: "#B31B1B", text: "#FFFFFF", letters: "C" },
    "columbia university": { color: "#6CACE4", text: "#FFFFFF", letters: "C" },
    "boston college": { color: "#8A100B", text: "#E0C48A", letters: "BC" },
    "new york university": { color: "#57068C", text: "#FFFFFF", letters: "NYU" },
    "university of washington": { color: "#4B2E83", text: "#B7A57A", letters: "W" },
    "university of texas at austin": { color: "#BF5700", text: "#FFFFFF", letters: "T" },
    "bowdoin college": { color: "#1A1A1A", text: "#FFFFFF", letters: "B" },
    "bates college": { color: "#881124", text: "#FFFFFF", letters: "B" },
    "middlebury college": { color: "#0D395F", text: "#FFFFFF", letters: "M" },
    "williams college": { color: "#500082", text: "#FFCC00", letters: "W" },
    "amherst college": { color: "#3F1F69", text: "#FFFFFF", letters: "A" },
    "brown university": { color: "#4E3629", text: "#ED1C24", letters: "B" },
    "dartmouth college": { color: "#00693E", text: "#FFFFFF", letters: "D" },
    "yale university": { color: "#00356B", text: "#FFFFFF", letters: "Y" },
    "harvard university": { color: "#A51C30", text: "#FFFFFF", letters: "H" },
    "princeton university": { color: "#E77500", text: "#121212", letters: "P" },
    "stanford university": { color: "#8C1515", text: "#FFFFFF", letters: "S" },
    "university of michigan": { color: "#00274C", text: "#FFCB05", letters: "M" },
    "university of california, berkeley": { color: "#003262", text: "#FDB515", letters: "CAL" },
    "georgetown university": { color: "#041E42", text: "#A7B1B7", letters: "G" },
    "duke university": { color: "#00539B", text: "#FFFFFF", letters: "D" },
    "northwestern university": { color: "#4E2A84", text: "#FFFFFF", letters: "N" }
  };
  var FALLBACK_COLORS = ["#1D4F91", "#7A1F2B", "#1F6B45", "#5B2C83", "#B35A00", "#0F5A6B"];
  var FILLER = /* @__PURE__ */ new Set(["of", "the", "at", "and", "for", "in"]);
  function schoolStyle(school) {
    const name = (school ?? "").replace(/\s+/g, " ").trim();
    if (!name) return null;
    const known = SCHOOL_STYLES[name.toLowerCase()];
    if (known) return known;
    const words = name.split(/[\s,-]+/).filter((word) => word && !FILLER.has(word.toLowerCase()));
    const general = words.filter((word) => !/^(college|university|school|institute)$/i.test(word));
    const letters = (words[0] && /^university$/i.test(words[0]) ? words : general.length ? general : words).map((word) => word[0]).join("").toUpperCase().slice(0, 3) || name[0].toUpperCase();
    const hash = [...name].reduce((sum, char) => sum * 31 + char.charCodeAt(0) >>> 0, 7);
    return { color: FALLBACK_COLORS[hash % FALLBACK_COLORS.length], text: "#FFFFFF", letters: letters.length === 2 && general.length === 1 ? letters[0] : letters };
  }
  function shade(hex, amount) {
    const value = parseInt(hex.replace("#", ""), 16);
    const target = amount > 0 ? 255 : 0;
    const mix = (channel) => Math.round(channel + (target - channel) * Math.abs(amount));
    const [r, g, b] = [value >> 16 & 255, value >> 8 & 255, value & 255].map(mix);
    return `#${(1 << 24 | r << 16 | g << 8 | b).toString(16).slice(1).toUpperCase()}`;
  }
  function spiderPalette(look) {
    if (look.skin === "classic") {
      return {
        o: "#000000",
        b: "#6E5B6E",
        h: "#B48FAE",
        d: "#4E3549",
        a: "#3D8BFF",
        e: "#3D8BFF",
        k: "#7E6580",
        K: "#5A4258",
        l: "#6E5B6E",
        L: "#4E3549",
        w: "#FFFFFF",
        m: "#1A0E14",
        f: "#F7F7F8",
        p: "#965E8C",
        t: "#FFFFFF",
        r: "#4E3549"
      };
    }
    const skin = SKINS.find((item) => item.id === look.skin) ?? SKINS[0];
    const style = look.skin === "school" ? schoolStyle(look.school) : null;
    const body = skin.color;
    const back = style?.color ?? body;
    return {
      o: "#000000",
      b: back,
      h: shade(back, 0.35),
      d: shade(back, -0.3),
      k: shade(body, 0.12),
      K: shade(body, -0.15),
      l: body,
      L: shade(body, -0.3),
      a: skin.id === "school" ? "#3D8BFF" : shade(body, 0.55),
      e: skin.id === "school" ? "#3D8BFF" : shade(body, 0.55),
      t: style?.text ?? "#FFFFFF",
      r: shade(back, -0.45),
      m: "#1A0E14",
      w: "#FFFFFF",
      f: "#F7F7F8",
      p: "#965E8C"
    };
  }
  function crawlerColors(look) {
    if (look.skin === "classic") return {};
    const palette = spiderPalette(look);
    return { b: palette.b, s: palette.h, l: palette.L };
  }

  // extension/src/shared/sprite.ts
  var W = 20;
  var H = 17;
  var COLORS = { o: "#000000", b: "#2B2531", s: "#4A4252", l: "#1B171F", w: "#EAF6F2", p: "#1B171F", c: "#F2949E" };
  function spiderGrid(step) {
    const g = Array.from({ length: H }, () => Array(W).fill(""));
    const set = (x, y, c) => {
      if (x >= 0 && x < W && y >= 0 && y < H) g[y][x] = c;
    };
    const legs = step === 0 ? [[[6, 6], [5, 5], [4, 4], [4, 3], [3, 2]], [[5, 8], [4, 7], [3, 7], [2, 7], [1, 8]], [[5, 10], [4, 10], [3, 11], [2, 11], [2, 12]], [[6, 12], [5, 13], [4, 14], [4, 15]]] : [[[6, 6], [5, 5], [5, 4], [4, 3], [4, 2]], [[5, 8], [4, 8], [3, 8], [2, 8], [1, 9]], [[5, 10], [4, 11], [3, 11], [3, 12], [2, 13]], [[6, 12], [6, 13], [5, 14], [5, 15]]];
    for (const leg of legs) for (const [x, y] of leg) {
      set(x, y, "l");
      set(W - 1 - x, y, "l");
    }
    for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
      const nx = (x + 0.5 - 10) / 4.6, ny = (y + 0.5 - 9.2) / 5;
      if (nx * nx + ny * ny <= 1) set(x, y, "b");
    }
    for (const ex of [6, 11]) for (let dx = 0; dx < 3; dx++) for (let dy = 0; dy < 3; dy++) set(ex + dx, 5 + dy, "w");
    set(7, 6, "p");
    set(12, 6, "p");
    set(5, 8, "c");
    set(14, 8, "c");
    set(11, 11, "s");
    const out = g.map((row) => row.slice());
    for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
      if (g[y][x]) continue;
      if ([[1, 0], [-1, 0], [0, 1], [0, -1]].some(([dx, dy]) => g[y + dy]?.[x + dx])) out[y][x] = "o";
    }
    return out;
  }
  function spiderRects(step, colors = {}) {
    const out = spiderGrid(step);
    const palette = { ...COLORS, ...colors };
    let rects = "";
    for (let y = 0; y < H; y++) {
      let x = 0;
      while (x < W) {
        const c = out[y][x];
        if (!c) {
          x++;
          continue;
        }
        let w = 1;
        while (x + w < W && out[y][x + w] === c) w++;
        rects += `<rect x="${x}" y="${y}" width="${w}" height="1" fill="${palette[c]}"/>`;
        x += w;
      }
    }
    return rects;
  }
  async function storedSpiderColors() {
    try {
      const { spider } = await chrome.storage.local.get("spider");
      return spider && isSkin(spider.skin) ? crawlerColors(spider) : {};
    } catch {
      return {};
    }
  }

  // extension/src/content/quick-apply.ts
  var QUICK_BOARDS = /(^|\.)((joinhandshake|linkedin|ziprecruiter|indeed|simplyhired|wellfound|glassdoor|dice|builtin|monster|careerbuilder|wayup)\.com|simplify\.jobs|idealist\.org|usajobs\.gov)$/;
  var APPLY_PRESS = /^(1-click apply|one-click apply|quick apply|easy apply|instant apply|apply|apply now|submit( my)? application|send( my)? application|submit|apply with (my )?(profile|resume))$/i;
  var FINAL_PRESS = /1-click|one-click|quick apply|instant apply|submit|send|apply with/i;
  var ELSEWHERE = /externally|company('|’)?s? (site|website)|employer('|’)?s? (site|website)|on company site/i;
  var APPLIED_NOW = /^([✓✔☑]\s*)?((you )?applied|application (sent|submitted|received|complete)|you(?:'|’| ha)ve applied|already applied|your application (was |has been )?(sent|submitted|received))\b.{0,40}$/i;
  var shortText = (el) => (el.innerText || el.textContent || "").replace(/\s+/g, " ").trim();
  var shown = (el) => el.getBoundingClientRect().height > 0;
  function appliedLabels() {
    return Array.from(document.querySelectorAll("button, a, [role=button], [role=status], [role=alert], span, p, div, h2, h3")).filter((el) => el.childElementCount <= 2 && shown(el) && APPLIED_NOW.test(shortText(el)));
  }
  function watchApplyPresses(tell) {
    let watching = 0;
    document.addEventListener("click", (event) => {
      const button = event.target?.closest("button, a, [role=button], input[type=submit]");
      const label = button ? shortText(button) || button.value || "" : "";
      if (!button) return;
      const mark = () => {
        document.querySelectorAll("[data-unnepo-pressed]").forEach((el) => el.removeAttribute("data-unnepo-pressed"));
        button.setAttribute("data-unnepo-pressed", String(Date.now()));
      };
      if (ELSEWHERE.test(label) || /^apply( now)? (on|at) /i.test(label)) {
        mark();
        tell({ type: "apply-clicked", url: location.href, label, final: false, elsewhere: true });
        return;
      }
      if (!APPLY_PRESS.test(label)) return;
      mark();
      tell({ type: "apply-clicked", url: location.href, label, final: FINAL_PRESS.test(label) });
      const before = appliedLabels().length;
      const run = ++watching;
      const started = Date.now();
      const check = () => {
        if (run !== watching) return;
        const said = `${shortText(button)} ${button.getAttribute("aria-label") ?? ""}`.trim();
        const changed = button.isConnected && (APPLIED_NOW.test(shortText(button)) || /\bapplied\b/i.test(said) && (button.disabled || button.getAttribute("aria-disabled") === "true"));
        const now = appliedLabels();
        if (changed || now.length > before) {
          tell({ type: "applied-detected", text: shortText(changed ? button : now[now.length - 1]).slice(0, 120), url: location.href });
          return;
        }
        if (Date.now() - started < 9e4) setTimeout(check, 700);
      };
      setTimeout(check, 700);
    }, true);
  }

  // extension/src/content/edits.ts
  var EDITED = "data-unnepo-edited";
  var opened = null;
  var fieldOf = (el) => el.closest("[data-unnepo-id]") ?? el;
  function touch(el) {
    el.setAttribute(EDITED, "");
    fieldOf(el).setAttribute(EDITED, "");
    if (el instanceof HTMLInputElement && (el.type === "radio" || el.type === "checkbox") && el.name) {
      const root = el.getRootNode();
      root.querySelectorAll(`input[name="${CSS.escape(el.name)}"]`).forEach((item) => item.setAttribute(EDITED, ""));
    }
  }
  function targetOf(event) {
    const target = event.composedPath()[0];
    return target instanceof Element ? target : null;
  }
  function watchEdits() {
    if (window.__unnepoEdits) return;
    window.__unnepoEdits = true;
    const onEdit = (event) => {
      const target = targetOf(event);
      if (event.isTrusted && target?.matches("input, select, textarea, [contenteditable]")) touch(target);
    };
    document.addEventListener("input", onEdit, true);
    document.addEventListener("change", onEdit, true);
    document.addEventListener("pointerdown", (event) => {
      const target = targetOf(event);
      if (!event.isTrusted || !target) return;
      const option = target.closest("[role=option], [data-automation-id*='promptOption' i]");
      if (option) {
        if (opened?.isConnected) touch(opened);
      } else {
        opened = target.closest("[data-unnepo-id], [role=combobox], [aria-haspopup=listbox]");
      }
    }, true);
    document.addEventListener("keydown", (event) => {
      const target = targetOf(event);
      if (event.isTrusted && target && event.key === "Enter" && target.closest("[role=combobox], [aria-haspopup=listbox]")) touch(target);
    }, true);
  }

  // extension/src/content/launcher.ts
  var ATS_HOST = /(myworkdayjobs|myworkdaysite|greenhouse|lever\.co|ashbyhq|workable|smartrecruiters|icims|jobvite|bamboohr|paycomonline|paylocity|ultipro|ukg|taleo|successfactors|breezy\.hr|recruitee|teamtailor|rippling|applytojob|dayforcehcm|oraclecloud|eightfold|avature|phenom|gem\.com|dover\.com|wellfound)\./i;
  var APPLY = /^(apply( now| for this (job|position|role|opportunity)| here| online| today)?|i(?:'|’)?m interested|start (my |your )?application|easy apply)$/i;
  var DISMISSED = "unnepo-launcher-dismissed";
  function looksLikeJobPage() {
    if (ATS_HOST.test(location.hostname)) return true;
    const buttons = Array.from(document.querySelectorAll("a, button, [role=button], input[type=submit]"));
    if (buttons.some((el) => APPLY.test((el.textContent || el.value || "").replace(/\s+/g, " ").trim()))) return true;
    const fields = document.querySelectorAll("input:not([type=hidden]):not([type=search]), textarea, select").length;
    if (document.querySelector("input[type=file]") && fields >= 3) return true;
    return fields >= 6 && /\b(resume|cv|cover letter|work authori[sz]ation|years of experience)\b/i.test(document.body.innerText || "");
  }
  function show() {
    if (document.querySelector("[data-unnepo-launcher]")) return;
    const host = document.createElement("div");
    host.setAttribute("data-unnepo-launcher", "");
    const root = host.attachShadow({ mode: "closed" });
    const reduce = matchMedia("(prefers-reduced-motion: reduce)").matches;
    root.innerHTML = `
    <style>
      :host { all: initial; position: fixed; top: 0; right: 22px; z-index: 2147483646; font: 13px/1.3 system-ui, -apple-system, sans-serif; }
      .wrap { position: relative; display: flex; flex-direction: column; align-items: center; animation: ${reduce ? "none" : "drop .9s cubic-bezier(.3,1.5,.6,1) both"}; }
      .thread { width: 2px; height: 96px; background: linear-gradient(90deg, #000 0 1px, #EAF6F2 1px 2px); }
      .spider { all: unset; cursor: pointer; display: block; width: 48px; height: ${Math.round(48 * H / W)}px; filter: drop-shadow(2px 3px 0 rgba(0,0,0,.2)); animation: ${reduce ? "none" : "sway 3.2s steps(4) 1s infinite"}; transform-origin: 50% -96px; }
      .spider svg { display: block; width: 100%; height: 100%; transform: rotate(180deg); }
      .spider:focus-visible { outline: 3px solid #3D8BFF; outline-offset: 4px; border-radius: 6px; }
      .tip { position: absolute; right: 58px; top: 104px; white-space: nowrap; background: #F7F7F8; color: #070708; border: 3px solid #070708; box-shadow: 0 0 0 2px #F7F7F8, 4px 4px 0 2px #3D8BFF; padding: 6px 10px; font-weight: 600; opacity: 0; transform: translateX(6px); transition: opacity .15s, transform .15s; pointer-events: none; }
      .wrap:hover .tip, .spider:focus-visible ~ .tip, .tip.say { opacity: 1; transform: none; }
      .close { all: unset; position: absolute; top: 96px; right: -14px; width: 18px; height: 18px; border-radius: 50%; background: #070708; color: #F7F7F8; font-size: 12px; line-height: 18px; text-align: center; cursor: pointer; opacity: 0; transition: opacity .15s; }
      .wrap:hover .close, .close:focus-visible { opacity: 1; }
      @keyframes drop { from { transform: translateY(-150px); } to { transform: none; } }
      @keyframes sway { 0%, 100% { transform: rotate(0); } 25% { transform: rotate(4deg); } 75% { transform: rotate(-4deg); } }
    </style>
    <div class="wrap">
      <div class="thread"></div>
      <button class="spider" type="button" aria-label="Fill this application with Unnepo"><svg viewBox="0 0 ${W} ${H}" shape-rendering="crispEdges" aria-hidden="true">${spiderRects(0)}</svg></button>
      <span class="tip" role="status">Fill with Unnepo</span>
      <button class="close" type="button" aria-label="Hide the Unnepo spider on this site">\xD7</button>
    </div>`;
    void storedSpiderColors().then((colors) => {
      const svg = root.querySelector(".spider svg");
      if (svg && Object.keys(colors).length) svg.innerHTML = spiderRects(0, colors);
    });
    const tip = root.querySelector(".tip");
    const say = (words) => {
      tip.textContent = words;
      tip.classList.add("say");
      setTimeout(() => {
        tip.classList.remove("say");
        tip.textContent = "Fill with Unnepo";
      }, 4e3);
    };
    root.querySelector(".spider").addEventListener("click", () => {
      let reachable = false;
      try {
        reachable = Boolean(chrome.runtime?.id);
      } catch {
        reachable = false;
      }
      if (!reachable) return say("Unnepo was updated. Refresh this page");
      try {
        chrome.runtime.sendMessage({ type: "open-panel" }).then((result) => {
          if (!result?.ok) say("Click the Unnepo icon in your toolbar");
        }, () => say("Refresh this page to use Unnepo"));
      } catch {
        say("Refresh this page to use Unnepo");
      }
    });
    const hideFor = (open) => {
      host.style.display = open ? "none" : "";
    };
    try {
      chrome.runtime.onMessage.addListener((message) => {
        if (message?.type === "panel") hideFor(message.open);
      });
      void chrome.runtime.sendMessage({ type: "panel-state" }).then((state) => hideFor(state?.open), () => void 0);
    } catch {
    }
    root.querySelector(".close").addEventListener("click", () => {
      try {
        sessionStorage.setItem(DISMISSED, "1");
      } catch {
      }
      host.remove();
    });
    document.documentElement.appendChild(host);
  }
  function dismissed() {
    try {
      return sessionStorage.getItem(DISMISSED) === "1";
    } catch {
      return false;
    }
  }
  var RECEIVED = /(application (has been |was )?(successfully )?(submitted|received|sent)|your application (was |has been )?sent to|you(?:'|’| ha)?ve (successfully )?applied (to|for) this|we(?:'|’| ha)?ve received your application|thank(s| you) for (applying|submitting your application)|successfully (submitted|applied)|your application is (in|complete))/i;
  function watchForReceived() {
    let toldFor = "";
    let pageAt = location.href;
    let showingBefore = false;
    let pending = 0;
    const found = () => {
      const boxes = Array.from(document.querySelectorAll("input:not([type=hidden]):not([type=search]), textarea, select")).filter((el) => el.getBoundingClientRect().height > 0);
      if (boxes.length > 4) return null;
      const text = (document.body.innerText || "").replace(/\s+/g, " ");
      const match = text.match(RECEIVED);
      return match ? text.slice(Math.max(0, (match.index ?? 0) - 40), Math.max(0, (match.index ?? 0) - 40) + 200) : null;
    };
    const check = () => {
      pending = 0;
      if (!document.body) return;
      if (location.href !== pageAt) {
        pageAt = location.href;
        showingBefore = Boolean(found());
        return;
      }
      if (toldFor === pageAt) return;
      const text = found();
      if (!text) {
        showingBefore = false;
        return;
      }
      if (showingBefore) return;
      toldFor = pageAt;
      try {
        void chrome.runtime.sendMessage({ type: "received-page", text, url: location.href }).catch(() => void 0);
      } catch {
        observer.disconnect();
      }
    };
    const observer = new MutationObserver(() => {
      if (!pending) pending = window.setTimeout(check, 800);
    });
    observer.observe(document.documentElement, { childList: true, subtree: true, characterData: true });
    check();
  }
  watchEdits();
  if (window.top === window && !/unneponew\.vercel\.app$|(^|\.)unnepo\.com$|^localhost$/.test(location.hostname)) watchForReceived();
  if (window.top === window && QUICK_BOARDS.test(location.hostname)) {
    watchApplyPresses((message) => {
      try {
        void chrome.runtime.sendMessage(message).catch(() => void 0);
      } catch {
      }
    });
  }
  if (window.top === window && !/unneponew\.vercel\.app$|(^|\.)unnepo\.com$|^localhost$/.test(location.hostname) && !dismissed()) {
    let tries = 0;
    const check = () => {
      if (looksLikeJobPage()) return show();
      if (++tries < 15) setTimeout(check, 2e3);
    };
    void chrome.storage.local.get("notJobs").then((kept) => {
      if (!(kept.notJobs ?? []).includes(location.href.split("#")[0])) check();
    }, check);
  }
})();
