// lib/apply/follow-ups.ts
var FOLLOW_UP_BUSINESS_DAYS = 5;
function businessDaysBetween(from, to) {
  let days = 0;
  const day = new Date(Date.UTC(from.getUTCFullYear(), from.getUTCMonth(), from.getUTCDate()));
  const end = Date.UTC(to.getUTCFullYear(), to.getUTCMonth(), to.getUTCDate());
  while (day.getTime() < end) {
    day.setUTCDate(day.getUTCDate() + 1);
    const weekday = day.getUTCDay();
    if (weekday !== 0 && weekday !== 6) days += 1;
  }
  return days;
}
function followUpsDue(apps, now = /* @__PURE__ */ new Date()) {
  return apps.flatMap((app) => (app.contacts ?? []).flatMap((person) => {
    const at = app.fillReport?.emailedAt?.[person.id];
    if (person.outreachStatus !== "emailed" || !at) return [];
    const days = businessDaysBetween(new Date(at), now);
    return days >= FOLLOW_UP_BUSINESS_DAYS ? [{ applicationId: app.id, contactId: person.id, name: person.name, company: app.company, title: app.title, emailedAt: at, days }] : [];
  })).sort((a, b) => a.emailedAt.localeCompare(b.emailedAt));
}

// lib/plan.ts
var UPGRADE_URL = "/home?tab=pro";

// lib/apply/stats.ts
var NO_RESPONSE_DAYS = 28;
var isApplied = (status) => status === "submitted" || status === "applied_manual";
function stageOf(app, now = Date.now()) {
  if (!isApplied(app.status)) return "in_progress";
  if (app.fillReport?.outcome) return app.fillReport.outcome;
  const last = Math.max(Date.parse(app.submittedAt ?? app.createdAt ?? "") || 0, Date.parse(app.fillReport?.lastEmailAt ?? "") || 0);
  return last && now - last > NO_RESPONSE_DAYS * 864e5 ? "no_response" : "submitted";
}

// lib/apply/compose-link.ts
var MAX_LINK = 2e3;
function composeLink(mailer, to, subject, body) {
  const q = (pairs) => Object.entries(pairs).filter(([, value]) => value).map(([key, value]) => `${key}=${encodeURIComponent(value)}`).join("&");
  const build = (text) => mailer === "gmail" ? `https://mail.google.com/mail/?${q({ view: "cm", fs: "1", to, su: subject, body: text })}` : mailer === "outlook" ? `https://outlook.office.com/mail/deeplink/compose?${q({ to, subject, body: text })}` : `mailto:${encodeURIComponent(to).replace(/%40/g, "@")}?${q({ subject, body: text })}`;
  const full = build(body);
  return full.length <= MAX_LINK ? { url: full, cut: false } : { url: build(""), cut: true };
}

// lib/apply/progress.ts
var STEPS = ["Applied", "Reach out", "Waiting", "Follow up", "Interview"];
var applied = (job) => job.status === "submitted" || job.status === "applied_manual";
var emailedCount = (job) => Math.max(job.fillReport?.reachedOut?.count ?? 0, job.contacts.filter((person) => person.outreachStatus !== "not_contacted").length);
function progressOf(job, followedUp = false, now = /* @__PURE__ */ new Date()) {
  const stage = stageOf(job);
  const company = job.companyMissing ? "the company" : job.company;
  if (!applied(job)) return { done: 0, due: false, ended: null, next: "Apply, then it moves along here." };
  if (stage === "offer") return { done: 5, due: false, ended: "Offer", next: "You got an offer." };
  if (stage === "interviewing" || stage === "assessment") return { done: 5, due: false, ended: null, next: stage === "assessment" ? "You have an assessment." : "You're interviewing." };
  const emailed = emailedCount(job);
  const replied = job.contacts.some((person) => person.outreachStatus === "replied");
  const progress = !emailed ? { done: 1, due: false, ended: null, next: `Email someone at ${company}.` } : followUpsDue([job], now).length ? { done: 3, due: true, ended: null, next: "A follow-up is due." } : replied || followedUp ? { done: 4, due: false, ended: null, next: replied ? "Someone replied. Waiting on an interview." : "Followed up. Waiting on an interview." } : { done: 2, due: false, ended: null, next: `Emailed ${emailed} ${emailed === 1 ? "person" : "people"}. Waiting on a reply.` };
  return stage === "rejected" ? { ...progress, due: false, ended: "Rejected", next: "This one said no." } : progress;
}

// lib/apply/next-up.ts
var DAY = 864e5;
var FINISH_DAYS = 30;
var UPDATE_DAYS = 14;
var SHOWN = 5;
function daysAgo(at, now) {
  const start = (date) => new Date(date.getFullYear(), date.getMonth(), date.getDate()).getTime();
  return Math.round((start(now) - start(new Date(at))) / DAY);
}
function dayWords(at, now) {
  const days = daysAgo(at, now);
  if (days <= 0) return "Today";
  if (days === 1) return "Yesterday";
  return new Date(at).toLocaleDateString("en-US", { month: "short", day: "numeric" });
}
function nextUp(apps, options = {}) {
  const shown = options.shown ?? SHOWN;
  const now = options.now ?? /* @__PURE__ */ new Date();
  const role = (app) => app.titleMissing ? "" : app.title;
  const named = apps.filter((app) => !app.companyMissing);
  const goal = { today: options.goal?.today ?? 0, daily: options.goal?.daily ?? 0, week: options.goal?.week ?? 0, weekly: options.goal?.weekly ?? 0 };
  const goalItems = [];
  const leftToday = Math.max(0, goal.daily - goal.today);
  const leftWeek = Math.max(0, goal.weekly - goal.week);
  if (leftToday > 0 || leftWeek > 0) {
    const left = leftToday || leftWeek;
    goalItems.push({
      key: `goal:${goal.today}:${goal.week}`,
      kind: "goal",
      title: `Apply to ${left} more ${left === 1 ? "job" : "jobs"}${leftToday ? " today" : " this week"}`,
      detail: [goal.daily ? `${goal.today} of ${goal.daily} today` : "", goal.weekly ? `${goal.week} of ${goal.weekly} this week` : ""].filter(Boolean).join(" \xB7 "),
      when: `${left} to go`,
      action: "Find a job"
    });
  }
  const replied = named.filter((app) => stageOf(app) === "follow_up").map((app) => {
    const change = [...app.fillReport?.statusHistory ?? []].reverse().find((item) => item.status !== "applied" && item.status !== "incomplete");
    return { app, at: Date.parse(change?.at ?? app.fillReport?.lastEmailAt ?? app.submittedAt ?? app.createdAt), summary: change?.summary ?? "" };
  }).sort((a, b) => b.at - a.at);
  const followItems = replied.map(({ app, at, summary }) => ({
    key: `reply:${app.id}`,
    kind: "reply",
    applicationId: app.id,
    title: `Follow up with ${app.company}`,
    detail: [role(app), summary].filter(Boolean).join(" \xB7 "),
    when: dayWords(at, now),
    action: "Open job"
  }));
  for (const due of followUpsDue(named, now)) {
    followItems.push({
      key: `follow:${due.contactId}`,
      kind: "follow_up",
      applicationId: due.applicationId,
      contactId: due.contactId,
      title: `Follow up with ${due.name}`,
      detail: `${due.company} \xB7 emailed ${due.days} business days ago`,
      when: `${due.days} business days`,
      action: "Write follow-up"
    });
  }
  const appItems = named.filter((app) => !isApplied(app.status) && now.getTime() - Date.parse(app.createdAt) <= FINISH_DAYS * DAY).sort((a, b) => Date.parse(b.createdAt) - Date.parse(a.createdAt)).map((app) => ({
    key: `finish:${app.id}`,
    kind: "finish",
    applicationId: app.id,
    title: role(app) ? `Finish ${role(app)} at ${app.company}` : `Finish your application at ${app.company}`,
    detail: "Started, not submitted",
    when: "In progress",
    action: "Finish application"
  }));
  const dueIds = new Set(followItems.map((item) => item.applicationId));
  for (const app of named.filter((app2) => ["submitted", "no_response"].includes(stageOf(app2, now.getTime())) && !dueIds.has(app2.id)).filter((app2) => now.getTime() - Date.parse(app2.fillReport?.lastEmailAt ?? app2.submittedAt ?? app2.createdAt) >= UPDATE_DAYS * DAY).sort((a, b) => Date.parse(a.submittedAt ?? a.createdAt) - Date.parse(b.submittedAt ?? b.createdAt))) {
    appItems.push({
      key: `update:${app.id}`,
      kind: "update",
      applicationId: app.id,
      title: `Heard back from ${app.company}?`,
      detail: [role(app), `applied ${daysAgo(Date.parse(app.submittedAt ?? app.createdAt), now)} days ago`].filter(Boolean).join(" \xB7 "),
      when: "Update status",
      action: "Update status"
    });
  }
  return {
    goals: { ...goal, items: goalItems },
    follow_ups: { replied: replied.length, count: followItems.length, items: followItems.slice(0, shown) },
    applications: { count: appItems.length, items: appItems.slice(0, shown) }
  };
}

// extension/src/shared/reminders.ts
var MAX_FOLLOW_UPS = 2;
var SENT_ASK_MS = 60 * 60 * 1e3;
var DAY2 = 864e5;
function goalCounts(tracker, now) {
  const dayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
  const weekStart = new Date(dayStart - (now.getDay() + 6) % 7 * DAY2).getTime();
  const applied2 = tracker.jobs.filter((job) => isApplied(job.status) && !job.fillReport?.notCounted).map((job) => Date.parse(job.submittedAt ?? job.createdAt));
  const weekly = tracker.weeklyGoal ?? 0;
  return { today: applied2.filter((at) => at >= dayStart).length, daily: weekly ? Math.ceil(weekly / 5) : 0, week: applied2.filter((at) => at >= weekStart).length, weekly };
}
function reminders(tracker, marks, opened, followUps, now = /* @__PURE__ */ new Date()) {
  const next = nextUp(tracker.jobs, { now, goal: goalCounts(tracker, now), shown: 100 });
  const hidden = (key) => Boolean(marks[key]?.done || marks[key]?.until && marks[key].until > now.getTime());
  const contact = (id) => tracker.jobs.flatMap((job) => job.contacts).find((person) => person.id === id);
  const sent = Object.entries(opened).filter(([id, item]) => now.getTime() - item.at >= SENT_ASK_MS && (item.followUp || contact(id)?.outreachStatus === "not_contacted")).map(([id, item]) => ({
    key: `sent:${id}:${item.at}`,
    kind: "sent",
    applicationId: item.applicationId,
    contactId: id,
    title: `Did you send your ${item.followUp ? "follow-up" : "email"} to ${item.name}?`,
    detail: item.company,
    when: "",
    action: "Yes, I sent it"
  }));
  const follow = next.follow_ups.items.map((item) => item.kind === "follow_up" && item.contactId && (followUps[item.contactId] ?? 0) >= MAX_FOLLOW_UPS ? { ...item, title: `No reply from ${item.title.replace(/^Follow up with /, "")}`, detail: `${item.detail} \xB7 followed up ${MAX_FOLLOW_UPS} times`, action: "Stop following up" } : item);
  const today = [...sent, ...follow, ...next.applications.items].filter((item) => !hidden(item.key));
  return { goal: next.goals, items: today };
}

// extension/src/shared/tracker-view.ts
var escape = (text) => text.replace(/[&<>"']/g, (char) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[char]);
var ask = (message) => chrome.runtime.sendMessage(message);
var short = (text, max = 60) => text.length > max ? `${text.slice(0, max - 1).trimEnd()}\u2026` : text;
var store = {
  tracker: null,
  error: "",
  loading: false,
  loadedAt: 0,
  detected: null,
  marks: {},
  opened: {},
  followUps: {},
  mailer: "gmail",
  /** What happened last, per job: "Copied", an error. */
  notes: {},
  busy: /* @__PURE__ */ new Set()
};
var host = { redraw: () => void 0, openJob: () => void 0, upgradeUrl: () => "" };
function setHost(next) {
  host = next;
}
async function loadTracker(fresh = false) {
  if (store.loading) return;
  store.loading = true;
  const [result, local, detected] = await Promise.all([
    ask({ type: "tracker", fresh }).catch(() => ({ ok: false, error: "Couldn't reach Unnepo." })),
    chrome.storage.local.get(["reminderMarks", "openedEmails", "followUps", "mailer"]),
    ask({ type: "detected-list" }).catch(() => ({ ok: false, list: [] }))
  ]);
  store.loading = false;
  store.loadedAt = Date.now();
  if (result.ok && "tracker" in result && result.tracker) {
    store.tracker = result.tracker;
    store.error = "";
  } else store.error = result.error ?? "Couldn't load your jobs.";
  store.marks = local.reminderMarks ?? {};
  store.opened = local.openedEmails ?? {};
  store.followUps = local.followUps ?? {};
  store.mailer = local.mailer ?? "gmail";
  store.detected = detected.list ?? [];
  host.redraw();
  pollWhileFinding();
}
var pollTimer = 0;
function pollWhileFinding() {
  clearTimeout(pollTimer);
  if (store.tracker?.jobs.some((job) => job.contactsStatus === "finding" || job.contactsStatus === "writing")) pollTimer = window.setTimeout(() => void loadTracker(true), 4e3);
}
var jobById = (id) => store.tracker?.jobs.find((job) => job.id === id) ?? null;
var STAGE_LABEL = {
  in_progress: "Not applied yet",
  submitted: "Applied",
  no_response: "No response",
  follow_up: "Follow up",
  assessment: "Assessment",
  interviewing: "Interviewing",
  offer: "Offer",
  rejected: "Rejected"
};
var stageLabel = (job) => STAGE_LABEL[stageOf(job)] ?? "Applied";
var isAppliedJob = (job) => job.status === "submitted" || job.status === "applied_manual";
var isHiddenJob = (job) => job.fillReport?.jobHidden === true;
async function setHidden(jobId, hidden) {
  const job = jobById(jobId);
  if (job) job.fillReport = { ...job.fillReport ?? { outcome: null, peopleReveals: 0 }, jobHidden: hidden };
  host.redraw();
  const result = await ask({ type: "job-status", applicationId: jobId, hidden }).catch(() => ({ ok: false, error: "Couldn't reach Unnepo." }));
  store.notes[jobId] = result.ok ? hidden ? "Hidden from your lists. It still counts as applied." : "" : result.error ?? "Couldn't change it.";
  await loadTracker(true);
}
var emailedCount2 = (job) => Math.max(job.fillReport?.reachedOut?.count ?? 0, job.contacts.filter((person) => person.outreachStatus !== "not_contacted").length);
function progressOf2(job, now = /* @__PURE__ */ new Date()) {
  return progressOf(job, job.contacts.some((person) => (store.followUps[person.id] ?? 0) > 0), now);
}
var ROLE_LABEL = { alumni: "Alum", recruiter: "Recruiter", department: "Team", team_member: "Team", poster: "Shown on job posting", job_poster: "Shown on job posting" };
var AVATAR = `<span class="avatar" aria-hidden="true"><svg viewBox="0 0 24 24" fill="currentColor"><circle cx="12" cy="9" r="4.2"/><path d="M3.5 24c.8-5 4.2-8 8.5-8s7.7 3 8.5 8z"/></svg></span>`;
var AVATAR_COLORS = ["#3D8BFF", "#8B5CF6", "#EC4899", "#14B8A6", "#F59E0B", "#22C55E", "#EF4444", "#06B6D4"];
function initialsAvatar(name) {
  const words = name.replace(/[^\p{L}\s]/gu, "").trim().split(/\s+/).filter(Boolean);
  if (!words.length) return AVATAR;
  const initials = (words[0][0] + (words.length > 1 ? words[words.length - 1][0] : "")).toUpperCase();
  const color = AVATAR_COLORS[[...name].reduce((sum, char) => sum + char.charCodeAt(0), 0) % AVATAR_COLORS.length];
  return `<span class="avatar initials" aria-hidden="true" style="color:${color};background:${color}22;box-shadow:inset 0 0 0 1.5px ${color}66">${escape(initials)}</span>`;
}
var GMAIL = `<svg class="gmail" aria-hidden="true" viewBox="0 0 24 18"><path fill="#4285F4" d="M1.6 18h3.8V8.7L0 4.6v11.8C0 17.3.7 18 1.6 18z"/><path fill="#34A853" d="M18.6 18h3.8c.9 0 1.6-.7 1.6-1.6V4.6l-5.4 4.1z"/><path fill="#FBBC04" d="M18.6 1.6v7.1L24 4.6V2.4C24 .4 21.7-.7 20.1.5z"/><path fill="#EA4335" d="M5.4 8.7V1.6L12 6.5l6.6-4.9v7.1L12 13.6z"/><path fill="#C5221F" d="M0 2.4v2.2l5.4 4.1V1.6L3.9.5C2.3-.7 0 .4 0 2.4z"/></svg>`;
function freeRow(name, title, role) {
  const label = ROLE_LABEL[role] ?? role;
  const main = name || title || label;
  const sub = name ? [title || label] : [title ? label : "", "Name hidden"];
  return `<li class="person compact">${AVATAR}
    <div class="person-text"><span class="person-name" title="${escape(main)}">${escape(main)}</span><span class="sub">${escape(sub.filter(Boolean).join(" \xB7 "))}</span></div>
    <span class="pro-tag" title="Included with Pro">Pro</span><button type="button" class="solid" data-upgrade>Show person</button></li>`;
}
var EMAIL_SOURCE = {
  apollo: "Verified",
  hunter: "Verified",
  pattern: "Verified",
  job_posting: "From the job posting",
  website: "From the company's website",
  likely: "Likely: follows the company's format, not checked",
  cant_check: "Can't be checked: the company accepts every address",
  guess: "Best guess"
};
var when = (at) => {
  const date = new Date(at);
  return date.toLocaleDateString("en-US", { month: "short", day: "numeric", ...date.getFullYear() === (/* @__PURE__ */ new Date()).getFullYear() ? {} : { year: "numeric" } });
};
var MAILER_NAME = { gmail: "Gmail", outlook: "Outlook", mailto: "your mail app" };
var openPeople = /* @__PURE__ */ new Set();
var justOpened = /* @__PURE__ */ new Map();
var drafts = {};
var websites = {};
var editing = { jobId: "", title: "", company: "", url: "", busy: false, error: "" };
var menuOpenFor = "";
function jobPage(job, focus) {
  if (focus) openPeople.add(focus);
  const applied2 = isAppliedJob(job);
  const stage = stageOf(job);
  const pick = (value, label) => `<option value="${value}"${(stage === "no_response" ? "submitted" : stage) === value ? " selected" : ""}>${label}</option>`;
  const note = store.notes[job.id];
  const progress = progressOf2(job);
  const status = applied2 ? `<select class="status-mini" data-outcome="${job.id}" aria-label="Status">${pick("submitted", "Applied")}${pick("follow_up", "Follow up")}${stage === "assessment" ? pick("assessment", "Assessment") : ""}${pick("interviewing", "Interviewing")}${pick("offer", "Offer")}${pick("rejected", "Rejected")}</select>` : "";
  const date = applied2 ? `Applied ${when(job.submittedAt ?? job.createdAt)}` : `Saved ${when(job.createdAt)}`;
  const company = job.companyMissing ? "Company missing" : job.company;
  const menuItem = (attrs, icon, label, danger = false) => `<button type="button" class="job-menu-item${danger ? " danger" : ""}" role="menuitem" ${attrs}>${icon}<span>${label}</span></button>`;
  const menu = `
        <details class="job-menu" data-job-menu="${job.id}" ${menuOpenFor === job.id ? "open" : ""}>
          <summary aria-label="More for this job">${ICON.dots}</summary>
          <div class="job-menu-list" role="menu">
            ${job.url ? `<a class="job-menu-item" role="menuitem" href="${escape(job.url)}" target="_blank" rel="noreferrer">${ICON.link}<span>Job posting</span></a>` : ""}
            ${menuItem(`data-edit-job="${job.id}"`, ICON.edit, "Edit job info")}
            ${applied2 ? menuItem(`data-hide-job="${job.id}" data-hide="${isHiddenJob(job) ? "0" : "1"}"`, ICON.hide, isHiddenJob(job) ? "Show job again" : "Hide job") : ""}
            ${menuItem(`data-delete-job="${job.id}"`, ICON.trash, "Delete job", true)}
          </div>
        </details>`;
  const step = Math.min(progress.done, STEPS.length - 1);
  const tone = progress.ended === "Rejected" ? " ended" : progress.ended === "Offer" ? " ok" : progress.due ? " due" : "";
  const eyebrow = progress.ended ? progress.ended : applied2 ? `Next \xB7 step ${step + 1} of ${STEPS.length}` : "Next";
  const action = !applied2 ? `<button type="button" class="btn primary next-btn" data-mark-applied="${job.id}">I applied</button>` : !progress.ended && (progress.done === 1 || progress.due) ? `<button type="button" class="btn primary next-btn" data-see-people>See people <span aria-hidden="true">\u2193</span></button>` : "";
  const bars = STEPS.map((_, index) => `<i class="${index < progress.done ? "d" : index === progress.done && !progress.ended ? progress.due ? "w" : "n" : ""}"></i>`).join("");
  return `
    <section class="page job-view" aria-label="${escape(job.title)}">
      <div class="job-head">
        <div class="job-head-text">
          <div class="job-name small-name">${escape(job.titleMissing ? "Job title missing" : job.title)}</div>
          <div class="job-detail">${escape(company)}${job.location ? ` \xB7 ${escape(job.location)}` : ""} \xB7 ${escape(date)}${job.confirmation?.confidence === "confirmed" ? ' <span class="confirmed" title="The site confirmed it">\u2713</span>' : ""}</div>
        </div>
        ${menu}
      </div>
      ${status ? `<div class="job-status">${status}</div>` : ""}
      ${editing.jobId === job.id ? editForm(job) : ""}
      <div class="next-box${tone}">
        <div class="next-top"><span class="next-eyebrow">${escape(eyebrow)}</span><span class="dots" aria-hidden="true">${bars}</span></div>
        <p class="next-text">${escape(progress.next)}</p>
        ${action}
      </div>
      ${note ? `<p class="small" role="status">${escape(note)}</p>` : ""}
    </section>
    ${peopleCard(job)}
    ${applied2 ? `<section class="page" aria-label="People you emailed">${reachPicker(job)}</section>` : ""}`;
}
document.addEventListener("click", (event) => {
  if (!menuOpenFor || event.target?.closest?.(".job-menu")) return;
  menuOpenFor = "";
  document.querySelectorAll(".job-menu[open]").forEach((menu) => {
    menu.open = false;
  });
});
var svg = (path) => `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${path}</svg>`;
var ICON = {
  dots: `<svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><circle cx="5" cy="12" r="1.8"/><circle cx="12" cy="12" r="1.8"/><circle cx="19" cy="12" r="1.8"/></svg>`,
  link: svg('<path d="M14 4h6v6M20 4l-9 9M18 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h5"/>'),
  edit: svg('<path d="M4 20h4L19 9l-4-4L4 16z"/>'),
  hide: svg('<path d="M3 3l18 18M10.6 10.6a2 2 0 0 0 2.8 2.8M9.9 5.2A9.8 9.8 0 0 1 12 5c5 0 9 5 9 7a12 12 0 0 1-2.4 3.3M6.6 6.6C4.5 8 3 10.3 3 12c0 2 4 7 9 7a9.6 9.6 0 0 0 4-.9"/>'),
  trash: svg('<path d="M4 7h16M10 11v6M14 11v6M6 7l1 12a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1l1-12M9 7V4h6v3"/>')
};
function editForm(job) {
  return `
      <div class="edit-job letter-form flat" role="group" aria-label="Edit job info">
        <label class="question"><span class="q-label">Job title</span><input class="field" data-edit="title" maxlength="200" value="${escape(editing.title)}"></label>
        <label class="question"><span class="q-label">Company</span><input class="field" data-edit="company" maxlength="200" value="${escape(editing.company)}"></label>
        <label class="question"><span class="q-label">Job link</span><input class="field" data-edit="url" type="url" maxlength="2000" placeholder="https://\u2026" value="${escape(editing.url)}"></label>
        ${editing.error ? `<p class="small" style="color: var(--warn)" role="alert">${escape(editing.error)}</p>` : ""}
        <div class="links">
          <button type="button" class="solid" data-edit-save="${job.id}" ${editing.busy ? "disabled" : ""}>${editing.busy ? "Saving\u2026" : "Save"}</button>
          <button type="button" class="link" data-edit-cancel>Cancel</button>
        </div>
      </div>`;
}
function reachPicker(job) {
  const count2 = emailedCount2(job);
  const busy = store.busy.has(`reach:${job.id}`);
  const option = (value, label) => {
    const on = value === 3 ? count2 >= 3 : count2 === value;
    return `<button type="button" class="seg-btn${on ? " on" : ""}" data-reach="${value}" data-reach-job="${job.id}" aria-pressed="${on}" ${busy ? "disabled" : ""}>${label}</button>`;
  };
  return `<div class="question" role="group" aria-label="People you emailed about this job">
    <span class="q-label">People you emailed</span>
    <div class="seg">${option(0, "None yet")}${option(1, "1")}${option(2, "2")}${option(3, "3+")}</div>
  </div>`;
}
async function setReached(jobId, count2) {
  const key = `reach:${jobId}`;
  store.busy.add(key);
  const job = jobById(jobId);
  if (job) job.fillReport = { ...job.fillReport ?? { outcome: null, peopleReveals: 0 }, reachedOut: count2 ? { count: count2, at: job.fillReport?.reachedOut?.at ?? (/* @__PURE__ */ new Date()).toISOString() } : void 0 };
  host.redraw();
  const result = await ask({ type: "job-status", applicationId: jobId, reachedOut: count2 }).catch(() => ({ ok: false, error: "Couldn't reach Unnepo." }));
  store.busy.delete(key);
  store.notes[jobId] = result.ok ? "" : result.error ?? "Couldn't save it.";
  await loadTracker(true);
}
function wireReach(root) {
  root.querySelectorAll("[data-reach-job]").forEach((button) => button.addEventListener("click", () => void setReached(button.dataset.reachJob, Number(button.dataset.reach))));
}
function peopleCard(job) {
  const company = job.companyMissing ? "this company" : job.company;
  const posted = job.postedRecruiter && !job.contacts.some((person) => person.role === "job_poster") ? `<p class="small">Posted by <strong>${escape(job.postedRecruiter.name)}</strong>${job.postedRecruiter.title ? `, ${escape(job.postedRecruiter.title)}` : ""}${job.postedRecruiter.linkedinUrl ? ` \xB7 <a href="${escape(job.postedRecruiter.linkedinUrl)}" target="_blank" rel="noreferrer">LinkedIn \u2197</a>` : ""}</p>` : "";
  const badge = store.tracker?.peopleBadge;
  const head = `<div class="row-between"><span class="eyebrow">People at ${escape(short(company, 28))}${job.contacts.length ? ` \xB7 ${job.contacts.length}` : ""}</span>${badge ? `<span class="people-count${/^0 /.test(badge) ? " out" : ""}">${escape(badge)}</span>` : ""}</div>`;
  if (!isAppliedJob(job)) {
    return `<section class="page people" aria-label="People">${head}${posted}<p class="note">Once you apply, Unnepo finds who to email here: recruiters, the team, and people from your school.</p></section>`;
  }
  const preview = !job.contacts.length && job.contactsStatus === "done" ? job.fillReport?.peoplePreview : void 0;
  if (preview?.rows.length && store.tracker?.free) {
    const count2 = (role) => preview.rows.filter((row) => row.role === role).length;
    const words = (n, one, many) => n ? `${n} ${n === 1 ? one : many}` : "";
    const parts = [words(count2("recruiter"), "recruiter", "recruiters"), words(count2("alumni"), "alum", "alumni"), words(count2("department") + count2("team_member"), "person on the team", "people on the team")].filter(Boolean);
    return `<section class="page people" aria-label="People">${head}${posted}
      <p class="small">Unnepo found ${escape(parts.join(", ") || `${preview.rows.length} people`)} at ${escape(company)}.</p>
      <ul class="people-list">${preview.rows.map((row) => freeRow(null, row.title, row.role)).join("")}</ul></section>`;
  }
  const known = job.contacts.length ? peopleList(job) : "";
  if (job.contactsStatus === "idle" || preview && !store.tracker?.free) {
    return `<section class="page people" aria-label="People">${head}${posted}${known}
      <p class="note">Recruiters, the team, and people you have something in common with.</p>
      <button type="button" class="btn primary" data-find-people="${job.id}" ${store.busy.has(`find:${job.id}`) ? "disabled" : ""}>Find people</button>
      ${store.tracker?.peopleNote ? `<p class="small" style="color: var(--warn)">${escape(store.tracker.peopleNote)}</p>` : ""}</section>`;
  }
  const stale = job.contactsStatus === "finding" && Date.now() - Date.parse(job.updatedAt) > 2 * 60 * 1e3;
  if ((job.contactsStatus === "finding" || job.contactsStatus === "writing") && !stale) {
    return `<section class="page people" aria-label="People">${head}${posted}${known}<p class="note" role="status">${escape(job.contactsMessage || `Searching for people at ${company}\u2026`)}</p></section>`;
  }
  const none = !job.contacts.length;
  const linkedIn = (label, keywords) => `<a class="link" href="https://www.linkedin.com/search/results/people/?${new URLSearchParams({ keywords })}" target="_blank" rel="noreferrer">${label} on LinkedIn \u2197</a>`;
  return `
    <section class="page people" aria-label="People">${head}${posted}
      ${job.contactsMessage && none ? `<p class="small">${escape(job.contactsMessage)}</p>` : ""}
      ${none ? `
        <p class="note">${stale || job.contactsStatus === "failed" ? "That search didn't finish." : `No one found at ${escape(company)} yet.`}</p>
        <div class="links">${linkedIn("Recruiters", `recruiter ${job.company}`)}${linkedIn("The team", `${job.department || job.title} ${job.company}`)}</div>
        <div class="connect-code"><input class="field" data-website="${job.id}" value="${escape(websites[job.id] ?? "")}" placeholder="Company website, like acme.com" aria-label="Company website"><button type="button" class="solid" data-find-people="${job.id}">Search again</button></div>` : known}
    </section>`;
}
function peopleList(job) {
  return `<ul class="people-list">${job.contacts.map((person, index) => store.tracker?.free && !person.email && job.hidden.includes(person.name.toLowerCase()) ? freeRow(person.name, person.title, person.role) : personRow(job, person, index === job.contacts.findIndex((other) => other.email))).join("")}${store.tracker?.free ? unlockRow(job) : ""}</ul>`;
}
function unlockRow(job) {
  const more = job.fillReport?.peopleLocked ?? 0;
  const company = job.companyMissing ? "this company" : short(job.company, 24);
  const line = more ? `${more} more ${more === 1 ? "person" : "people"} at ${company}, with checked emails` : "Recruiters, the team and alumni, with checked emails";
  return `<li class="person compact unlock-row"><span class="unlock-plus" aria-hidden="true">+</span>
    <div class="person-text"><span class="person-name">Unlock more people</span><span class="sub" title="${escape(line)}">${escape(line)}</span></div>
    <button type="button" class="solid" data-upgrade>Upgrade to Pro</button></li>`;
}
function personRow(job, person, first) {
  const key = person.name.toLowerCase();
  const hidden = job.hidden.includes(key);
  const revealsLeft = (job.fillReport?.peopleReveals ?? 0) < 3;
  const open = openPeople.has(person.id);
  const followUps = store.followUps[person.id] ?? 0;
  const due = person.outreachStatus === "emailed" && Boolean(job.fillReport?.emailedAt?.[person.id]);
  const busy = (what) => store.busy.has(`${what}:${person.id}`);
  const draft = drafts[person.id] ?? { subject: person.emailSubject ?? "", body: person.emailBody ?? "" };
  const link = person.email && draft.body ? composeLink(store.mailer, person.email, draft.subject, draft.body) : null;
  const followUp = person.outreachStatus === "emailed" || person.outreachStatus === "no_response";
  const status = { not_contacted: "", emailed: "Emailed", replied: "Replied", no_response: "No reply" }[person.outreachStatus];
  const send = person.email ? link ? `<a class="solid send-mail" href="${escape(link.url)}" ${link.url.startsWith("mailto:") ? "" : 'target="_blank" rel="noreferrer"'} data-email-link="${person.id}" data-cut="${link.cut}">${store.mailer === "gmail" ? GMAIL : ""}${followUp ? "Open again" : "Send"} in ${MAILER_NAME[store.mailer]} \u2197</a>` : `<button type="button" class="solid send-mail" data-write-open="${person.id}" ${busy("write") ? "disabled" : ""}>${busy("write") ? "Writing your email\u2026" : "Write email"}</button>` : hidden ? revealsLeft ? `<button type="button" class="solid" data-reveal="${person.id}" ${busy("reveal") ? "disabled" : ""}>${busy("reveal") ? "Looking\u2026" : "Show person"}</button>` : `<span class="small">You've shown 3 people for this job.</span>` : `<span class="small">No email found.</span>`;
  const tag = status ? `<span class="card-tag${person.outreachStatus === "replied" ? " ok" : ""}">${status}</span>` : person.emailBody ? `<span class="card-tag written">Written</span>` : "";
  return `
    <li class="person card${first ? " first" : ""}${open ? " open" : ""}">
      <button type="button" class="person-head" data-person-toggle="${person.id}" aria-expanded="${open}" aria-label="${escape(person.name)}">
        ${initialsAvatar(person.name)}
        <span class="person-text">
          <span class="person-top"><span class="person-name">${escape(person.name)}</span>${first ? `<span class="start-here">\u2605 Start</span>` : ""}${person.role === "job_poster" ? `<span class="posted-tag">Shown on job posting</span>` : ""}</span>
          <span class="sub">${escape(person.title || ROLE_LABEL[person.role] || "")}</span>
          <span class="person-mail">${person.email ? `${GMAIL}<span class="mail-text">${escape(person.email)}</span>` : `<span class="muted">${hidden ? "Tap to show who it is" : "No email found"}</span>`}</span>
        </span>
        <span class="person-side">${tag}<span class="chev" aria-hidden="true">\u203A</span></span>
      </button>
      ${open ? `<div class="person-body">
        ${justOpened.has(person.id) ? `
          <div class="sent-check" role="status"><span class="small">${justOpened.get(person.id) ? "Sent the follow-up?" : "Sent it?"}</span>
            <button type="button" class="solid" data-sent="${person.id}" data-follow="${justOpened.get(person.id)}">${justOpened.get(person.id) ? "I sent the follow-up" : "I emailed them"}</button></div>` : ""}
        ${person.email && !hidden && draft.body ? `<div class="letter-form flat">
            <input class="field" data-subject="${person.id}" value="${escape(draft.subject)}" aria-label="Subject" maxlength="200">
            <textarea class="field letter-input" rows="7" data-body="${person.id}" aria-label="Email to ${escape(person.name)}">${escape(draft.body)}</textarea>
          </div>` : ""}
        <div class="person-line">${send}${person.linkedinUrl ? `<a class="link" href="${escape(person.linkedinUrl)}" target="_blank" rel="noreferrer">LinkedIn \u2197</a>` : ""}</div>
        ${person.emailSource && person.email ? `<span class="small"${person.emailSource === "likely" || person.emailSource === "guess" ? ' style="color: var(--warn)"' : ""}>${escape(EMAIL_SOURCE[person.emailSource] ?? "")}</span>` : ""}
        ${person.email && !hidden ? `<div class="links">
          ${draft.body ? `<button type="button" class="quiet-link" data-write="${person.id}" ${busy("write") ? "disabled" : ""}>${busy("write") ? "Writing\u2026" : "Write it again"}</button>` : ""}
          ${drafts[person.id] ? `<button type="button" class="quiet-link" data-save-draft="${person.id}">Save my edits</button>` : ""}
          ${draft.body ? `<button type="button" class="quiet-link" data-copy-email="${person.id}">Copy</button>` : ""}
          ${person.outreachStatus === "not_contacted" && !justOpened.has(person.id) ? `<button type="button" class="quiet-link" data-status="${person.id}" data-value="emailed">I emailed them</button>` : ""}
          ${followUp && due ? `${followUps < MAX_FOLLOW_UPS ? `<button type="button" class="quiet-link" data-follow-up="${person.id}" ${busy("follow") ? "disabled" : ""}>${busy("follow") ? "Writing\u2026" : "Write follow-up"}</button>` : ""}<button type="button" class="quiet-link" data-status="${person.id}" data-value="replied">They replied</button><button type="button" class="quiet-link" data-status="${person.id}" data-value="no_response">No reply, stop</button>` : ""}
          <button type="button" class="quiet-link" data-bounced="${person.id}">It bounced</button>
        </div>` : ""}
      </div>` : ""}
    </li>`;
}
function wireJobPage(root, job) {
  wireReach(root);
  const say = (text) => {
    store.notes[job.id] = text;
    host.redraw();
  };
  const run = async (what, contactId, message) => {
    store.busy.add(`${what}:${contactId}`);
    host.redraw();
    const result = await ask({ type: "people", body: { applicationId: job.id, contactId, ...message } }).catch(() => ({ ok: false, error: "Couldn't reach Unnepo." }));
    store.busy.delete(`${what}:${contactId}`);
    if (!result.ok) store.notes[job.id] = result.error ?? "Couldn't do that.";
    else store.notes[job.id] = "";
    await loadTracker();
    return result;
  };
  const person = (id) => job.contacts.find((item) => item.id === id);
  root.querySelectorAll("[data-outcome]").forEach((select) => select.addEventListener("change", async () => {
    const outcome = select.value === "submitted" ? null : select.value;
    const result = await ask({ type: "job-status", applicationId: job.id, outcome }).catch(() => ({ ok: false, error: "Couldn't reach Unnepo." }));
    say(result.ok ? "" : result.error ?? "Couldn't change it.");
    void loadTracker();
  }));
  root.querySelector("[data-mark-applied]")?.addEventListener("click", async () => {
    const result = await ask({ type: "job-status", applicationId: job.id, applied: true }).catch(() => ({ ok: false, error: "Couldn't reach Unnepo." }));
    say(result.ok ? "Marked as applied." : result.error ?? "Couldn't change it.");
    void loadTracker();
  });
  root.querySelectorAll("[data-job-menu]").forEach((menu) => {
    menu.addEventListener("toggle", () => {
      menuOpenFor = menu.open ? menu.dataset.jobMenu : menuOpenFor === menu.dataset.jobMenu ? "" : menuOpenFor;
    });
    menu.querySelectorAll(".job-menu-item").forEach((item) => item.addEventListener("click", () => {
      menuOpenFor = "";
      menu.open = false;
    }));
  });
  root.querySelector("[data-see-people]")?.addEventListener("click", () => {
    root.querySelector(".people")?.scrollIntoView({ behavior: "smooth", block: "start" });
  });
  root.querySelector("[data-edit-job]")?.addEventListener("click", () => {
    Object.assign(editing, { jobId: job.id, title: job.titleMissing ? "" : job.title, company: job.companyMissing ? "" : job.company, url: job.url ?? "", busy: false, error: "" });
    host.redraw();
  });
  root.querySelectorAll("[data-edit]").forEach((box) => box.addEventListener("input", () => {
    editing[box.dataset.edit] = box.value;
  }));
  root.querySelector("[data-edit-cancel]")?.addEventListener("click", () => {
    editing.jobId = "";
    if (document.activeElement instanceof HTMLElement) document.activeElement.blur();
    host.redraw();
  });
  root.querySelector("[data-edit-save]")?.addEventListener("click", async () => {
    const [title, company, url] = [editing.title.trim(), editing.company.trim(), editing.url.trim()];
    if (title.length < 2) {
      editing.error = "Type the job title.";
      return host.redraw();
    }
    if (company.length < 2) {
      editing.error = "Type the company's name.";
      return host.redraw();
    }
    if (url && !/^https:\/\/\S+\.\S+/i.test(url)) {
      editing.error = "The link should start with https://.";
      return host.redraw();
    }
    editing.busy = true;
    editing.error = "";
    if (document.activeElement instanceof HTMLElement) document.activeElement.blur();
    host.redraw();
    const changes = {
      ...title !== job.title || job.titleMissing ? { title } : {},
      ...company !== job.company || job.companyMissing ? { company } : {},
      ...url !== (job.url ?? "") ? { url } : {}
    };
    const result = Object.keys(changes).length ? await ask({ type: "edit-job", applicationId: job.id, ...changes }).catch(() => ({ ok: false, error: "Couldn't reach Unnepo." })) : { ok: true };
    editing.busy = false;
    if (!result.ok) {
      editing.error = result.error ?? "Couldn't save it.";
      return host.redraw();
    }
    editing.jobId = "";
    store.notes[job.id] = Object.keys(changes).length ? "Saved." : "";
    await loadTracker(true);
  });
  root.querySelector("[data-hide-job]")?.addEventListener("click", (event) => {
    const button = event.currentTarget;
    void setHidden(job.id, button.dataset.hide === "1");
  });
  root.querySelector("[data-delete-job]")?.addEventListener("click", async () => {
    if (!confirm(`Delete ${job.title} at ${job.company} from your tracker? Its people go too.`)) return;
    const result = await ask({ type: "delete-job", applicationId: job.id }).catch(() => ({ ok: false, error: "Couldn't reach Unnepo." }));
    if (!result.ok) return say(result.error ?? "Couldn't delete it.");
    await loadTracker();
    host.openJob("");
  });
  root.querySelectorAll("[data-website]").forEach((box) => box.addEventListener("input", () => {
    websites[job.id] = box.value;
  }));
  root.querySelectorAll("[data-find-people]").forEach((button) => button.addEventListener("click", async () => {
    store.busy.add(`find:${job.id}`);
    host.redraw();
    const website = (websites[job.id] ?? "").trim();
    const result = await ask({ type: "people", body: { action: "find", applicationId: job.id, ...website ? { website } : {} } }).catch(() => ({ ok: false, error: "Couldn't reach Unnepo." }));
    store.busy.delete(`find:${job.id}`);
    store.notes[job.id] = result.ok ? "" : result.error ?? "Couldn't start the search.";
    await loadTracker(true);
  }));
  root.querySelectorAll("[data-upgrade]").forEach((button) => button.addEventListener("click", () => {
    if (host.upgradeUrl()) window.open(host.upgradeUrl(), "_blank", "noreferrer");
  }));
  root.querySelectorAll("[data-reveal]").forEach((button) => button.addEventListener("click", () => void run("reveal", button.dataset.reveal, { action: "reveal" })));
  root.querySelectorAll("[data-person-toggle]").forEach((button) => button.addEventListener("click", () => {
    const id = button.dataset.personToggle;
    if (openPeople.has(id)) openPeople.delete(id);
    else openPeople.add(id);
    host.redraw();
  }));
  root.querySelectorAll("[data-write]").forEach((button) => button.addEventListener("click", async () => {
    delete drafts[button.dataset.write];
    await run("write", button.dataset.write, { action: "write" });
  }));
  root.querySelectorAll("[data-subject]").forEach((box) => box.addEventListener("input", () => {
    const id = box.dataset.subject;
    const current = drafts[id] ?? { subject: person(id)?.emailSubject ?? "", body: person(id)?.emailBody ?? "" };
    drafts[id] = { ...current, subject: box.value };
  }));
  root.querySelectorAll("[data-body]").forEach((box) => box.addEventListener("input", () => {
    const id = box.dataset.body;
    const current = drafts[id] ?? { subject: person(id)?.emailSubject ?? "", body: person(id)?.emailBody ?? "" };
    drafts[id] = { ...current, body: box.value };
  }));
  root.querySelectorAll("[data-save-draft]").forEach((button) => button.addEventListener("click", async () => {
    const id = button.dataset.saveDraft;
    const draft = drafts[id];
    if (!draft) return;
    const result = await run("save", id, { action: "write", subject: draft.subject, body: draft.body });
    if (result.ok) delete drafts[id];
    if (document.activeElement instanceof HTMLElement) document.activeElement.blur();
    host.redraw();
  }));
  root.querySelectorAll("[data-copy-email]").forEach((button) => button.addEventListener("click", () => {
    const id = button.dataset.copyEmail;
    const body = drafts[id]?.body ?? person(id)?.emailBody ?? "";
    void navigator.clipboard.writeText(body).then(() => say("Copied."), () => say("Couldn't copy. Select the text and copy it."));
  }));
  root.querySelectorAll("[data-bounced]").forEach((button) => button.addEventListener("click", () => {
    if (confirm("Did the email bounce? Unnepo drops this address and checks the company's format again.")) void run("bounced", button.dataset.bounced, { action: "bounced" });
  }));
  const opened = async (contact, followUp) => {
    justOpened.set(contact.id, followUp);
    await ask({ type: "email-opened", contactId: contact.id, applicationId: job.id, name: contact.name, company: job.company, followUp });
    host.redraw();
  };
  const openLink = async (contact, followUp) => {
    const draft = drafts[contact.id] ?? { subject: contact.emailSubject ?? "", body: contact.emailBody ?? "" };
    const link = composeLink(store.mailer, contact.email, draft.subject, draft.body);
    if (link.cut) {
      await navigator.clipboard.writeText(draft.body).catch(() => void 0);
      say("The email was too long for the link: it's copied. Paste it into the email that opened.");
    }
    if (link.url.startsWith("mailto:")) window.location.href = link.url;
    else void chrome.tabs.create({ url: link.url });
    await opened(contact, followUp);
  };
  root.querySelectorAll("[data-email-link]").forEach((anchor) => anchor.addEventListener("click", (event) => {
    const contact = person(anchor.dataset.emailLink);
    if (!contact) return;
    event.preventDefault();
    void openLink(contact, contact.outreachStatus !== "not_contacted");
  }));
  root.querySelectorAll("[data-write-open]").forEach((button) => button.addEventListener("click", async () => {
    const result = await run("write", button.dataset.writeOpen, { action: "write" });
    const contact = result.ok ? jobById(job.id)?.contacts.find((item) => item.id === button.dataset.writeOpen) : null;
    if (contact?.email && contact.emailBody) await openLink(contact, false);
  }));
  root.querySelectorAll("[data-follow-up]").forEach((button) => button.addEventListener("click", async () => {
    const id = button.dataset.followUp;
    delete drafts[id];
    const result = await run("follow", id, { action: "write", followUp: true });
    const contact = result.ok ? jobById(job.id)?.contacts.find((item) => item.id === id) : null;
    openPeople.add(id);
    if (contact?.email && contact.emailBody) await openLink(contact, true);
  }));
  root.querySelectorAll("[data-sent]").forEach((button) => button.addEventListener("click", async () => {
    const id = button.dataset.sent;
    justOpened.delete(id);
    await run("status", id, { action: "status", status: "emailed", followedUp: button.dataset.follow === "true" });
  }));
  root.querySelectorAll("[data-status]").forEach((button) => button.addEventListener("click", () => {
    justOpened.delete(button.dataset.status);
    void run("status", button.dataset.status, { action: "status", status: button.dataset.value });
  }));
}
var SNOOZE_MS = 3 * 864e5;
function todayList() {
  if (!store.tracker) return { goal: null, items: [] };
  return reminders(store.tracker, store.marks, store.opened, store.followUps);
}
function remindersCard(limit = 6, title = "Today", showGoal = true) {
  if (!store.tracker) {
    return `<section class="page" aria-label="Today"><span class="eyebrow">Today</span><p class="note">${store.error ? escape(store.error) : "Loading your reminders\u2026"}</p></section>`;
  }
  const { goal, items } = todayList();
  const goalLine = showGoal && goal?.daily ? `<div class="goal"><span>Applied today</span><span>${goal.today} of ${goal.daily}</span></div><div class="bar" role="progressbar" aria-label="Goal for today" aria-valuemin="0" aria-valuemax="${goal.daily}" aria-valuenow="${Math.min(goal.today, goal.daily)}"><div style="width:${Math.min(100, Math.round(goal.today / goal.daily * 100))}%"></div></div>` : "";
  const row = (item) => `
    <li class="reminder">
      <div class="reminder-text"><span class="reminder-title">${escape(item.title)}</span>${item.detail ? `<span class="sub">${escape(item.detail)}</span>` : ""}</div>
      <div class="reminder-actions">
        <button type="button" class="solid" data-remind="${escape(item.key)}">${escape(item.action)}</button>
        ${item.kind === "sent" ? `<button type="button" class="quiet-link" data-remind-mark="${escape(item.key)}">Not yet</button>` : `<button type="button" class="quiet-link" data-remind-snooze="${escape(item.key)}" title="Hide for 3 days">Later</button><button type="button" class="quiet-link" data-remind-mark="${escape(item.key)}" title="Done">Done</button>`}
      </div>
    </li>`;
  return `
    <section class="page" aria-label="${title}">
      <div class="row-between"><span class="eyebrow">${title}</span>${items.length ? `<span class="mono">${items.length} TO DO</span>` : ""}</div>
      ${goalLine}
      ${items.length ? `<ul class="reminders">${items.slice(0, limit).map(row).join("")}</ul>${items.length > limit ? `<p class="small">And ${items.length - limit} more on the dashboard.</p>` : ""}` : `<p class="note">Nothing due. Email someone at a company you applied to, and Unnepo reminds you to follow up.</p>`}
    </section>`;
}
function wireReminders(root) {
  const items = todayList().items;
  const find = (key) => items.find((item) => item.key === key);
  const mark = async (key, until) => {
    await ask({ type: "reminder-mark", key, until });
    await loadTracker();
  };
  root.querySelectorAll("[data-remind-mark]").forEach((button) => button.addEventListener("click", () => void mark(button.dataset.remindMark)));
  root.querySelectorAll("[data-remind-snooze]").forEach((button) => button.addEventListener("click", () => void mark(button.dataset.remindSnooze, Date.now() + SNOOZE_MS)));
  root.querySelectorAll("[data-remind]").forEach((button) => button.addEventListener("click", async () => {
    const item = find(button.dataset.remind);
    if (!item) return;
    if (item.kind === "sent" && item.contactId && item.applicationId) {
      const followUp = item.title.includes("follow-up");
      await ask({ type: "people", body: { action: "status", applicationId: item.applicationId, contactId: item.contactId, status: "emailed", followedUp: followUp } });
      return void loadTracker();
    }
    if (item.action === "Stop following up" && item.contactId && item.applicationId) {
      await ask({ type: "people", body: { action: "status", applicationId: item.applicationId, contactId: item.contactId, status: "no_response" } });
      return void loadTracker();
    }
    if (item.kind === "finish" && item.applicationId) {
      const job = jobById(item.applicationId);
      if (job?.url) return void chrome.tabs.create({ url: job.url });
    }
    if (item.applicationId) host.openJob(item.applicationId, item.contactId);
  }));
}
var SURE = { confirmed: "Confirmed", likely: "Likely", pressed: "Pressed Apply", viewed: "Viewed" };
var detectedOpen = false;
var detectedShown = "";
var ago = (at) => {
  const minutes = Math.round((Date.now() - at) / 6e4);
  if (minutes < 1) return "just now";
  if (minutes < 60) return `${minutes} min ago`;
  const hours = Math.round(minutes / 60);
  if (hours < 24) return `${hours} h ago`;
  return new Date(at).toLocaleDateString("en-US", { month: "short", day: "numeric" });
};
function detectedMenu(inline = false) {
  const list = store.detected ?? [];
  const asking = list.filter((item) => item.state === "ask").length;
  const row = (item) => {
    const answered = item.state === "yes" || item.state === "no" || item.state === "undone";
    const actions = item.state === "ask" ? `<button type="button" class="solid" data-detected-yes="${item.id}">\u2713 I applied</button><button type="button" class="quiet-link" data-detected-no="${item.id}">\u2717 No</button>` : item.state === "saved" ? `<span class="status done">Saved \u2713</span><button type="button" class="quiet-link" data-detected-undo="${item.id}">Undo</button>` : item.state === "yes" ? `<span class="status done">Added \u2713</span><button type="button" class="quiet-link" data-detected-undo="${item.id}">Undo</button>` : item.state === "seen" ? `<button type="button" class="solid" data-detected-yes="${item.id}">\u2713 I applied</button>` : item.state === "undone" ? `<span class="status">Undone</span>` : `<span class="status">Not applied</span>`;
    const description = (item.description ?? "").trim();
    const info = description || item.poster || item.url ? `
          <details class="detected-info">
            <summary>Job details</summary>
            ${item.poster ? `<p class="small">Hiring: ${escape(item.poster.name)}${item.poster.title ? ` \xB7 ${escape(short(item.poster.title, 80))}` : ""}</p>` : ""}
            ${description ? `<p class="detected-desc">${escape(description.slice(0, 1500))}${description.length > 1500 ? "\u2026" : ""}</p>` : ""}
            ${/^https:\/\//.test(item.url) ? `<a class="quiet-link" href="${escape(item.url)}" target="_blank" rel="noreferrer">Open the job \u2197</a>` : ""}
          </details>` : "";
    return `
      <li class="detected${answered ? " answered" : ""}">
        <div class="detected-text">
          ${item.applicationId ? `<button type="button" class="detected-title" data-open-job="${item.applicationId}">${escape(short(item.title, 70))}</button>` : `<span class="detected-title">${escape(short(item.title, 70))}</span>`}
          <span class="sub">${escape([item.company, item.site, ago(item.at), SURE[item.sure]].filter(Boolean).join(" \xB7 "))}</span>
          ${item.error ? `<span class="small" style="color: var(--warn)">${escape(item.error)}</span>` : ""}
          ${info}
        </div>
        <div class="detected-actions">${actions}</div>
      </li>`;
  };
  if (inline) {
    const shown = list.slice(0, 5);
    if (!shown.length) return `<div class="add-part detected-inline"><span class="eyebrow">Detected</span><p class="small">Jobs you open or apply to show up here. Ones the site confirms are saved by themselves.</p></div>`;
    const main = shown.find((item) => item.id === detectedShown) ?? shown[0];
    const done = (item) => item.state === "saved" || item.state === "yes";
    const open = (item) => item.state === "ask" || item.state === "seen";
    const mainActions = open(main) ? `<button type="button" class="btn primary" data-detected-yes="${main.id}">\u2713 I applied</button>${main.state === "ask" ? `<button type="button" class="btn square" data-detected-no="${main.id}" aria-label="I didn't apply">\u2717</button>` : ""}` : done(main) ? `<span class="status done">${main.state === "saved" ? "Saved" : "Added"} \u2713</span><button type="button" class="quiet-link" data-detected-undo="${main.id}">Undo</button>` : `<span class="status">${main.state === "undone" ? "Undone" : "Not applied"}</span>`;
    const description = (main.description ?? "").trim();
    const details = description || main.poster || /^https:\/\//.test(main.url) ? `
        <details class="detected-info">
          <summary>Job details</summary>
          ${main.poster ? `<p class="small">Hiring: ${escape(main.poster.name)}${main.poster.title ? ` \xB7 ${escape(short(main.poster.title, 80))}` : ""}</p>` : ""}
          ${description ? `<p class="detected-desc">${escape(description.slice(0, 1500))}${description.length > 1500 ? "\u2026" : ""}</p>` : ""}
          ${/^https:\/\//.test(main.url) ? `<a class="quiet-link" href="${escape(main.url)}" target="_blank" rel="noreferrer">Open the job \u2197</a>` : ""}
        </details>` : "";
    const others = shown.filter((item) => item !== main).map((item) => `
        <li class="mini-detected${done(item) || item.state === "no" || item.state === "undone" ? " answered" : ""}">
          <button type="button" class="mini-detected-text" data-detected-page="${item.id}" title="Show this one"><span class="mini-title">${escape(short(item.title, 60))}</span><span class="sub">${escape([item.company, ago(item.at)].filter(Boolean).join(" \xB7 "))}</span></button>
          ${open(item) ? `<button type="button" class="mini-btn" data-detected-yes="${item.id}" aria-label="I applied to ${escape(item.title)}">\u2713</button>` : done(item) ? `<span class="mini-done" aria-label="Saved">\u2713</span>` : ""}
        </li>`).join("");
    return `
    <div class="add-part detected-inline">
      <div class="detected-card${main.state === "ask" ? " asking" : ""}">
        <span class="tile-sub">${escape([main.site, ago(main.at), SURE[main.sure]].filter(Boolean).join(" \xB7 "))}</span>
        ${main.applicationId ? `<button type="button" class="detected-title big" data-open-job="${main.applicationId}">${escape(short(main.title, 80))}</button>` : `<span class="detected-title big">${escape(short(main.title, 80))}</span>`}
        <span class="sub">${escape(main.company)}</span>
        ${main.error ? `<span class="small" style="color: var(--warn)">${escape(main.error)}</span>` : ""}
        ${details}
        <div class="detected-card-actions">${mainActions}</div>
      </div>
      ${others ? `<ul class="mini-detected-list" aria-label="Other jobs Unnepo caught">${others}</ul>` : ""}
    </div>`;
  }
  return `
    <details class="detected-menu" id="detected-menu" ${detectedOpen ? "open" : ""}>
      <summary><span>Detected jobs${asking ? ` <span class="count">${asking}</span>` : ""}</span><span class="mono">LAST ${Math.min(5, list.length) || 5}</span></summary>
      ${list.length ? `<ul class="detected-list">${list.slice(0, 5).map(row).join("")}</ul><button type="button" class="quiet-link" id="detected-clear">Clear list</button>` : `<p class="note">Jobs you open or apply to show up here, with their details. Ones the site confirms are saved by themselves.</p>`}
    </details>`;
}
function wireDetected(root) {
  const menu = root.querySelector("#detected-menu");
  menu?.addEventListener("toggle", () => {
    detectedOpen = menu.open;
  });
  const act = async (message, item2) => {
    const result = await ask(message).catch(() => ({ ok: false, error: "Couldn't reach Unnepo." }));
    if (!result.ok && result.needsForm && item2 && host.addJob) host.addJob(item2);
    await loadTracker();
  };
  const item = (id) => store.detected?.find((entry) => entry.id === id);
  root.querySelectorAll("[data-detected-yes]").forEach((button) => button.addEventListener("click", () => {
    button.disabled = true;
    void act({ type: "detected-answer", id: button.dataset.detectedYes, applied: true }, item(button.dataset.detectedYes));
  }));
  root.querySelectorAll("[data-detected-no]").forEach((button) => button.addEventListener("click", () => void act({ type: "detected-answer", id: button.dataset.detectedNo, applied: false })));
  root.querySelectorAll("[data-detected-undo]").forEach((button) => button.addEventListener("click", () => void act({ type: "detected-undo", id: button.dataset.detectedUndo })));
  root.querySelectorAll("[data-detected-page]").forEach((button) => button.addEventListener("click", () => {
    detectedShown = button.dataset.detectedPage;
    host.redraw();
  }));
  root.querySelector("#detected-clear")?.addEventListener("click", () => void act({ type: "detected-clear" }));
  root.querySelectorAll(".detected-title[data-open-job]").forEach((button) => button.addEventListener("click", () => host.openJob(button.dataset.openJob)));
}
async function refreshDetected() {
  const result = await ask({ type: "detected-list" }).catch(() => ({ ok: false, list: void 0 }));
  if (!result.ok || !result.list) return;
  const changed = JSON.stringify(result.list) !== JSON.stringify(store.detected);
  store.detected = result.list;
  if (changed) host.redraw();
}

// extension/src/dashboard/dashboard.ts
var side = document.getElementById("side");
var rows = document.getElementById("rows");
var detail = document.getElementById("detail");
var empty = document.getElementById("empty");
var count = document.getElementById("dash-count");
var search = document.getElementById("search");
var filter = document.getElementById("filter");
var sort = document.getElementById("sort");
var selected = { id: new URLSearchParams(location.search).get("job") ?? "", contact: "" };
var apiBase = "";
void chrome.storage.local.get("apiBase").then((stored) => {
  apiBase = stored.apiBase ?? "";
});
var when2 = (at) => at ? new Date(at).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "2-digit" }) : "\u2014";
function shownJobs() {
  const jobs = store.tracker?.jobs ?? [];
  const words = search.value.trim().toLowerCase();
  const due = new Set(followUpsDue(jobs).map((item) => item.applicationId));
  const matches = jobs.filter((job) => {
    if (words && !`${job.title} ${job.company} ${job.location ?? ""}`.toLowerCase().includes(words)) return false;
    if (filter.value === "hidden") return isHiddenJob(job);
    if (isHiddenJob(job)) return false;
    const stage = stageOf(job);
    switch (filter.value) {
      case "applied":
        return isAppliedJob(job);
      case "in_progress":
        return stage === "in_progress";
      case "follow_up":
        return stage === "follow_up" || due.has(job.id);
      case "interviewing":
        return stage === "interviewing" || stage === "assessment" || stage === "offer";
      case "rejected":
        return stage === "rejected";
      default:
        return true;
    }
  });
  const at = (job) => Date.parse(job.submittedAt ?? job.createdAt);
  const order = {
    recent: (a, b) => at(b) - at(a),
    oldest: (a, b) => at(a) - at(b),
    company: (a, b) => a.company.localeCompare(b.company),
    follow: (a, b) => Number(due.has(b.id)) - Number(due.has(a.id)) || at(b) - at(a)
  };
  return [...matches].sort(order[sort.value] ?? order.recent);
}
function drawTable() {
  const jobs = shownJobs();
  const due = new Set(followUpsDue(store.tracker?.jobs ?? []).map((item) => item.applicationId));
  count.textContent = store.tracker ? `${store.tracker.jobs.length} JOBS` : "";
  rows.innerHTML = jobs.map((job) => {
    const emailed = job.contacts.filter((person) => person.outreachStatus !== "not_contacted").length;
    const people = job.contacts.length ? `${job.contacts.length}${emailed ? ` \xB7 ${emailed} emailed` : ""}` : job.contactsStatus === "finding" ? "Searching\u2026" : "\u2014";
    return `<tr data-job="${job.id}" class="${job.id === selected.id ? "selected" : ""}${due.has(job.id) ? " due" : ""}" tabindex="0">
      <td><span class="cell-title">${escape(job.titleMissing ? "Job title missing" : job.title)}</span>${job.location ? `<span class="cell-sub">${escape(job.location)}</span>` : ""}${due.has(job.id) ? `<span class="due-tag">FOLLOW-UP DUE</span>` : ""}</td>
      <td>${escape(job.company)}</td>
      <td><span class="status${isAppliedJob(job) ? " done" : ""}">${escape(stageLabel(job))}</span></td>
      <td class="mono">${isAppliedJob(job) ? when2(job.submittedAt ?? job.createdAt) : "\u2014"}</td>
      <td class="mono">${escape(people)}</td>
    </tr>`;
  }).join("");
  empty.hidden = Boolean(jobs.length);
  empty.textContent = !store.tracker ? store.error || "Loading your jobs\u2026" : store.tracker.jobs.length ? "No jobs match." : "No jobs yet. Apply somewhere and the extension catches it.";
  rows.querySelectorAll("tr[data-job]").forEach((row) => {
    const open = () => openJob(row.dataset.job);
    row.addEventListener("click", open);
    row.addEventListener("keydown", (event) => {
      if (event.key === "Enter") open();
    });
  });
}
var typing = () => Boolean(document.activeElement?.closest(".dash-detail, .dash-side") && document.activeElement.matches("input, textarea, select"));
function draw() {
  drawTable();
  if (typing()) return;
  side.innerHTML = detectedMenu() + remindersCard(12);
  wireDetected(side);
  wireReminders(side);
  const job = selected.id ? jobById(selected.id) : null;
  detail.innerHTML = job ? jobPage(job, selected.contact || void 0) : `<p class="placeholder">Click a job to see its status and the people to email there.</p>`;
  if (job) wireJobPage(detail, job);
}
function openJob(id, contact = "") {
  selected = { id, contact };
  history.replaceState(null, "", id ? `?job=${encodeURIComponent(id)}` : location.pathname);
  draw();
  if (id) detail.scrollIntoView({ block: "nearest" });
}
setHost({ redraw: draw, openJob, upgradeUrl: () => `${apiBase}${UPGRADE_URL}` });
for (const box of [search, filter, sort]) box.addEventListener(box === search ? "input" : "change", drawTable);
chrome.runtime.onMessage.addListener((message) => {
  if (message?.type === "tracker-changed") void loadTracker();
  if (message?.type === "state-changed") void refreshDetected();
});
document.addEventListener("visibilitychange", () => {
  if (!document.hidden) void loadTracker();
});
void loadTracker(true);
